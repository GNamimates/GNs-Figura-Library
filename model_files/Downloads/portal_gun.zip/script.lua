--portal gun in figura by dragekk#7300 on discord

--enable commands

--chat.setFiguraCommandPrefix(".")


--texture
local texture = {x = 64, y = 64}

--functions
function lerp(a, b, x)
    return a + (b - a) * x
end

function clamp(value,low,high)
    return math.min(math.max(value, low), high)
end

--pos and load 
function player_init()
    local saved_data = load_saved_data(data.load("rtx"))
    if not saved_data then
        block_pos = vectors.of({0, 0, 0, 1})
        portal_pos = block_pos
        update_pixels_pos(0)
    end
end

function load_saved_data(loaded)
    if not loaded then
        return
    end
    pixel_scale = 1
    block_pos = loaded.block
    portal_pos = loaded.portal
    default_rot = loaded.rot
    portal_rot = loaded.portal_rot
    update_pixels_pos(loaded.rot.y)
    return true
end

--block colors u can add more colors here
block_colors = {
    ["sky"] = {184/255, 210/255, 1},
    ["minecraft:stone"] = {0.5, 0.5, 0.5},
    ["minecraft:gravel"] = {0.7, 0.7, 0.7},
    ["minecraft:grass_block"] = {0.7, 1, 0.4},
    ["minecraft:dirt"] = {0.7, 0.5, 0.3},
    ["minecraft:oak_log"] = {0.5, 0.35, 0.3},
    ["minecraft:oak_planks"] = {194/255, 157/255, 98/255},
    ["minecraft:birch_log"] = {0.9, 0.9, 0.9},
    ["minecraft:spruce_log"] = {0.3, 0.2, 0.1},
    ["minecraft:oak_leaves"] = {0.4, 0.7, 0.3},
    ["minecraft:birch_leaves"] = {0.55, 0.7, 0.4},
    ["minecraft:spruce_leaves"] = {0.4, 0.6, 0.4},
    ["minecraft:water"] = {0.4, 0.6, 1},
    ["minecraft:tall_seagrass"] = {0.4, 0.6, 1},
    ["minecraft:seagrass"] = {0.4, 0.6, 1},
    ["minecraft:kelp"] = {0.4, 0.6, 1},
    ["minecraft:sand"] = {1, 0.95, 0.75},
    ["minecraft:sandstone"] = {0.95, 0.9, 0.7},
    ["minecraft:granite"] = {1, 0.6, 0.5},
    ["minecraft:snow"] = {1, 1, 1},
    ["minecraft:ice"] = {0.6, 0.8, 1},
    ["minecraft:diamond_block"] = {90/255, 200/255, 247/255}
}

--list of not solid blocks
not_solid_blocks = " minecraft:air minecraft:cave_air minecraft:grass minecraft:fern minecraft:poppy minecraft:tall_grass minecraft:dandelion minecraft:oxeye_daisy minecraft:glass_pane "

--settings
pixel_scale = 1
move_distance = 0.9
move_blocks = 10
render_pos = false
pause = false
pixels_limit = 3
render_type = "tick"
default_rot = vectors.of({0, 0, 0})
portal_rot = vectors.of({0, 0, 0})

--[[local world = {getLunarTime = _G.world.getLunarTime, getLightLevel = _G.world.getLightLevel}
function world.getBlockState(pos)
    local block = _G.world.getBlockState(pos)
    return {name = block.name}
end]]

--block functions
function getBlockColor(block)
    if block.getMapColor then
        return vectors.intToRGB(block.getMapColor())
    else
        return block_colors[block.name]
    end
end

function blockIsSolid(block)
    if block.isTranslucent then
        return block.isOpaque() or ( not block.isTranslucent())
    else
        return not string.match(not_solid_blocks, " "..block.name.." ")
    end
end

function math.round(value)
    return math.floor(value*10000)/10000
end

function teleport_player(pos, relative, extra, rot, player_rot)
    if player_rot == nil then
        player_rot = 0
    end
    if extra == nil or rot == nil then
        rot = 0
        extra = 0
    end
    rot = math.rad(rot)
    if type(pos) == "table" then
        pos = vectors.of(pos)
    end
    pos = pos+vectors.of({
        math.sin(rot)*extra,
        0,
        math.cos(rot)*extra
    })
    pos = {x = math.round(pos.x), y = math.round(pos.y), z = math.round(pos.z)}
    if not string.match(pos.x, "%.") then
        pos.x = pos.x..".0"
    end
    if not string.match(pos.y, "%.") then
        pos.y = pos.y..".0"
    end
    if not string.match(pos.z, "%.") then
        pos.z = pos.z..".0"
    end
    local command = ""
    if math.abs(pos.x) > 1.5 and math.abs(pos.y) > 1.5 and math.abs(pos.z) > 1.5 and (not relative ) then
        command = "/tp @s "..pos.x.." "..pos.y.." "..pos.z.." "..player_rot.." ~"
    elseif relative then
        command = "/tp @s ~"..pos.x.." ~"..pos.y.." ~"..pos.z.." ~"..player_rot.." ~"
    end
    chat.sendMessage(command)
end

--update pos
size = {x = 16, y = 64} --size of screen 
function update_pixels_pos(rot)
    default_rot = vectors.of({0, rot, 0})
    rot = math.rad(rot)
    pixel_offset = {}
    local offset = {}
    for i, v in pairs(model.NO_PARENT) do  
        if type(v) == "table" then
            x = tonumber(i-1)%512+1
            v.setPos({
                0, --x
                math.floor((x-1)/size.x)*-1*pixel_scale, --y
                ((x-1)%size.x)*pixel_scale
            })
            pixel_offset[i] = v.getPos()
        end
    end
end

function portal_gun(tick, type)
    if not tick then
        portal_gun_pos = player.getPos()+vectors.of({0, player.getEyeHeight(), 0, 0, type})
        portal_gun_rot = player.getLookDir()*0.1
        return
    end
    if portal_gun_pos then
        --move portal thingy
        portal_gun_pos = portal_gun_pos+portal_gun_rot+vectors.of({0, 0, 0, 1})
        --particle
        if portal_gun_pos.t == 2 then
            particle.addParticle("minecraft:dust", portal_gun_pos*vectors.of({1, 1, 1}), {1, 0.5, 0, 0.5})
        else
            particle.addParticle("minecraft:dust", portal_gun_pos*vectors.of({1, 1, 1}), {0, 0, 1, 0.5})
        end
        --did it hit block?
        local block = world.getBlockState(portal_gun_pos)
        if blockIsSolid(block) then
            local type = portal_gun_pos.t
            local rot = math.atan(portal_gun_rot.x/portal_gun_rot.z)*60
            if tostring(rot) == "nan" then
                portal_gun_pos = nil
                return
            end
            if portal_gun_rot.z < 0 then
                rot = rot-180
            end
            rot = math.floor((rot+45)/90)
            if rot == 0 then
                portal_gun_pos = portal_gun_pos-portal_gun_rot*vectors.of({1, 1, 10})
            elseif rot == -3 or rot == 1 then
                portal_gun_pos = portal_gun_pos-portal_gun_rot*vectors.of({14, 1, 1})+vectors.of({0, 0, 0.5})
            elseif rot == -1 then
                portal_gun_pos = portal_gun_pos-vectors.of({0, 0, 0.5})
            end
            portal_gun_pos = portal_gun_pos*vectors.of({1, 1, 1})-portal_gun_rot*1
            portal_gun_pos = vectors.of({
                math.floor(portal_gun_pos.x+1),
                math.floor(portal_gun_pos.y-0.25),
                math.floor(portal_gun_pos.z+0.5)
            })
            if blockIsSolid(world.getBlockState(portal_gun_pos)) then
                portal_gun_pos = nil
                return
            elseif blockIsSolid(world.getBlockState(portal_gun_pos+vectors.of({0, 1}))) then
                portal_gun_pos = nil
                return
            end
            local set_portal_pos = portal_gun_pos
            local set_portal_rot
            local from_wall = 0.005
            if rot == -2 then
                set_portal_rot = vectors.of({0, 0, 0})
                if type == 2 then
                    set_portal_pos = set_portal_pos+vectors.of({-1, 0, from_wall})
                else
                    set_portal_pos = set_portal_pos+vectors.of({-1/16, 0, from_wall})
                end
            elseif rot == -1 then
                set_portal_rot = vectors.of({0, 90, 0})
                if type == 2 then
                    set_portal_pos = set_portal_pos+vectors.of({from_wall-1, 0, 31/32})
                else
                    set_portal_pos = set_portal_pos+vectors.of({from_wall-1, 0, 1/32})
                end
            elseif rot == 0 then
                set_portal_rot = vectors.of({0, 180, 0})
                if type == 2 then
                    set_portal_pos = set_portal_pos+vectors.of({-1/16, 0, 1-from_wall})
                else
                    set_portal_pos = set_portal_pos+vectors.of({-1, 0, 1-from_wall})
                end
            else
                set_portal_rot = vectors.of({0, 270, 0})
                if type == 2 then
                    set_portal_pos = set_portal_pos+vectors.of({1-1/16, 0, -31/32})
                else
                    set_portal_pos = set_portal_pos+vectors.of({1-1/16, 0, -1/32})
                end
            end
            if type == 2 then
                portal_pos = set_portal_pos
                portal_rot = set_portal_rot+vectors.of({0, 180, 0})
            else
                default_rot = set_portal_rot
                block_pos = set_portal_pos
            end
            portal_gun_pos = nil
        end
        --despawn
        if portal_gun_pos and portal_gun_pos.w > 400 then
            portal_gun_pos = nil
        end
    end
end

--action wheel
action_wheel.SLOT_1.setItem(item_stack.createItem("minecraft:blue_dye"))
action_wheel.SLOT_1.setHoverItem(item_stack.createItem("minecraft:blue_dye", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
action_wheel.SLOT_2.setItem(item_stack.createItem("minecraft:orange_dye"))
action_wheel.SLOT_2.setHoverItem(item_stack.createItem("minecraft:orange_dye", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
action_wheel.SLOT_3.setItem(item_stack.createItem("minecraft:barrier"))
action_wheel.SLOT_3.setHoverItem(item_stack.createItem("minecraft:barrier", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
action_wheel.SLOT_1.setFunction(function() portal_gun(nil, 1) end)
action_wheel.SLOT_2.setFunction(function() portal_gun(nil, 2) end)
action_wheel.SLOT_3.setFunction(function() block_pos = vectors.of({0, 0, 0, 1}) portal_pos = block_pos end)
action_wheel.setRightSize(3)
action_wheel.setLeftSize(3)

quality_settings = {
    {text = "Very Low", color = "#CC77FF", settings = function() pixels_limit = 8 move_distance = 1 move_blocks = 5 end},
    {text = "Low", color = "#AFF2FF", settings = function() pixels_limit = 6 move_distance = 0.9 move_blocks = 10 end},
    {text = "Normal", color = "#77FF77", settings = function() pixels_limit = 5 move_distance = 0.9 move_blocks = 20 end},
    {text = "High", color = "#AFF2FF", settings = function() pixels_limit = 5 move_distance = 0.8 move_blocks = 35 end},
    {text = "Very High", color = "#FF862B", settings = function() pixels_limit = 6 move_distance = 0.6 move_blocks = 50 end},
    {text = "Insane", color = "#FF82B7", settings = function() pixels_limit = 8 move_distance = 0.4 move_blocks = 100 end},
    {text = "Good Bye pc", color = "#FF4444", settings = function() pixels_limit = 16 move_distance = 0.1 move_blocks = 200 end}
}
quality_settings.page = 2
action_wheel.SLOT_6.setFunction(function() end)
action_wheel.SLOT_5.setFunction(function() action_wheel_quality(-1) end)
action_wheel.SLOT_7.setFunction(function() action_wheel_quality(1) end)
action_wheel.SLOT_6.setItem(item_stack.createItem("minecraft:yellow_glazed_terracotta"))
action_wheel.SLOT_6.setHoverItem(item_stack.createItem("minecraft:yellow_glazed_terracotta", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
action_wheel.SLOT_5.setItem(item_stack.createItem("minecraft:red_glazed_terracotta"))
action_wheel.SLOT_5.setHoverItem(item_stack.createItem("minecraft:red_glazed_terracotta", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
action_wheel.SLOT_7.setItem(item_stack.createItem("minecraft:lime_glazed_terracotta"))
action_wheel.SLOT_7.setHoverItem(item_stack.createItem("minecraft:lime_glazed_terracotta", '{Enchantments:[{id:"minecraft:mending",lvl:1}]}'))
function action_wheel_quality(x)
    local text = {
        '[{"text":"',
        '","color":"#AAAAAA"},{"text":": ","color":"white"},{"text":"',
        '","color":"',
        '"}]'
    }
    if quality_settings[quality_settings.page+x] ~= nil then
        quality_settings.page = quality_settings.page + x
    end
    local stuff = quality_settings[quality_settings.page]
    stuff.settings()
    action_wheel.SLOT_6.setTitle(text[1].."current"..text[2]..stuff.text..text[3]..stuff.color..text[4])
    stuff = quality_settings[quality_settings.page+1]
    if stuff == nil then
        stuff = {text = "none", color = "#FF00FF"}
    end
    action_wheel.SLOT_7.setTitle(text[1].."increase"..text[2]..stuff.text..text[3]..stuff.color..text[4])
    stuff = quality_settings[quality_settings.page-1]
    if stuff == nil then
        stuff = {text = "none", color = "#FF00FF"}
    end
    action_wheel.SLOT_5.setTitle(text[1].."decrease"..text[2]..stuff.text..text[3]..stuff.color..text[4])
end

action_wheel_quality(0)

--tick
time = 0 --used for fancy invalid texture animation
render_times = 0
tp_player = 0
function tick()
    player_pos = player.getPos()
    local distance_B = model.NO_PARENT[8].getPos()/vectors.of({-16, -16, 16})-player.getPos()
    local distance_B = (distance_B.x^2+distance_B.y^2+distance_B.z^2)^0.5
    local distance_O = model.NO_PARENT[520].getPos()/vectors.of({-16, -16, 16})-player.getPos()
    local distance_O = (distance_O.x^2+distance_O.y^2+distance_O.z^2)^0.5
    if time < pixels_limit+2 or block_pos.w == 1 or portal_pos.w == 1 then
        --do nothing
    elseif distance_O > 0.28 and distance_O < 0.5 then
        if tp_player == 0 then
            tp_player = 2
        end
    elseif distance_B > 0.28 and distance_B < 0.5 then
        if tp_player == 0 then
            tp_player = 1
        end
    elseif tp_player > 20 or tp_player < 5 or ( distance_B > 2 and distance_O > 2 ) then
        tp_player = 0
    end
    if tp_player >= 5 then
        tp_player = tp_player + 1
    end
    local pos1 = model.NO_PARENT[8].getPos()/vectors.of({-16, -16, 16})
    local pos2 = model.NO_PARENT[520].getPos()/vectors.of({-16, -16, 16})
    if tp_player == 1 then
        teleport_player(pos2-pos1, true, 0.5, portal_rot.y+180, default_rot.y-portal_rot.y)
        tp_player = 5
    elseif tp_player == 2 then
        teleport_player(pos1-pos2, true, 0.5, default_rot.y, portal_rot.y-default_rot.y)
        tp_player = 5
    end
    time = time + 1
    local day_time = world.getLunarTime()%24000
    sky = 0
    if day_time >= 0 and day_time < 12000 then
        sky = 15
    elseif day_time > 14000 and day_time < 22000 then
        sky = 4
    elseif day_time >= 12000 and day_time <= 14000 then
        sky = lerp(15, 4, (day_time-12000)/2000)
    elseif day_time >= 22000 and day_time <= 24000 then
        sky = lerp(4, 15, (day_time-22000)/2000)
    end
    for a = 1, 10 do
        portal_gun(true)
    end
    --action wheel and portal outline color
    local color1 = vectors.of({0, (math.cos(time*0.25)*0.5+0.5)*0.4+0.6, 1})
    model.NO_PARENT[1].outline[1].setColor(color1)
    color1 = vectors.of({0, (math.cos(time*0.25+0.5)*0.5+0.5)*0.4+0.6, 1})
    model.NO_PARENT[1].outline[2].setColor(color1)
    color1 = vectors.of({0, (math.cos(time*0.25+1)*0.5+0.5)*0.4+0.6, 1})
    model.NO_PARENT[1].outline[3].setColor(color1)
    color1 = "#"..string.format("%x", color1.x*255)..string.format("%x", color1.y*255)..string.format("%x", color1.z*255)
    local color2 = vectors.of({1, (math.sin(time*0.25)*0.5+0.5)*0.5+0.25, 0.07})
    model.NO_PARENT[513].outline2[1].setColor(color2)
    color2 = vectors.of({1, (math.sin(time*0.25+0.5)*0.5+0.5)*0.5+0.25, 0.07})
    model.NO_PARENT[513].outline2[2].setColor(color2)
    color2 = vectors.of({1, (math.sin(time*0.25+1)*0.5+0.5)*0.5+0.25, 0.07})
    model.NO_PARENT[513].outline2[3].setColor(color2)
    color2 = "#"..string.format("%x", color2.x*255)..string.format("%x", color2.y*255)..string.format("%x", color2.z*255)
    action_wheel.SLOT_1.setTitle('[{"text":"P","color":"'..color1..'"},{"text":"ortal ","color":"white"},{"text":"G","color":"'..color1..'"},{"text":"un","color":"white"}]')
    action_wheel.SLOT_2.setTitle('[{"text":"P","color":"'..color2..'"},{"text":"ortal ","color":"white"},{"text":"G","color":"'..color2..'"},{"text":"un","color":"white"}]')
    action_wheel.SLOT_3.setTitle('[{"text":"Remove "},{"text":"P","color":"'..color1..'"},{"text":"ortal","color":"white"},{"text":"s","color":"'..color2..'"}]')
    --render pixels
    if render_type == "tick" then
        render_pixels()
    end
end

function world_render(delta)
    --local time = world.getTime()+delta
    animate_outline(time+delta)
    if render_type == "render" then
        render_pixels()
    end
end

--animate outline
function animate_outline(time)
    for i, v in pairs({
        model.NO_PARENT[1].outline[1],
        model.NO_PARENT[1].outline[2],
        model.NO_PARENT[1].outline[3],
        model.NO_PARENT[513].outline2[1],
        model.NO_PARENT[513].outline2[2],
        model.NO_PARENT[513].outline2[3]
    }) do
        local x = i*25
        v.setPos({math.cos((time+x)*0.1)*0.2, math.sin((time+x)*0.2+64)*0.2, (i%3-1.5)*0.1})
    end
end

--set pixels
function render_pixels()
    --pause camera
    if not pause then
        pos = renderer.getCameraPos()
    end
    --some useful variables
    local scale_vector = vectors.of({-16, -16, 16})
    local invalid_texture_color = vectors.of({time*0.01%1, 0.8, 1})
    invalid_texture_color = vectors.hsvToRGB(invalid_texture_color)
    --limit pixels
    render_times = render_times+1
    pixels_limit_offset = render_times%pixels_limit
    --if only 1 portal exist
    if block_pos.w == 1 and portal_pos.w == 1 then
        model.NO_PARENT.setEnabled(false)
    elseif block_pos.w == 1 or portal_pos.w == 1 then
        model.NO_PARENT.setEnabled(true)
        model.NO_PARENT[248].setShader("EndPortal")
        model.NO_PARENT[760].setShader("EndPortal")
        model.NO_PARENT[1].pixel.setEnabled(false)
        model.NO_PARENT[513].pixel.setEnabled(false)
    else
        model.NO_PARENT.setEnabled(true)
        model.NO_PARENT[248].setShader("None")
        model.NO_PARENT[760].setShader("None")
        model.NO_PARENT[1].pixel.setEnabled(true)
        model.NO_PARENT[513].pixel.setEnabled(true)
    end
    --update pixels
    for i, v in pairs(model.NO_PARENT) do
        if type(v) == "table" and (pixels_limit_offset+tonumber(i))%pixels_limit == 0 then
            local block_pos = block_pos
            local portal_pos = portal_pos
            local portal_rot = portal_rot
            local default_rot = default_rot
            local pixel_offset = pixel_offset[i]
            local portal_pixel_offset = pixel_offset
            if tonumber(i) > 512 then
                block_pos, portal_pos = portal_pos, block_pos
                portal_rot, default_rot = default_rot, portal_rot
            end
            local rot = math.rad(default_rot.y)
            local rad_90 = math.rad(90)
            if block_pos.w == 1 or (portal_pos.w == 1 and tonumber(i)%512 ~= 248) then
                if v.pixel then
                    local pixel_offset = vectors.of({
                        math.cos(rot+rad_90)*pixel_offset.x+math.sin(rot+rad_90)*pixel_offset.z, --x
                        pixel_offset.y,
                        math.cos(rot)*pixel_offset.x+math.sin(rot)*pixel_offset.z --z
                    })
                    v.setPos(pixel_offset+block_pos*scale_vector)
                    v.setScale({pixel_scale, pixel_scale, pixel_scale})
                    v.setRot(default_rot)
                    v.setEnabled(true)
                    goto contine
                else
                    v.setEnabled(false)
                    goto contine
                end
            else
                v.setEnabled(true)
            end
            if portal_pos.w == 1 then
                local pixel_offset = pixel_offset + vectors.of({0, -0.5, 0.5})
                v.setEnabled(true)
                v.setPos(vectors.of({
                    math.cos(rot+rad_90)*pixel_offset.x+math.sin(rot+rad_90)*pixel_offset.z, --x
                    pixel_offset.y,
                    math.cos(rot)*pixel_offset.x+math.sin(rot)*pixel_offset.z --z
                })+block_pos*scale_vector)
                if tonumber(i) > 512 then
                    v.setScale({pixel_scale*16, pixel_scale*32, pixel_scale*16})
                else
                    v.setScale({pixel_scale*-16, pixel_scale*32, pixel_scale*-16})
                end
                v.setRot(default_rot)
                v.setColor({1, 1, 1})
                goto contine
            end
            pixel_offset = vectors.of({
                math.cos(rot+rad_90)*pixel_offset.x+math.sin(rot+rad_90)*pixel_offset.z, --x
                pixel_offset.y,
                math.cos(rot)*pixel_offset.x+math.sin(rot)*pixel_offset.z --z
            })
            local rot = math.rad(portal_rot.y)
            portal_pixel_offset = vectors.of({
                math.cos(rot+rad_90)*portal_pixel_offset.x+math.sin(rot+rad_90)*portal_pixel_offset.z, --x
                pixel_offset.y,
                math.cos(rot)*portal_pixel_offset.x+math.sin(rot)*portal_pixel_offset.z --z
            })
            --rot_dif = portal_rot.y-default_rot.y
            --set block pos and get direction
            local pixel_pos = block_pos-vectors.of({pixel_offset.x/16, pixel_offset.y/16, pixel_offset.z/-16})
            local xz_distance = pixel_pos - pos
            xz_distance = math.sqrt(xz_distance.x*xz_distance.x+xz_distance.z*xz_distance.z)
            local rot = {
            math.atan((pixel_pos.y-pos.y)/xz_distance)*-60
            ,
            math.atan((pos.x - pixel_pos.x)/(pos.z - pixel_pos.z))*60
            }
            if pos.z <= pixel_pos.z then
                rot[2] = rot[2]-180
            end
            rot[2] = rot[2]+portal_rot.y-default_rot.y
            --set block pos again but this time for destination
            pixel_pos = portal_pos-vectors.of({portal_pixel_offset.x/16, portal_pixel_offset.y/16, portal_pixel_offset.z/-16})
            local distance = 0
            local light = world.getLightLevel(pixel_pos)
            local void = false
            --fix rotation
            rot[1] = rot[1]*-1
            rot[2] = rot[2]*-1-90
            --ray tracing/casting
            local move_coords = vectors.of({
                math.cos(math.rad(rot[2]))*math.cos(math.rad(rot[1]))*move_distance
                ,
                math.sin(math.rad(rot[1]))*move_distance
                ,
                math.sin(math.rad(rot[2]))*math.cos(math.rad(rot[1]))*move_distance
            })
            local move_by = 1/(move_blocks/move_distance) --distance it should move
            for a = 1, move_blocks/move_distance do
                --move
                distance = distance + move_by
                pixel_pos = pixel_pos + move_coords
                --detect block
                local block = world.getBlockState(pixel_pos)
                if blockIsSolid(block) then
                local color = getBlockColor(block)
                    distance = distance*-1
                    if color == nil then
                        local color = math.sin((time*0.5+i*3.3)*0.25)*0.5+0.5
                        v.setColor(invalid_texture_color*color)
                    else
                        v.setColor({color[1], color[2], color[3]})
                    end
                    if block.name == "minecraft:void_air" then
                        void = true
                    end 
                    break
                else
                    light = world.getLightLevel(pixel_pos)
                end
            end
            --add light
            light = light/15
            v.setColor(v.getColor()*light)
            --set sky color
            if distance > 0 or void then
                color = block_colors["sky"]
                local sky = (sky-4)/11
                v.setColor({color[1]*sky, color[2]*sky, color[3]*sky})
            end
            --special render type
            if render_pos then
                local distance = math.abs(distance)
                local pixel_scale = pixel_scale*0.8*(move_blocks/16)
                v.setScale({distance*16*pixel_scale, distance*16*pixel_scale, distance*16*pixel_scale})
                local pixel_pos = portal_pos-vectors.of({portal_pixel_offset.x/16, portal_pixel_offset.y/16, portal_pixel_offset.z/-16})
                v.setRot({rot[1]*-1, rot[2]*-1+90})
                local move_distance = math.max(distance*move_blocks-1.4, 0)
                local pixel_pos = pixel_pos+vectors.of({
                    math.cos(math.rad(rot[2]))*math.cos(math.rad(rot[1]))*move_distance
                    ,
                    math.sin(math.rad(rot[1]))*move_distance
                    ,
                    math.sin(math.rad(rot[2]))*math.cos(math.rad(rot[1]))*move_distance
                })
                v.setPos((block_pos-pixel_pos)*vectors.of({16, 16, -16}))
            else
                v.setPos(pixel_offset)
                v.setScale({pixel_scale, pixel_scale, pixel_scale})
                v.setRot(default_rot)
            end
            v.setPos(v.getPos()+block_pos*scale_vector)
            if tonumber(i) % 512 == 1 then
                v.pixel.setColor(v.getColor())
                v.setColor({1, 1, 1})
            end
            ::contine::
        end
    end
end

--commands
function onCommand(text)
    text_command = text
    local pcall_cmd = pcall(function() --pcall chat command

    local text = text_command
    local text_table = {""}
    local letter
    for i = 2, text:len() do
        letter = string.sub(text, i, i)
        if letter == " " then
            text_table[#text_table+1] = ""
        else
            text_table[#text_table] = text_table[#text_table]..letter
        end
    end
    if text_table[1] == "help" then
        log("commands:")
        log(".save (name, not required)")
        log(".load (name, not required)")
        log(".rot (screen, portal or none) (rotation)")
        log(".pos (screen, portal or none)")
        log(".scale (scale)")
        log(".move (speed or blocks) (number)")
        log(".render (true or false)")
        log(".pixels (number)")
        log(".type (tick or render)")
        log(".stop")
        log(".start")
        log(".pause")
        log(".info")
    elseif text_table[1] == "save" then
        local save_data = {portal = portal_pos, block = block_pos, rot = default_rot, scale = pixel_scale, portal_rot = portal_rot}
        if text_table[2] then
            data.save("rtx"..text_table[2], save_data)
        else
            data.save("rtx", save_data)
        end
    elseif text_table[1] == "load" then
        if text_table[2] then
            load_saved_data(data.load("rtx"..text_table[2]))
        else
            load_saved_data(data.load("rtx"))
        end
    elseif text_table[1] == "rot" then
        if tonumber(text_table[2]) ~= nil then
            update_pixels_pos(tonumber(text_table[2]))
            portal_rot = vectors.of({0, tonumber(text_table[2]), 0})
        elseif text_table[2] == "screen" then
            update_pixels_pos(tonumber(text_table[3]))
        elseif text_table[2] == "portal" then
            portal_rot = vectors.of({0, tonumber(text_table[3]), 0})
        end
    elseif text_table[1] == "pos" then
        if text_table[2] == "portal" then
            portal_pos = player.getPos()
        elseif text_table[2] == "screen" then
            block_pos = player.getPos()
        else
            portal_pos = player.getPos()
            block_pos = player.getPos()
        end
    elseif text_table[1] == "scale" then
        pixel_scale = tonumber(text_table[2])
        update_pixels_pos(default_rot.y)
    elseif text_table[1] == "move" then
        if text_table[2] == "speed" then
            move_distance = tonumber(text_table[3])
        elseif text_table[2] == "blocks" then
            move_blocks = tonumber(text_table[3])
        end
    elseif text_table[1] == "render" then
        if text_table[2] == "true" then
            render_pos = true
        else
            render_pos = false
        end
    elseif text_table[1] == "pixels" then
        pixels_limit = tonumber(text_table[2])
    elseif text_table[1] == "type" then
        if text_table[2] == "tick" then
            render_type = "tick"
        elseif text_table[2] == "render" then
            render_type = "render"
        end
    elseif text_table[1] == "stop" then
        pause = true
    elseif text_table[1] == "start" then
        pause = false
    elseif text_table[1] == "pause" then
        pause = not pause
    elseif text_table[1] == "info" then
        log(world.getLightLevel(player.getPos()))
        log(world.getBlockState(player.getPos()).name)
    else
        text_command = nil
    end

    end) --end of pcall

    if not pcall_cmd then
        log("there was error while running that command")
    elseif text_command == nil then
        log("invalid command")
    end
end