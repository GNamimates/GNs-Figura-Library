lastPosition = vectors.of{}
position = vectors.of{}

model.gravityGun.thicc.setTexture("Skin")
model.gravityGun.thicc.setExtraTexEnabled(false)
model.gravityGun.slim.setTexture("Skin")
model.gravityGun.slim.setExtraTexEnabled(false)

vanilla_model.RIGHT_ARM.setEnabled(false)
vanilla_model.RIGHT_SLEEVE.setEnabled(false)
vanilla_model.LEFT_ARM.setEnabled(false)
vanilla_model.LEFT_SLEEVE.setEnabled(false)

function player_init()
    if player.getModelType() == "slim" then
        model.gravityGun.thicc.setEnabled(false)
        model.gravityGun.slim.setEnabled(true)
        
    else
        model.gravityGun.thicc.setEnabled(true)
        model.gravityGun.slim.setEnabled(false)
        
    end
end

count = 3
workspace = {
    {
        type="minecraft:oak_wood",
        pos=vectors.of{},
        scl=vectors.of{1,1,1},
    },
    {
        type="minecraft:oak_planks",
        pos=vectors.of{1,1,1},
        scl=vectors.of{1,1,1},
    },
    {
        type="minecraft:glass",
        pos=vectors.of{3,1,1},
        scl=vectors.of{1,1,1},
    }
}
mode = 0
axis = 0
selectedID = 1

grabDistance = 3
blockToPlaceName = "minecraft:glass"

chat.setFiguraCommandPrefix("!")
function onCommand(cmd)
    local given = string.sub(cmd,2,999)
    if pcall(item_stack.createItem,given) then
        if item_stack.createItem(given).isBlockItem() then
            blockToPlaceName = given
            log('§asetted insert block to: "'..given..'"')
            return
        end
        log('§c"'..given..'" isnt a block')
    else
        log('§cInvalid type block: "'..given..'"')
    end
    
end

swapMode = keybind.newKey("Swap Mode","TAB")
alt = keybind.newKey("altKey","LEFT_ALT")
insert = keybind.newKey("insert","INSERT")
delete = keybind.newKey("delete","DELETE")
primary = keybind.newKey("primary","MOUSE_BUTTON_2")
lastPrimary = false

offsetSelection = vectors.of{}
dynamicSyncTime = 0
dynamicSyncWaitTime = 2


function refreashRenderTasks()
    model.NO_PARENT_WORKSPACE.clearAllRenderTasks()
    for index, current in pairs(workspace) do
        model.NO_PARENT_WORKSPACE.addRenderTask(
            "BLOCK",index,current.type,false,
            current.pos*vectors.of{-16,-16,16},
            vectors.of{0,0,0},
            current.scl)
    end
end

function switchMode(type)
    mode = type
    if mode == 0 then
        log("switched to §dMove mode")
    end
    if mode == 1 then
        log("switched to §aScale mode")
    end
end

function player_init()
    refreashRenderTasks()
end

function tick()
    if client.isHost() then
        local cursorPos = (player.getPos()+vectors.of{0,player.getEyeHeight()}+player.getLookDir()*grabDistance)
        if primary.isPressed() ~= lastPrimary then
            if primary.isPressed() then
                if mode == 0 then--=================================================================================MOVE MODE
                    local selected = findSelected(renderer.getCameraPos(),player.getLookDir()*0.5)
                    if selected then
                        selectedID = selected
                        offsetSelection = (workspace[selected].pos-cursorPos)
                    else
                        selectedID = 0
                    end
                    refreashRenderTasks()
                end
                if mode == 1 then
                    if workspace[selectedID] then
                        offsetSelection = (workspace[selectedID].pos-cursorPos)
                    end
                end
            end
        end

        lastPrimary = primary.isPressed()
        if primary.isPressed() then
            if next(workspace) and selectedID ~= 0 then
                if mode == 0 then
                    workspace[selectedID].pos = (cursorPos-offsetSelection*-1)
                    model.NO_PARENT_WORKSPACE.getRenderTask(selectedID).setPos((workspace[selectedID].pos)*vectors.of{-16,-16,16})
                    dynamicSyncTime = dynamicSyncTime + 1
                    
                    if dynamicSyncTime > dynamicSyncWaitTime then
                        dynamicSyncTime = 0
                        ping.syncPos({selectedID,cursorPos-offsetSelection*-1})
                    end
                end
                if mode == 1 then
                    workspace[selectedID].scl = (workspace[selectedID].pos-cursorPos)*vectors.of{1,-1,1}
                    model.NO_PARENT_WORKSPACE.getRenderTask(selectedID).setScale((workspace[selectedID].scl))

                    if dynamicSyncTime > dynamicSyncWaitTime then
                        dynamicSyncTime = 0
                        ping.syncScl({selectedID,(workspace[selectedID].pos-cursorPos)*vectors.of{1,-1,1}})
                    end
                end
            end
        end

        if delete.wasPressed() then
            if count ~= 0 then
                table.remove(workspace,selectedID)
                count = count - 1
                if count == 0 then
                    workspace = {}
                end
                log("§cdeleted: "..selectedID)
                
                selectedID = math.clamp(selectedID,1,count)
                timeSinceLastSync = syncTime*20
                refreashRenderTasks()
            end
        end
        if insert.wasPressed() then
            log("§aInserted: "..blockToPlaceName)
            timeSinceLastSync = syncTime*20
            count = count + 1
            table.insert(workspace,{
                type=blockToPlaceName,
                pos=cursorPos+vectors.of{0.5,-0.5,0.5},
                scl=vectors.of{1,1,1},
            })
            refreashRenderTasks()
        end

        --lastPosition = position
        --position = (player.getLookDir()*5)+player.getPos()+vectors.of{0,player.getEyeHeight(),0}
        if swapMode.wasPressed() then
            switchMode((mode+1)%2)
        end
        if alt.isPressed() then
            selectedID = ((selectedID + client.getMouseScroll()-1) % count-1) + 2
        end
    end
end

function world_render(delta)
    if next(workspace) and selectedID ~= 0 and client.isHost() then
        model.NO_PARENT_WORKSPACE.SELECTION.setEnabled(true)
        model.NO_PARENT_WORKSPACE.SELECTION.setPos(workspace[selectedID].pos*vectors.of{-16,-16,16})
        model.NO_PARENT_WORKSPACE.SELECTION.setScale(workspace[selectedID].scl)
    else
        model.NO_PARENT_WORKSPACE.SELECTION.setEnabled(false)
    end
    model.gravityGun.setRot({-player.getRot().x})
    model.NO_PARENT_WORKSPACE.setPos(vectors.lerp(lastPosition,position,delta)*vectors.of{-16,-16,16})
end

--============ [ OTHER ] ===========--
function angleToDir(direction)
    if type(direction) == "table" then
        direction = vectors.of{direction}
    end
    return vectors.of({
        math.cos(math.rad(direction.y+90))*math.cos(math.rad(direction.x)),
        math.sin(math.rad(-direction.x)),
        math.sin(math.rad(direction.y+90))*math.cos(math.rad(direction.x))
    })
end

function findSelected(pos,vel)
    local rayPos = pos
    for step = 1, 10, 1 do
        rayPos = rayPos + vel
        for key, c in pairs(workspace) do
            local lowest = vectors.of{lowest(c.pos.x,c.pos.x-c.scl.x),lowest(c.pos.y,c.pos.y+c.scl.y),lowest(c.pos.z,c.pos.z-c.scl.z)}
            local highest = vectors.of{highest(c.pos.x,c.pos.x-c.scl.x),highest(c.pos.y,c.pos.y+c.scl.y),highest(c.pos.z,c.pos.z-c.scl.z)}
            if 
            rayPos.x < highest.x and rayPos.x > lowest.x and
            rayPos.y > lowest.y and rayPos.y < highest.y and
            rayPos.z < highest.z and rayPos.z > lowest.z then
                return key
            end
        end
    end
end
syncCount = 0
syncTime = 3
batchTime = 0.3
timeSinceLastSync = syncTime*20
batch = {}
isSyncing = false
batchID = 0

function tick()
    if not isSyncing then
        timeSinceLastSync = timeSinceLastSync + 1
        if timeSinceLastSync > syncTime*20 then
            timeSinceLastSync = 0
            isSyncing = true
            ping.newBatch(count)
            batchID = 0
        end
    else
        timeSinceLastSync = timeSinceLastSync + 1
        if timeSinceLastSync > batchTime*20 then
            timeSinceLastSync = 0
            batchID = batchID + 1
            if batchID > count then
                ping.applyBatch()
                isSyncing = false
                return
            end
            ping.batch({batchID,workspace[batchID]})
        end
    end
end

ping.newBatch = function (howMany)
    batch = {}
end

ping.batch = function (data)
    if not client.isHost() then
        table.insert(batch,data[2])
    end
end

ping.applyBatch = function ()
    syncCount = syncCount + 1
    if not client.isHost() then
        workspace = batch
    end
    refreashRenderTasks()
    if client.isHost() then
        sound.playSound("entity.item.pickup",player.getPos(),{0.01,0.1})
    end
end

ping.syncPos = function (data)
    if workspace[data[1]] then
        workspace[data[1]].pos = data[2]
    end
end

ping.syncScl = function (data)
    if workspace[data[1]] then
        workspace[data[1]].scl = data[2]
    end
end

function lowest(x,y)
    if x > y then
        return y
    else
        return x
    end
end

function highest(x,y)
    if x > y then
        return x
    else
        return y
    end
end
