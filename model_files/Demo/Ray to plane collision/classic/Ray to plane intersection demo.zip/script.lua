--[[--====================================================================---------
░██████╗░███╗░░██╗░█████╗░███╗░░░███╗██╗███╗░░░███╗░█████╗░████████╗███████╗░██████╗
██╔════╝░████╗░██║██╔══██╗████╗░████║██║████╗░████║██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░██╗░██╔██╗██║███████║██╔████╔██║██║██╔████╔██║███████║░░░██║░░░█████╗░░╚█████╗░
██║░░╚██╗██║╚████║██╔══██║██║╚██╔╝██║██║██║╚██╔╝██║██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚██████╔╝██║░╚███║██║░░██║██║░╚═╝░██║██║██║░╚═╝░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚═════╝░╚═╝░░╚══╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═╝╚═╝░░░░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░
--=================================================================================--]]

pos = vectors.of{}
towrld = vectors.of{-16,-16,16}

idrot = {
    {90,-90,0},
    {180,0,0},
    {90,180,0},
    {90,90,0},
    {0,0,0},
    {90,0,0},
}
idnorm = {
    {1,0,0},
    {0,-1,0},
    {0,0,-1},
    {1,0,0},
    {0,1,0},
    {0,0,1},
}

idinvnorm = {
    {0,1,0},
    {1,0,0},
    {0,1,0},
    {0,1,0},
    {1,0,0},
    {0,1,0},
}

drag = keybind.newKey("Extrude","MOUSE_BUTTON_2")

dist = 0
stardragPos = nil
draggingPos = nil
dragOffset = nil
draggingAxis = 0
isDragging = false
wasDragging = false
blockPos = nil
block_state = nil

function world_render(delta)
    pos = player.getPos(delta)+vectors.of{0,player.getEyeHeight()}
    local ray = renderer.raycastBlocks(pos,pos+player.getLookDir()*10,"VISUAL","NONE")
    if ray then
        if not isDragging then
            blockPos = ray.pos+player.getLookDir()*0.001
            dragOffset = blockPos-vectors.of{math.floor(blockPos.x),math.floor(blockPos.y),math.floor(blockPos.z)}
            local pos, normal = getClosestFace(blockPos) 
            blockPos = vectors.of{math.floor(blockPos.x),math.floor(blockPos.y),math.floor(blockPos.z)}
            draggingAxis = normal
            model.NO_PARENT.setPos(pos*towrld)
            model.NO_PARENT.setRot(idrot[normal+1])
        end
    end
    isDragging = drag.isPressed()
    if wasDragging ~= isDragging then
        if ray then
            if isDragging then
                block_state = world.getBlockState(blockPos).name
                --print(dist)
                stardragPos = blockPos * 1
                if draggingAxis == 0 then
                    dist = blockPos.y
                elseif draggingAxis == 1 then
                    dist = blockPos.x
                elseif draggingAxis == 2 then
                    dist = blockPos.y
                elseif draggingAxis == 3 then
                    dist = blockPos.y
                elseif draggingAxis == 4 then
                    dist = blockPos.x
                elseif draggingAxis == 5 then
                    dist = blockPos.y
                end
                if block_state == "minecraft:air" then
                    block_state = nil
                else
                    chat.sendMessage("/setblock "..tostring(blockPos.x).." "..tostring(blockPos.y).." "..tostring(blockPos.z).." air")
                    
                    model.NO_PARENT_MOVING.addRenderTask("BLOCK","moving",block_state,false,{-16,0,16})
                end
            end
        end
        if not isDragging and draggingPos then
            draggingPos = vectors.of{math.floor(draggingPos.x+0.5),math.floor(draggingPos.y+0.5),math.floor(draggingPos.z+0.5)}
            model.NO_PARENT_MOVING.clearAllRenderTasks()
            if block_state then
                chat.sendMessage("/setblock "..tostring(draggingPos.x).." "..tostring(draggingPos.y).." "..tostring(draggingPos.z).." "..block_state)
            end
            block_state = nil
        end
        wasDragging = isDragging
    end
    if isDragging and block_state ~= nil then
        --logTable(idinvnorm[draggingAxis+1])
        
        draggingPos = rayToPlane({dir=player.getLookDir(),origin=player.getPos(delta)+vectors.of{0,player.getEyeHeight()}-(vectors.of{dragOffset})},{normal=vectors.of(idinvnorm[draggingAxis+1]),dist=dist})
        draggingPos = draggingPos
        draggingPos = vectors.of{
            math.lerp(stardragPos.x,draggingPos.x,math.abs(idnorm[draggingAxis+1][1])),
            math.lerp(stardragPos.y,draggingPos.y,math.abs(idnorm[draggingAxis+1][2])),
            math.lerp(stardragPos.z,draggingPos.z,math.abs(idnorm[draggingAxis+1][3])),
        }
        if draggingPos then
            model.NO_PARENT_MOVING.setPos(draggingPos*towrld)
        end
    end
end

function raycast(pos,dir)
    local margin = 0.001
    local ray1 = renderer.raycastBlocks(pos,pos+dir*100,"VISUAL","NONE")
    local offset = vectors.of{margin,margin,margin}
    local ray2 = renderer.raycastBlocks(pos+offset,pos+dir*100+offset,"VISUAL","NONE")
    if ray1 and ray2 then--lazy check lmao
        pos = ray1.pos
        local diff = ray1.pos-ray2.pos
        if math.abs(diff.x) < math.abs(diff.y) and math.abs(diff.x) < math.abs(diff.z) then
            return vectors.of{1,0,0},1, pos+dir*margin, dir
        elseif math.abs(diff.y) < math.abs(diff.x) and math.abs(diff.y) < math.abs(diff.z) then
            return vectors.of{0,1,0},2, pos+dir*margin, dir
        else
            return vectors.of{0,0,1},3, pos+dir*margin, dir
        end
    end
end

function rayToPlane(ray,plane)
    local denom = vectors.dot(plane.normal,ray.dir)
    if denom == 0 then
        return nil
    end
    local t = -vectors.dot(plane.normal,ray.origin)+plane.dist
    t = t/denom
    return ray.origin+ray.dir*t
end

function vectors.dot(a,b)
    return a.x*b.x+a.y*b.y+a.z*b.z
end

function getClosestFace(pos)
    local blockPos = vectors.of{math.floor(pos.x),math.floor(pos.y),math.floor(pos.z)}
    local collision = world.getBlockState(pos).getCollisionShape()--getting block collision
    local modBlock = vectors.of({pos.x-math.floor(pos.x),pos.y-math.floor(pos.y),pos.z-math.floor(pos.z)})--block modulo position
    local whoClosest = 0
    for index, value in ipairs(collision) do--loop through all the collision boxes
        local blockCenter = vectors.of{
            math.lerp(value.x,value.w,0.5),
            math.lerp(value.y,value.t,0.5),
            math.lerp(value.z,value.h,0.5)
        }
        if value.x <= modBlock.x and value.w >= modBlock.x then-- checks if inside the collision box
            if value.y <= modBlock.y and value.t >= modBlock.y then
                if value.z <= modBlock.z and value.h >= modBlock.z then
                    --detected inside the cube
                    local closest = 9999--used to see what is the closes face
                    
                    local currentPoint = pos--for somethin idk
                    --finding the closest surface from the cube
                    if math.abs(value.x-modBlock.x) < closest then
                        closest = math.abs(value.x-modBlock.x)
                        whoClosest = 0
                    end
                    if math.abs(value.y-modBlock.y) < closest then
                        closest = math.abs(value.y-modBlock.y)
                        whoClosest = 1
                    end
                    if math.abs(value.z-modBlock.z) < closest then
                        closest = math.abs(value.z-modBlock.z)
                        whoClosest = 2
                    end
                    
                    if math.abs(value.w-modBlock.x) < closest then
                        closest = math.abs(value.w-modBlock.x)
                        whoClosest = 3
                    end
                    if math.abs(value.t-modBlock.y) < closest then
                        closest = math.abs(value.t-modBlock.y)
                        whoClosest = 4
                    end
                    if math.abs(value.h-modBlock.z) < closest then
                        closest = math.abs(value.h-modBlock.z)
                        whoClosest = 5
                    end
                    pos = vectors.of{blockCenter.x,blockCenter.y,blockCenter.z}+blockPos
                    --snap the closest surfance to the point
                    if whoClosest == 0 then
                        pos.x = math.floor(currentPoint.x)+value.x
                    end
                    if whoClosest == 1 then
                        pos.y = math.floor(currentPoint.y)+value.y
                    end
                    if whoClosest == 2 then
                        pos.z = math.floor(currentPoint.z)+value.z
                    end
                    if whoClosest == 3 then
                        pos.x =  math.floor(currentPoint.x)+value.w
                    end
                    if whoClosest == 4 then
                        pos.y = math.floor(currentPoint.y)+value.t
                    end
                    if whoClosest == 5 then
                        pos.z =  math.floor(currentPoint.z)+value.h
                    end
                end
            end
        end
    end
    return pos, whoClosest
end