position = {}
velocity = {}
targetRotation = {}
distanceWalked = {}
distVelocity = {}
offsetTarget = {}
wanderTimer = {}

agent1 = {
    base = model.NO_PARENT.agent1,
    B = model.NO_PARENT.agent1.B1,
    H = model.NO_PARENT.agent1.H1,
    LA = model.NO_PARENT.agent1.B1.LA1,
    RA = model.NO_PARENT.agent1.B1.RA1,
    LL = model.NO_PARENT.agent1.B1.LL1,
    RL = model.NO_PARENT.agent1.B1.RL1,}agent2 = {
    base = model.NO_PARENT.agent2,
    B = model.NO_PARENT.agent2.B2,
    H = model.NO_PARENT.agent2.H2,
    LA = model.NO_PARENT.agent2.B2.LA2,
    RA = model.NO_PARENT.agent2.B2.RA2,
    LL = model.NO_PARENT.agent2.B2.LL2,
    RL = model.NO_PARENT.agent2.B2.RL2,}agent3 = {
    base = model.NO_PARENT.agent3,
    B = model.NO_PARENT.agent3.B3,
    H = model.NO_PARENT.agent3.H3,
    LA = model.NO_PARENT.agent3.B3.LA3,
    RA = model.NO_PARENT.agent3.B3.RA3,
    LL = model.NO_PARENT.agent3.B3.LL3,
    RL = model.NO_PARENT.agent3.B3.RL3,}agent4 = {
    base = model.NO_PARENT.agent4,
    B = model.NO_PARENT.agent4.B4,
    H = model.NO_PARENT.agent4.H4,
    LA = model.NO_PARENT.agent4.B4.LA4,
    RA = model.NO_PARENT.agent4.B4.RA4,
    LL = model.NO_PARENT.agent4.B4.LL4,
    RL = model.NO_PARENT.agent4.B4.RL4,}agent5 = {
    base = model.NO_PARENT.agent5,
    B = model.NO_PARENT.agent5.B5,
    H = model.NO_PARENT.agent5.H5,
    LA = model.NO_PARENT.agent5.B5.LA5,
    RA = model.NO_PARENT.agent5.B5.RA5,
    LL = model.NO_PARENT.agent5.B5.LL5,
    RL = model.NO_PARENT.agent5.B5.RL5,}agent6 = {
    base = model.NO_PARENT.agent6,
    B = model.NO_PARENT.agent6.B6,
    H = model.NO_PARENT.agent6.H6,
    LA = model.NO_PARENT.agent6.B6.LA6,
    RA = model.NO_PARENT.agent6.B6.RA6,
    LL = model.NO_PARENT.agent6.B6.LL6,
    RL = model.NO_PARENT.agent6.B6.RL6,}agent7 = {
    base = model.NO_PARENT.agent7,
    B = model.NO_PARENT.agent7.B7,
    H = model.NO_PARENT.agent7.H7,
    LA = model.NO_PARENT.agent7.B7.LA7,
    RA = model.NO_PARENT.agent7.B7.RA7,
    LL = model.NO_PARENT.agent7.B7.LL7,
    RL = model.NO_PARENT.agent7.B7.RL7,}agent8 = {
    base = model.NO_PARENT.agent8,
    B = model.NO_PARENT.agent8.B8,
    H = model.NO_PARENT.agent8.H8,
    LA = model.NO_PARENT.agent8.B8.LA8,
    RA = model.NO_PARENT.agent8.B8.RA8,
    LL = model.NO_PARENT.agent8.B8.LL8,
    RL = model.NO_PARENT.agent8.B8.RL8,}agent9 = {
    base = model.NO_PARENT.agent9,
    B = model.NO_PARENT.agent9.B9,
    H = model.NO_PARENT.agent9.H9,
    LA = model.NO_PARENT.agent9.B9.LA9,
    RA = model.NO_PARENT.agent9.B9.RA9,
    LL = model.NO_PARENT.agent9.B9.LL9,
    RL = model.NO_PARENT.agent9.B9.RL9,}agent10 = {
    base = model.NO_PARENT.agent10,
    B = model.NO_PARENT.agent10.B10,
    H = model.NO_PARENT.agent10.H10,
    LA = model.NO_PARENT.agent10.B10.LA10,
    RA = model.NO_PARENT.agent10.B10.RA10,
    LL = model.NO_PARENT.agent10.B10.LL10,
    RL = model.NO_PARENT.agent10.B10.RL10,}agent11 = {
    base = model.NO_PARENT.agent11,
    B = model.NO_PARENT.agent11.B11,
    H = model.NO_PARENT.agent11.H11,
    LA = model.NO_PARENT.agent11.B11.LA11,
    RA = model.NO_PARENT.agent11.B11.RA11,
    LL = model.NO_PARENT.agent11.B11.LL11,
    RL = model.NO_PARENT.agent11.B11.RL11,}agent12 = {
    base = model.NO_PARENT.agent12,
    B = model.NO_PARENT.agent12.B12,
    H = model.NO_PARENT.agent12.H12,
    LA = model.NO_PARENT.agent12.B12.LA12,
    RA = model.NO_PARENT.agent12.B12.RA12,
    LL = model.NO_PARENT.agent12.B12.LL12,
    RL = model.NO_PARENT.agent12.B12.RL12,}agent13 = {
    base = model.NO_PARENT.agent13,
    B = model.NO_PARENT.agent13.B13,
    H = model.NO_PARENT.agent13.H13,
    LA = model.NO_PARENT.agent13.B13.LA13,
    RA = model.NO_PARENT.agent13.B13.RA13,
    LL = model.NO_PARENT.agent13.B13.LL13,
    RL = model.NO_PARENT.agent13.B13.RL13,}agent14 = {
    base = model.NO_PARENT.agent14,
    B = model.NO_PARENT.agent14.B14,
    H = model.NO_PARENT.agent14.H14,
    LA = model.NO_PARENT.agent14.B14.LA14,
    RA = model.NO_PARENT.agent14.B14.RA14,
    LL = model.NO_PARENT.agent14.B14.LL14,
    RL = model.NO_PARENT.agent14.B14.RL14,}agent15 = {
    base = model.NO_PARENT.agent15,
    B = model.NO_PARENT.agent15.B15,
    H = model.NO_PARENT.agent15.H15,
    LA = model.NO_PARENT.agent15.B15.LA15,
    RA = model.NO_PARENT.agent15.B15.RA15,
    LL = model.NO_PARENT.agent15.B15.LL15,
    RL = model.NO_PARENT.agent15.B15.RL15,}agent16 = {
    base = model.NO_PARENT.agent16,
    B = model.NO_PARENT.agent16.B16,
    H = model.NO_PARENT.agent16.H16,
    LA = model.NO_PARENT.agent16.B16.LA16,
    RA = model.NO_PARENT.agent16.B16.RA16,
    LL = model.NO_PARENT.agent16.B16.LL16,
    RL = model.NO_PARENT.agent16.B16.RL16,}agent17 = {
    base = model.NO_PARENT.agent17,
    B = model.NO_PARENT.agent17.B17,
    H = model.NO_PARENT.agent17.H17,
    LA = model.NO_PARENT.agent17.B17.LA17,
    RA = model.NO_PARENT.agent17.B17.RA17,
    LL = model.NO_PARENT.agent17.B17.LL17,
    RL = model.NO_PARENT.agent17.B17.RL17,}agent18 = {
    base = model.NO_PARENT.agent18,
    B = model.NO_PARENT.agent18.B18,
    H = model.NO_PARENT.agent18.H18,
    LA = model.NO_PARENT.agent18.B18.LA18,
    RA = model.NO_PARENT.agent18.B18.RA18,
    LL = model.NO_PARENT.agent18.B18.LL18,
    RL = model.NO_PARENT.agent18.B18.RL18,}agent19 = {
    base = model.NO_PARENT.agent19,
    B = model.NO_PARENT.agent19.B19,
    H = model.NO_PARENT.agent19.H19,
    LA = model.NO_PARENT.agent19.B19.LA19,
    RA = model.NO_PARENT.agent19.B19.RA19,
    LL = model.NO_PARENT.agent19.B19.LL19,
    RL = model.NO_PARENT.agent19.B19.RL19,}agent20 = {
    base = model.NO_PARENT.agent20,
    B = model.NO_PARENT.agent20.B20,
    H = model.NO_PARENT.agent20.H20,
    LA = model.NO_PARENT.agent20.B20.LA20,
    RA = model.NO_PARENT.agent20.B20.RA20,
    LL = model.NO_PARENT.agent20.B20.LL20,
    RL = model.NO_PARENT.agent20.B20.RL20,}agent21 = {
    base = model.NO_PARENT.agent21,
    B = model.NO_PARENT.agent21.B21,
    H = model.NO_PARENT.agent21.H21,
    LA = model.NO_PARENT.agent21.B21.LA21,
    RA = model.NO_PARENT.agent21.B21.RA21,
    LL = model.NO_PARENT.agent21.B21.LL21,
    RL = model.NO_PARENT.agent21.B21.RL21,}agent22 = {
    base = model.NO_PARENT.agent22,
    B = model.NO_PARENT.agent22.B22,
    H = model.NO_PARENT.agent22.H22,
    LA = model.NO_PARENT.agent22.B22.LA22,
    RA = model.NO_PARENT.agent22.B22.RA22,
    LL = model.NO_PARENT.agent22.B22.LL22,
    RL = model.NO_PARENT.agent22.B22.RL22,}agent23 = {
    base = model.NO_PARENT.agent23,
    B = model.NO_PARENT.agent23.B23,
    H = model.NO_PARENT.agent23.H23,
    LA = model.NO_PARENT.agent23.B23.LA23,
    RA = model.NO_PARENT.agent23.B23.RA23,
    LL = model.NO_PARENT.agent23.B23.LL23,
    RL = model.NO_PARENT.agent23.B23.RL23,}agent24 = {
    base = model.NO_PARENT.agent24,
    B = model.NO_PARENT.agent24.B24,
    H = model.NO_PARENT.agent24.H24,
    LA = model.NO_PARENT.agent24.B24.LA24,
    RA = model.NO_PARENT.agent24.B24.RA24,
    LL = model.NO_PARENT.agent24.B24.LL24,
    RL = model.NO_PARENT.agent24.B24.RL24,}agent25 = {
    base = model.NO_PARENT.agent25,
    B = model.NO_PARENT.agent25.B25,
    H = model.NO_PARENT.agent25.H25,
    LA = model.NO_PARENT.agent25.B25.LA25,
    RA = model.NO_PARENT.agent25.B25.RA25,
    LL = model.NO_PARENT.agent25.B25.LL25,
    RL = model.NO_PARENT.agent25.B25.RL25,}agent26 = {
    base = model.NO_PARENT.agent26,
    B = model.NO_PARENT.agent26.B26,
    H = model.NO_PARENT.agent26.H26,
    LA = model.NO_PARENT.agent26.B26.LA26,
    RA = model.NO_PARENT.agent26.B26.RA26,
    LL = model.NO_PARENT.agent26.B26.LL26,
    RL = model.NO_PARENT.agent26.B26.RL26,}agent27 = {
    base = model.NO_PARENT.agent27,
    B = model.NO_PARENT.agent27.B27,
    H = model.NO_PARENT.agent27.H27,
    LA = model.NO_PARENT.agent27.B27.LA27,
    RA = model.NO_PARENT.agent27.B27.RA27,
    LL = model.NO_PARENT.agent27.B27.LL27,
    RL = model.NO_PARENT.agent27.B27.RL27,}agent28 = {
    base = model.NO_PARENT.agent28,
    B = model.NO_PARENT.agent28.B28,
    H = model.NO_PARENT.agent28.H28,
    LA = model.NO_PARENT.agent28.B28.LA28,
    RA = model.NO_PARENT.agent28.B28.RA28,
    LL = model.NO_PARENT.agent28.B28.LL28,
    RL = model.NO_PARENT.agent28.B28.RL28,}agent29 = {
    base = model.NO_PARENT.agent29,
    B = model.NO_PARENT.agent29.B29,
    H = model.NO_PARENT.agent29.H29,
    LA = model.NO_PARENT.agent29.B29.LA29,
    RA = model.NO_PARENT.agent29.B29.RA29,
    LL = model.NO_PARENT.agent29.B29.LL29,
    RL = model.NO_PARENT.agent29.B29.RL29,}agent30 = {
    base = model.NO_PARENT.agent30,
    B = model.NO_PARENT.agent30.B30,
    H = model.NO_PARENT.agent30.H30,
    LA = model.NO_PARENT.agent30.B30.LA30,
    RA = model.NO_PARENT.agent30.B30.RA30,
    LL = model.NO_PARENT.agent30.B30.LL30,
    RL = model.NO_PARENT.agent30.B30.RL30,}agent31 = {
    base = model.NO_PARENT.agent31,
    B = model.NO_PARENT.agent31.B31,
    H = model.NO_PARENT.agent31.H31,
    LA = model.NO_PARENT.agent31.B31.LA31,
    RA = model.NO_PARENT.agent31.B31.RA31,
    LL = model.NO_PARENT.agent31.B31.LL31,
    RL = model.NO_PARENT.agent31.B31.RL31,}agent32 = {
    base = model.NO_PARENT.agent32,
    B = model.NO_PARENT.agent32.B32,
    H = model.NO_PARENT.agent32.H32,
    LA = model.NO_PARENT.agent32.B32.LA32,
    RA = model.NO_PARENT.agent32.B32.RA32,
    LL = model.NO_PARENT.agent32.B32.LL32,
    RL = model.NO_PARENT.agent32.B32.RL32,}agent33 = {
    base = model.NO_PARENT.agent33,
    B = model.NO_PARENT.agent33.B33,
    H = model.NO_PARENT.agent33.H33,
    LA = model.NO_PARENT.agent33.B33.LA33,
    RA = model.NO_PARENT.agent33.B33.RA33,
    LL = model.NO_PARENT.agent33.B33.LL33,
    RL = model.NO_PARENT.agent33.B33.RL33,}agent34 = {
    base = model.NO_PARENT.agent34,
    B = model.NO_PARENT.agent34.B34,
    H = model.NO_PARENT.agent34.H34,
    LA = model.NO_PARENT.agent34.B34.LA34,
    RA = model.NO_PARENT.agent34.B34.RA34,
    LL = model.NO_PARENT.agent34.B34.LL34,
    RL = model.NO_PARENT.agent34.B34.RL34,}agent35 = {
    base = model.NO_PARENT.agent35,
    B = model.NO_PARENT.agent35.B35,
    H = model.NO_PARENT.agent35.H35,
    LA = model.NO_PARENT.agent35.B35.LA35,
    RA = model.NO_PARENT.agent35.B35.RA35,
    LL = model.NO_PARENT.agent35.B35.LL35,
    RL = model.NO_PARENT.agent35.B35.RL35,}agent36 = {
    base = model.NO_PARENT.agent36,
    B = model.NO_PARENT.agent36.B36,
    H = model.NO_PARENT.agent36.H36,
    LA = model.NO_PARENT.agent36.B36.LA36,
    RA = model.NO_PARENT.agent36.B36.RA36,
    LL = model.NO_PARENT.agent36.B36.LL36,
    RL = model.NO_PARENT.agent36.B36.RL36,}agent37 = {
    base = model.NO_PARENT.agent37,
    B = model.NO_PARENT.agent37.B37,
    H = model.NO_PARENT.agent37.H37,
    LA = model.NO_PARENT.agent37.B37.LA37,
    RA = model.NO_PARENT.agent37.B37.RA37,
    LL = model.NO_PARENT.agent37.B37.LL37,
    RL = model.NO_PARENT.agent37.B37.RL37,}agent38 = {
    base = model.NO_PARENT.agent38,
    B = model.NO_PARENT.agent38.B38,
    H = model.NO_PARENT.agent38.H38,
    LA = model.NO_PARENT.agent38.B38.LA38,
    RA = model.NO_PARENT.agent38.B38.RA38,
    LL = model.NO_PARENT.agent38.B38.LL38,
    RL = model.NO_PARENT.agent38.B38.RL38,}agent39 = {
    base = model.NO_PARENT.agent39,
    B = model.NO_PARENT.agent39.B39,
    H = model.NO_PARENT.agent39.H39,
    LA = model.NO_PARENT.agent39.B39.LA39,
    RA = model.NO_PARENT.agent39.B39.RA39,
    LL = model.NO_PARENT.agent39.B39.LL39,
    RL = model.NO_PARENT.agent39.B39.RL39,}agent40 = {
    base = model.NO_PARENT.agent40,
    B = model.NO_PARENT.agent40.B40,
    H = model.NO_PARENT.agent40.H40,
    LA = model.NO_PARENT.agent40.B40.LA40,
    RA = model.NO_PARENT.agent40.B40.RA40,
    LL = model.NO_PARENT.agent40.B40.LL40,
    RL = model.NO_PARENT.agent40.B40.RL40,}agent41 = {
    base = model.NO_PARENT.agent41,
    B = model.NO_PARENT.agent41.B41,
    H = model.NO_PARENT.agent41.H41,
    LA = model.NO_PARENT.agent41.B41.LA41,
    RA = model.NO_PARENT.agent41.B41.RA41,
    LL = model.NO_PARENT.agent41.B41.LL41,
    RL = model.NO_PARENT.agent41.B41.RL41,}agent42 = {
    base = model.NO_PARENT.agent42,
    B = model.NO_PARENT.agent42.B42,
    H = model.NO_PARENT.agent42.H42,
    LA = model.NO_PARENT.agent42.B42.LA42,
    RA = model.NO_PARENT.agent42.B42.RA42,
    LL = model.NO_PARENT.agent42.B42.LL42,
    RL = model.NO_PARENT.agent42.B42.RL42,}agent43 = {
    base = model.NO_PARENT.agent43,
    B = model.NO_PARENT.agent43.B43,
    H = model.NO_PARENT.agent43.H43,
    LA = model.NO_PARENT.agent43.B43.LA43,
    RA = model.NO_PARENT.agent43.B43.RA43,
    LL = model.NO_PARENT.agent43.B43.LL43,
    RL = model.NO_PARENT.agent43.B43.RL43,}agent44 = {
    base = model.NO_PARENT.agent44,
    B = model.NO_PARENT.agent44.B44,
    H = model.NO_PARENT.agent44.H44,
    LA = model.NO_PARENT.agent44.B44.LA44,
    RA = model.NO_PARENT.agent44.B44.RA44,
    LL = model.NO_PARENT.agent44.B44.LL44,
    RL = model.NO_PARENT.agent44.B44.RL44,}agent45 = {
    base = model.NO_PARENT.agent45,
    B = model.NO_PARENT.agent45.B45,
    H = model.NO_PARENT.agent45.H45,
    LA = model.NO_PARENT.agent45.B45.LA45,
    RA = model.NO_PARENT.agent45.B45.RA45,
    LL = model.NO_PARENT.agent45.B45.LL45,
    RL = model.NO_PARENT.agent45.B45.RL45,}agent46 = {
    base = model.NO_PARENT.agent46,
    B = model.NO_PARENT.agent46.B46,
    H = model.NO_PARENT.agent46.H46,
    LA = model.NO_PARENT.agent46.B46.LA46,
    RA = model.NO_PARENT.agent46.B46.RA46,
    LL = model.NO_PARENT.agent46.B46.LL46,
    RL = model.NO_PARENT.agent46.B46.RL46,}agent47 = {
    base = model.NO_PARENT.agent47,
    B = model.NO_PARENT.agent47.B47,
    H = model.NO_PARENT.agent47.H47,
    LA = model.NO_PARENT.agent47.B47.LA47,
    RA = model.NO_PARENT.agent47.B47.RA47,
    LL = model.NO_PARENT.agent47.B47.LL47,
    RL = model.NO_PARENT.agent47.B47.RL47,}agent48 = {
    base = model.NO_PARENT.agent48,
    B = model.NO_PARENT.agent48.B48,
    H = model.NO_PARENT.agent48.H48,
    LA = model.NO_PARENT.agent48.B48.LA48,
    RA = model.NO_PARENT.agent48.B48.RA48,
    LL = model.NO_PARENT.agent48.B48.LL48,
    RL = model.NO_PARENT.agent48.B48.RL48,}agent49 = {
    base = model.NO_PARENT.agent49,
    B = model.NO_PARENT.agent49.B49,
    H = model.NO_PARENT.agent49.H49,
    LA = model.NO_PARENT.agent49.B49.LA49,
    RA = model.NO_PARENT.agent49.B49.RA49,
    LL = model.NO_PARENT.agent49.B49.LL49,
    RL = model.NO_PARENT.agent49.B49.RL49,}agent50 = {
    base = model.NO_PARENT.agent50,
    B = model.NO_PARENT.agent50.B50,
    H = model.NO_PARENT.agent50.H50,
    LA = model.NO_PARENT.agent50.B50.LA50,
    RA = model.NO_PARENT.agent50.B50.RA50,
    LL = model.NO_PARENT.agent50.B50.LL50,
    RL = model.NO_PARENT.agent50.B50.RL50,}agent51 = {
    base = model.NO_PARENT.agent51,
    B = model.NO_PARENT.agent51.B51,
    H = model.NO_PARENT.agent51.H51,
    LA = model.NO_PARENT.agent51.B51.LA51,
    RA = model.NO_PARENT.agent51.B51.RA51,
    LL = model.NO_PARENT.agent51.B51.LL51,
    RL = model.NO_PARENT.agent51.B51.RL51,}agent52 = {
    base = model.NO_PARENT.agent52,
    B = model.NO_PARENT.agent52.B52,
    H = model.NO_PARENT.agent52.H52,
    LA = model.NO_PARENT.agent52.B52.LA52,
    RA = model.NO_PARENT.agent52.B52.RA52,
    LL = model.NO_PARENT.agent52.B52.LL52,
    RL = model.NO_PARENT.agent52.B52.RL52,}agent53 = {
    base = model.NO_PARENT.agent53,
    B = model.NO_PARENT.agent53.B53,
    H = model.NO_PARENT.agent53.H53,
    LA = model.NO_PARENT.agent53.B53.LA53,
    RA = model.NO_PARENT.agent53.B53.RA53,
    LL = model.NO_PARENT.agent53.B53.LL53,
    RL = model.NO_PARENT.agent53.B53.RL53,}agent54 = {
    base = model.NO_PARENT.agent54,
    B = model.NO_PARENT.agent54.B54,
    H = model.NO_PARENT.agent54.H54,
    LA = model.NO_PARENT.agent54.B54.LA54,
    RA = model.NO_PARENT.agent54.B54.RA54,
    LL = model.NO_PARENT.agent54.B54.LL54,
    RL = model.NO_PARENT.agent54.B54.RL54,}agent55 = {
    base = model.NO_PARENT.agent55,
    B = model.NO_PARENT.agent55.B55,
    H = model.NO_PARENT.agent55.H55,
    LA = model.NO_PARENT.agent55.B55.LA55,
    RA = model.NO_PARENT.agent55.B55.RA55,
    LL = model.NO_PARENT.agent55.B55.LL55,
    RL = model.NO_PARENT.agent55.B55.RL55,}agent56 = {
    base = model.NO_PARENT.agent56,
    B = model.NO_PARENT.agent56.B56,
    H = model.NO_PARENT.agent56.H56,
    LA = model.NO_PARENT.agent56.B56.LA56,
    RA = model.NO_PARENT.agent56.B56.RA56,
    LL = model.NO_PARENT.agent56.B56.LL56,
    RL = model.NO_PARENT.agent56.B56.RL56,}agent57 = {
    base = model.NO_PARENT.agent57,
    B = model.NO_PARENT.agent57.B57,
    H = model.NO_PARENT.agent57.H57,
    LA = model.NO_PARENT.agent57.B57.LA57,
    RA = model.NO_PARENT.agent57.B57.RA57,
    LL = model.NO_PARENT.agent57.B57.LL57,
    RL = model.NO_PARENT.agent57.B57.RL57,}agent58 = {
    base = model.NO_PARENT.agent58,
    B = model.NO_PARENT.agent58.B58,
    H = model.NO_PARENT.agent58.H58,
    LA = model.NO_PARENT.agent58.B58.LA58,
    RA = model.NO_PARENT.agent58.B58.RA58,
    LL = model.NO_PARENT.agent58.B58.LL58,
    RL = model.NO_PARENT.agent58.B58.RL58,}agent59 = {
    base = model.NO_PARENT.agent59,
    B = model.NO_PARENT.agent59.B59,
    H = model.NO_PARENT.agent59.H59,
    LA = model.NO_PARENT.agent59.B59.LA59,
    RA = model.NO_PARENT.agent59.B59.RA59,
    LL = model.NO_PARENT.agent59.B59.LL59,
    RL = model.NO_PARENT.agent59.B59.RL59,}agent60 = {
    base = model.NO_PARENT.agent60,
    B = model.NO_PARENT.agent60.B60,
    H = model.NO_PARENT.agent60.H60,
    LA = model.NO_PARENT.agent60.B60.LA60,
    RA = model.NO_PARENT.agent60.B60.RA60,
    LL = model.NO_PARENT.agent60.B60.LL60,
    RL = model.NO_PARENT.agent60.B60.RL60,}agent61 = {
    base = model.NO_PARENT.agent61,
    B = model.NO_PARENT.agent61.B61,
    H = model.NO_PARENT.agent61.H61,
    LA = model.NO_PARENT.agent61.B61.LA61,
    RA = model.NO_PARENT.agent61.B61.RA61,
    LL = model.NO_PARENT.agent61.B61.LL61,
    RL = model.NO_PARENT.agent61.B61.RL61,}agent62 = {
    base = model.NO_PARENT.agent62,
    B = model.NO_PARENT.agent62.B62,
    H = model.NO_PARENT.agent62.H62,
    LA = model.NO_PARENT.agent62.B62.LA62,
    RA = model.NO_PARENT.agent62.B62.RA62,
    LL = model.NO_PARENT.agent62.B62.LL62,
    RL = model.NO_PARENT.agent62.B62.RL62,}agent63 = {
    base = model.NO_PARENT.agent63,
    B = model.NO_PARENT.agent63.B63,
    H = model.NO_PARENT.agent63.H63,
    LA = model.NO_PARENT.agent63.B63.LA63,
    RA = model.NO_PARENT.agent63.B63.RA63,
    LL = model.NO_PARENT.agent63.B63.LL63,
    RL = model.NO_PARENT.agent63.B63.RL63,}agent64 = {
    base = model.NO_PARENT.agent64,
    B = model.NO_PARENT.agent64.B64,
    H = model.NO_PARENT.agent64.H64,
    LA = model.NO_PARENT.agent64.B64.LA64,
    RA = model.NO_PARENT.agent64.B64.RA64,
    LL = model.NO_PARENT.agent64.B64.LL64,
    RL = model.NO_PARENT.agent64.B64.RL64,}agent65 = {
    base = model.NO_PARENT.agent65,
    B = model.NO_PARENT.agent65.B65,
    H = model.NO_PARENT.agent65.H65,
    LA = model.NO_PARENT.agent65.B65.LA65,
    RA = model.NO_PARENT.agent65.B65.RA65,
    LL = model.NO_PARENT.agent65.B65.LL65,
    RL = model.NO_PARENT.agent65.B65.RL65,}agent66 = {
    base = model.NO_PARENT.agent66,
    B = model.NO_PARENT.agent66.B66,
    H = model.NO_PARENT.agent66.H66,
    LA = model.NO_PARENT.agent66.B66.LA66,
    RA = model.NO_PARENT.agent66.B66.RA66,
    LL = model.NO_PARENT.agent66.B66.LL66,
    RL = model.NO_PARENT.agent66.B66.RL66,}agent67 = {
    base = model.NO_PARENT.agent67,
    B = model.NO_PARENT.agent67.B67,
    H = model.NO_PARENT.agent67.H67,
    LA = model.NO_PARENT.agent67.B67.LA67,
    RA = model.NO_PARENT.agent67.B67.RA67,
    LL = model.NO_PARENT.agent67.B67.LL67,
    RL = model.NO_PARENT.agent67.B67.RL67,}agent68 = {
    base = model.NO_PARENT.agent68,
    B = model.NO_PARENT.agent68.B68,
    H = model.NO_PARENT.agent68.H68,
    LA = model.NO_PARENT.agent68.B68.LA68,
    RA = model.NO_PARENT.agent68.B68.RA68,
    LL = model.NO_PARENT.agent68.B68.LL68,
    RL = model.NO_PARENT.agent68.B68.RL68,}agent69 = {
    base = model.NO_PARENT.agent69,
    B = model.NO_PARENT.agent69.B69,
    H = model.NO_PARENT.agent69.H69,
    LA = model.NO_PARENT.agent69.B69.LA69,
    RA = model.NO_PARENT.agent69.B69.RA69,
    LL = model.NO_PARENT.agent69.B69.LL69,
    RL = model.NO_PARENT.agent69.B69.RL69,}agent70 = {
    base = model.NO_PARENT.agent70,
    B = model.NO_PARENT.agent70.B70,
    H = model.NO_PARENT.agent70.H70,
    LA = model.NO_PARENT.agent70.B70.LA70,
    RA = model.NO_PARENT.agent70.B70.RA70,
    LL = model.NO_PARENT.agent70.B70.LL70,
    RL = model.NO_PARENT.agent70.B70.RL70,}agent71 = {
    base = model.NO_PARENT.agent71,
    B = model.NO_PARENT.agent71.B71,
    H = model.NO_PARENT.agent71.H71,
    LA = model.NO_PARENT.agent71.B71.LA71,
    RA = model.NO_PARENT.agent71.B71.RA71,
    LL = model.NO_PARENT.agent71.B71.LL71,
    RL = model.NO_PARENT.agent71.B71.RL71,}agent72 = {
    base = model.NO_PARENT.agent72,
    B = model.NO_PARENT.agent72.B72,
    H = model.NO_PARENT.agent72.H72,
    LA = model.NO_PARENT.agent72.B72.LA72,
    RA = model.NO_PARENT.agent72.B72.RA72,
    LL = model.NO_PARENT.agent72.B72.LL72,
    RL = model.NO_PARENT.agent72.B72.RL72,}agent73 = {
    base = model.NO_PARENT.agent73,
    B = model.NO_PARENT.agent73.B73,
    H = model.NO_PARENT.agent73.H73,
    LA = model.NO_PARENT.agent73.B73.LA73,
    RA = model.NO_PARENT.agent73.B73.RA73,
    LL = model.NO_PARENT.agent73.B73.LL73,
    RL = model.NO_PARENT.agent73.B73.RL73,}agent74 = {
    base = model.NO_PARENT.agent74,
    B = model.NO_PARENT.agent74.B74,
    H = model.NO_PARENT.agent74.H74,
    LA = model.NO_PARENT.agent74.B74.LA74,
    RA = model.NO_PARENT.agent74.B74.RA74,
    LL = model.NO_PARENT.agent74.B74.LL74,
    RL = model.NO_PARENT.agent74.B74.RL74,}agent75 = {
    base = model.NO_PARENT.agent75,
    B = model.NO_PARENT.agent75.B75,
    H = model.NO_PARENT.agent75.H75,
    LA = model.NO_PARENT.agent75.B75.LA75,
    RA = model.NO_PARENT.agent75.B75.RA75,
    LL = model.NO_PARENT.agent75.B75.LL75,
    RL = model.NO_PARENT.agent75.B75.RL75,}agent76 = {
    base = model.NO_PARENT.agent76,
    B = model.NO_PARENT.agent76.B76,
    H = model.NO_PARENT.agent76.H76,
    LA = model.NO_PARENT.agent76.B76.LA76,
    RA = model.NO_PARENT.agent76.B76.RA76,
    LL = model.NO_PARENT.agent76.B76.LL76,
    RL = model.NO_PARENT.agent76.B76.RL76,}agent77 = {
    base = model.NO_PARENT.agent77,
    B = model.NO_PARENT.agent77.B77,
    H = model.NO_PARENT.agent77.H77,
    LA = model.NO_PARENT.agent77.B77.LA77,
    RA = model.NO_PARENT.agent77.B77.RA77,
    LL = model.NO_PARENT.agent77.B77.LL77,
    RL = model.NO_PARENT.agent77.B77.RL77,}agent78 = {
    base = model.NO_PARENT.agent78,
    B = model.NO_PARENT.agent78.B78,
    H = model.NO_PARENT.agent78.H78,
    LA = model.NO_PARENT.agent78.B78.LA78,
    RA = model.NO_PARENT.agent78.B78.RA78,
    LL = model.NO_PARENT.agent78.B78.LL78,
    RL = model.NO_PARENT.agent78.B78.RL78,}agent79 = {
    base = model.NO_PARENT.agent79,
    B = model.NO_PARENT.agent79.B79,
    H = model.NO_PARENT.agent79.H79,
    LA = model.NO_PARENT.agent79.B79.LA79,
    RA = model.NO_PARENT.agent79.B79.RA79,
    LL = model.NO_PARENT.agent79.B79.LL79,
    RL = model.NO_PARENT.agent79.B79.RL79,}agent80 = {
    base = model.NO_PARENT.agent80,
    B = model.NO_PARENT.agent80.B80,
    H = model.NO_PARENT.agent80.H80,
    LA = model.NO_PARENT.agent80.B80.LA80,
    RA = model.NO_PARENT.agent80.B80.RA80,
    LL = model.NO_PARENT.agent80.B80.LL80,
    RL = model.NO_PARENT.agent80.B80.RL80,}agent81 = {
    base = model.NO_PARENT.agent81,
    B = model.NO_PARENT.agent81.B81,
    H = model.NO_PARENT.agent81.H81,
    LA = model.NO_PARENT.agent81.B81.LA81,
    RA = model.NO_PARENT.agent81.B81.RA81,
    LL = model.NO_PARENT.agent81.B81.LL81,
    RL = model.NO_PARENT.agent81.B81.RL81,}agent82 = {
    base = model.NO_PARENT.agent82,
    B = model.NO_PARENT.agent82.B82,
    H = model.NO_PARENT.agent82.H82,
    LA = model.NO_PARENT.agent82.B82.LA82,
    RA = model.NO_PARENT.agent82.B82.RA82,
    LL = model.NO_PARENT.agent82.B82.LL82,
    RL = model.NO_PARENT.agent82.B82.RL82,}agent83 = {
    base = model.NO_PARENT.agent83,
    B = model.NO_PARENT.agent83.B83,
    H = model.NO_PARENT.agent83.H83,
    LA = model.NO_PARENT.agent83.B83.LA83,
    RA = model.NO_PARENT.agent83.B83.RA83,
    LL = model.NO_PARENT.agent83.B83.LL83,
    RL = model.NO_PARENT.agent83.B83.RL83,}agent84 = {
    base = model.NO_PARENT.agent84,
    B = model.NO_PARENT.agent84.B84,
    H = model.NO_PARENT.agent84.H84,
    LA = model.NO_PARENT.agent84.B84.LA84,
    RA = model.NO_PARENT.agent84.B84.RA84,
    LL = model.NO_PARENT.agent84.B84.LL84,
    RL = model.NO_PARENT.agent84.B84.RL84,}agent85 = {
    base = model.NO_PARENT.agent85,
    B = model.NO_PARENT.agent85.B85,
    H = model.NO_PARENT.agent85.H85,
    LA = model.NO_PARENT.agent85.B85.LA85,
    RA = model.NO_PARENT.agent85.B85.RA85,
    LL = model.NO_PARENT.agent85.B85.LL85,
    RL = model.NO_PARENT.agent85.B85.RL85,}agent86 = {
    base = model.NO_PARENT.agent86,
    B = model.NO_PARENT.agent86.B86,
    H = model.NO_PARENT.agent86.H86,
    LA = model.NO_PARENT.agent86.B86.LA86,
    RA = model.NO_PARENT.agent86.B86.RA86,
    LL = model.NO_PARENT.agent86.B86.LL86,
    RL = model.NO_PARENT.agent86.B86.RL86,}agent87 = {
    base = model.NO_PARENT.agent87,
    B = model.NO_PARENT.agent87.B87,
    H = model.NO_PARENT.agent87.H87,
    LA = model.NO_PARENT.agent87.B87.LA87,
    RA = model.NO_PARENT.agent87.B87.RA87,
    LL = model.NO_PARENT.agent87.B87.LL87,
    RL = model.NO_PARENT.agent87.B87.RL87,}agent88 = {
    base = model.NO_PARENT.agent88,
    B = model.NO_PARENT.agent88.B88,
    H = model.NO_PARENT.agent88.H88,
    LA = model.NO_PARENT.agent88.B88.LA88,
    RA = model.NO_PARENT.agent88.B88.RA88,
    LL = model.NO_PARENT.agent88.B88.LL88,
    RL = model.NO_PARENT.agent88.B88.RL88,}agent89 = {
    base = model.NO_PARENT.agent89,
    B = model.NO_PARENT.agent89.B89,
    H = model.NO_PARENT.agent89.H89,
    LA = model.NO_PARENT.agent89.B89.LA89,
    RA = model.NO_PARENT.agent89.B89.RA89,
    LL = model.NO_PARENT.agent89.B89.LL89,
    RL = model.NO_PARENT.agent89.B89.RL89,}agent90 = {
    base = model.NO_PARENT.agent90,
    B = model.NO_PARENT.agent90.B90,
    H = model.NO_PARENT.agent90.H90,
    LA = model.NO_PARENT.agent90.B90.LA90,
    RA = model.NO_PARENT.agent90.B90.RA90,
    LL = model.NO_PARENT.agent90.B90.LL90,
    RL = model.NO_PARENT.agent90.B90.RL90,}agent91 = {
    base = model.NO_PARENT.agent91,
    B = model.NO_PARENT.agent91.B91,
    H = model.NO_PARENT.agent91.H91,
    LA = model.NO_PARENT.agent91.B91.LA91,
    RA = model.NO_PARENT.agent91.B91.RA91,
    LL = model.NO_PARENT.agent91.B91.LL91,
    RL = model.NO_PARENT.agent91.B91.RL91,}agent92 = {
    base = model.NO_PARENT.agent92,
    B = model.NO_PARENT.agent92.B92,
    H = model.NO_PARENT.agent92.H92,
    LA = model.NO_PARENT.agent92.B92.LA92,
    RA = model.NO_PARENT.agent92.B92.RA92,
    LL = model.NO_PARENT.agent92.B92.LL92,
    RL = model.NO_PARENT.agent92.B92.RL92,}agent93 = {
    base = model.NO_PARENT.agent93,
    B = model.NO_PARENT.agent93.B93,
    H = model.NO_PARENT.agent93.H93,
    LA = model.NO_PARENT.agent93.B93.LA93,
    RA = model.NO_PARENT.agent93.B93.RA93,
    LL = model.NO_PARENT.agent93.B93.LL93,
    RL = model.NO_PARENT.agent93.B93.RL93,}agent94 = {
    base = model.NO_PARENT.agent94,
    B = model.NO_PARENT.agent94.B94,
    H = model.NO_PARENT.agent94.H94,
    LA = model.NO_PARENT.agent94.B94.LA94,
    RA = model.NO_PARENT.agent94.B94.RA94,
    LL = model.NO_PARENT.agent94.B94.LL94,
    RL = model.NO_PARENT.agent94.B94.RL94,}agent95 = {
    base = model.NO_PARENT.agent95,
    B = model.NO_PARENT.agent95.B95,
    H = model.NO_PARENT.agent95.H95,
    LA = model.NO_PARENT.agent95.B95.LA95,
    RA = model.NO_PARENT.agent95.B95.RA95,
    LL = model.NO_PARENT.agent95.B95.LL95,
    RL = model.NO_PARENT.agent95.B95.RL95,}agent96 = {
    base = model.NO_PARENT.agent96,
    B = model.NO_PARENT.agent96.B96,
    H = model.NO_PARENT.agent96.H96,
    LA = model.NO_PARENT.agent96.B96.LA96,
    RA = model.NO_PARENT.agent96.B96.RA96,
    LL = model.NO_PARENT.agent96.B96.LL96,
    RL = model.NO_PARENT.agent96.B96.RL96,}agent97 = {
    base = model.NO_PARENT.agent97,
    B = model.NO_PARENT.agent97.B97,
    H = model.NO_PARENT.agent97.H97,
    LA = model.NO_PARENT.agent97.B97.LA97,
    RA = model.NO_PARENT.agent97.B97.RA97,
    LL = model.NO_PARENT.agent97.B97.LL97,
    RL = model.NO_PARENT.agent97.B97.RL97,}agent98 = {
    base = model.NO_PARENT.agent98,
    B = model.NO_PARENT.agent98.B98,
    H = model.NO_PARENT.agent98.H98,
    LA = model.NO_PARENT.agent98.B98.LA98,
    RA = model.NO_PARENT.agent98.B98.RA98,
    LL = model.NO_PARENT.agent98.B98.LL98,
    RL = model.NO_PARENT.agent98.B98.RL98,}agent99 = {
    base = model.NO_PARENT.agent99,
    B = model.NO_PARENT.agent99.B99,
    H = model.NO_PARENT.agent99.H99,
    LA = model.NO_PARENT.agent99.B99.LA99,
    RA = model.NO_PARENT.agent99.B99.RA99,
    LL = model.NO_PARENT.agent99.B99.LL99,
    RL = model.NO_PARENT.agent99.B99.RL99,}agent100 = {
    base = model.NO_PARENT.agent100,
    B = model.NO_PARENT.agent100.B100,
    H = model.NO_PARENT.agent100.H100,
    LA = model.NO_PARENT.agent100.B100.LA100,
    RA = model.NO_PARENT.agent100.B100.RA100,
    LL = model.NO_PARENT.agent100.B100.LL100,
    RL = model.NO_PARENT.agent100.B100.RL100,}agent101 = {
    base = model.NO_PARENT.agent101,
    B = model.NO_PARENT.agent101.B101,
    H = model.NO_PARENT.agent101.H101,
    LA = model.NO_PARENT.agent101.B101.LA101,
    RA = model.NO_PARENT.agent101.B101.RA101,
    LL = model.NO_PARENT.agent101.B101.LL101,
    RL = model.NO_PARENT.agent101.B101.RL101,}agent102 = {
    base = model.NO_PARENT.agent102,
    B = model.NO_PARENT.agent102.B102,
    H = model.NO_PARENT.agent102.H102,
    LA = model.NO_PARENT.agent102.B102.LA102,
    RA = model.NO_PARENT.agent102.B102.RA102,
    LL = model.NO_PARENT.agent102.B102.LL102,
    RL = model.NO_PARENT.agent102.B102.RL102,}agent103 = {
    base = model.NO_PARENT.agent103,
    B = model.NO_PARENT.agent103.B103,
    H = model.NO_PARENT.agent103.H103,
    LA = model.NO_PARENT.agent103.B103.LA103,
    RA = model.NO_PARENT.agent103.B103.RA103,
    LL = model.NO_PARENT.agent103.B103.LL103,
    RL = model.NO_PARENT.agent103.B103.RL103,}agent104 = {
    base = model.NO_PARENT.agent104,
    B = model.NO_PARENT.agent104.B104,
    H = model.NO_PARENT.agent104.H104,
    LA = model.NO_PARENT.agent104.B104.LA104,
    RA = model.NO_PARENT.agent104.B104.RA104,
    LL = model.NO_PARENT.agent104.B104.LL104,
    RL = model.NO_PARENT.agent104.B104.RL104,}agent105 = {
    base = model.NO_PARENT.agent105,
    B = model.NO_PARENT.agent105.B105,
    H = model.NO_PARENT.agent105.H105,
    LA = model.NO_PARENT.agent105.B105.LA105,
    RA = model.NO_PARENT.agent105.B105.RA105,
    LL = model.NO_PARENT.agent105.B105.LL105,
    RL = model.NO_PARENT.agent105.B105.RL105,}agent106 = {
    base = model.NO_PARENT.agent106,
    B = model.NO_PARENT.agent106.B106,
    H = model.NO_PARENT.agent106.H106,
    LA = model.NO_PARENT.agent106.B106.LA106,
    RA = model.NO_PARENT.agent106.B106.RA106,
    LL = model.NO_PARENT.agent106.B106.LL106,
    RL = model.NO_PARENT.agent106.B106.RL106,}agent107 = {
    base = model.NO_PARENT.agent107,
    B = model.NO_PARENT.agent107.B107,
    H = model.NO_PARENT.agent107.H107,
    LA = model.NO_PARENT.agent107.B107.LA107,
    RA = model.NO_PARENT.agent107.B107.RA107,
    LL = model.NO_PARENT.agent107.B107.LL107,
    RL = model.NO_PARENT.agent107.B107.RL107,}agent108 = {
    base = model.NO_PARENT.agent108,
    B = model.NO_PARENT.agent108.B108,
    H = model.NO_PARENT.agent108.H108,
    LA = model.NO_PARENT.agent108.B108.LA108,
    RA = model.NO_PARENT.agent108.B108.RA108,
    LL = model.NO_PARENT.agent108.B108.LL108,
    RL = model.NO_PARENT.agent108.B108.RL108,}agent109 = {
    base = model.NO_PARENT.agent109,
    B = model.NO_PARENT.agent109.B109,
    H = model.NO_PARENT.agent109.H109,
    LA = model.NO_PARENT.agent109.B109.LA109,
    RA = model.NO_PARENT.agent109.B109.RA109,
    LL = model.NO_PARENT.agent109.B109.LL109,
    RL = model.NO_PARENT.agent109.B109.RL109,}agent110 = {
    base = model.NO_PARENT.agent110,
    B = model.NO_PARENT.agent110.B110,
    H = model.NO_PARENT.agent110.H110,
    LA = model.NO_PARENT.agent110.B110.LA110,
    RA = model.NO_PARENT.agent110.B110.RA110,
    LL = model.NO_PARENT.agent110.B110.LL110,
    RL = model.NO_PARENT.agent110.B110.RL110,}agent111 = {
    base = model.NO_PARENT.agent111,
    B = model.NO_PARENT.agent111.B111,
    H = model.NO_PARENT.agent111.H111,
    LA = model.NO_PARENT.agent111.B111.LA111,
    RA = model.NO_PARENT.agent111.B111.RA111,
    LL = model.NO_PARENT.agent111.B111.LL111,
    RL = model.NO_PARENT.agent111.B111.RL111,}agent112 = {
    base = model.NO_PARENT.agent112,
    B = model.NO_PARENT.agent112.B112,
    H = model.NO_PARENT.agent112.H112,
    LA = model.NO_PARENT.agent112.B112.LA112,
    RA = model.NO_PARENT.agent112.B112.RA112,
    LL = model.NO_PARENT.agent112.B112.LL112,
    RL = model.NO_PARENT.agent112.B112.RL112,}agent113 = {
    base = model.NO_PARENT.agent113,
    B = model.NO_PARENT.agent113.B113,
    H = model.NO_PARENT.agent113.H113,
    LA = model.NO_PARENT.agent113.B113.LA113,
    RA = model.NO_PARENT.agent113.B113.RA113,
    LL = model.NO_PARENT.agent113.B113.LL113,
    RL = model.NO_PARENT.agent113.B113.RL113,}agent114 = {
    base = model.NO_PARENT.agent114,
    B = model.NO_PARENT.agent114.B114,
    H = model.NO_PARENT.agent114.H114,
    LA = model.NO_PARENT.agent114.B114.LA114,
    RA = model.NO_PARENT.agent114.B114.RA114,
    LL = model.NO_PARENT.agent114.B114.LL114,
    RL = model.NO_PARENT.agent114.B114.RL114,}agent115 = {
    base = model.NO_PARENT.agent115,
    B = model.NO_PARENT.agent115.B115,
    H = model.NO_PARENT.agent115.H115,
    LA = model.NO_PARENT.agent115.B115.LA115,
    RA = model.NO_PARENT.agent115.B115.RA115,
    LL = model.NO_PARENT.agent115.B115.LL115,
    RL = model.NO_PARENT.agent115.B115.RL115,}agent116 = {
    base = model.NO_PARENT.agent116,
    B = model.NO_PARENT.agent116.B116,
    H = model.NO_PARENT.agent116.H116,
    LA = model.NO_PARENT.agent116.B116.LA116,
    RA = model.NO_PARENT.agent116.B116.RA116,
    LL = model.NO_PARENT.agent116.B116.LL116,
    RL = model.NO_PARENT.agent116.B116.RL116,}agent117 = {
    base = model.NO_PARENT.agent117,
    B = model.NO_PARENT.agent117.B117,
    H = model.NO_PARENT.agent117.H117,
    LA = model.NO_PARENT.agent117.B117.LA117,
    RA = model.NO_PARENT.agent117.B117.RA117,
    LL = model.NO_PARENT.agent117.B117.LL117,
    RL = model.NO_PARENT.agent117.B117.RL117,}agent118 = {
    base = model.NO_PARENT.agent118,
    B = model.NO_PARENT.agent118.B118,
    H = model.NO_PARENT.agent118.H118,
    LA = model.NO_PARENT.agent118.B118.LA118,
    RA = model.NO_PARENT.agent118.B118.RA118,
    LL = model.NO_PARENT.agent118.B118.LL118,
    RL = model.NO_PARENT.agent118.B118.RL118,}agent119 = {
    base = model.NO_PARENT.agent119,
    B = model.NO_PARENT.agent119.B119,
    H = model.NO_PARENT.agent119.H119,
    LA = model.NO_PARENT.agent119.B119.LA119,
    RA = model.NO_PARENT.agent119.B119.RA119,
    LL = model.NO_PARENT.agent119.B119.LL119,
    RL = model.NO_PARENT.agent119.B119.RL119,}agent120 = {
    base = model.NO_PARENT.agent120,
    B = model.NO_PARENT.agent120.B120,
    H = model.NO_PARENT.agent120.H120,
    LA = model.NO_PARENT.agent120.B120.LA120,
    RA = model.NO_PARENT.agent120.B120.RA120,
    LL = model.NO_PARENT.agent120.B120.LL120,
    RL = model.NO_PARENT.agent120.B120.RL120,}agent121 = {
    base = model.NO_PARENT.agent121,
    B = model.NO_PARENT.agent121.B121,
    H = model.NO_PARENT.agent121.H121,
    LA = model.NO_PARENT.agent121.B121.LA121,
    RA = model.NO_PARENT.agent121.B121.RA121,
    LL = model.NO_PARENT.agent121.B121.LL121,
    RL = model.NO_PARENT.agent121.B121.RL121,}agent122 = {
    base = model.NO_PARENT.agent122,
    B = model.NO_PARENT.agent122.B122,
    H = model.NO_PARENT.agent122.H122,
    LA = model.NO_PARENT.agent122.B122.LA122,
    RA = model.NO_PARENT.agent122.B122.RA122,
    LL = model.NO_PARENT.agent122.B122.LL122,
    RL = model.NO_PARENT.agent122.B122.RL122,}agent123 = {
    base = model.NO_PARENT.agent123,
    B = model.NO_PARENT.agent123.B123,
    H = model.NO_PARENT.agent123.H123,
    LA = model.NO_PARENT.agent123.B123.LA123,
    RA = model.NO_PARENT.agent123.B123.RA123,
    LL = model.NO_PARENT.agent123.B123.LL123,
    RL = model.NO_PARENT.agent123.B123.RL123,}agent124 = {
    base = model.NO_PARENT.agent124,
    B = model.NO_PARENT.agent124.B124,
    H = model.NO_PARENT.agent124.H124,
    LA = model.NO_PARENT.agent124.B124.LA124,
    RA = model.NO_PARENT.agent124.B124.RA124,
    LL = model.NO_PARENT.agent124.B124.LL124,
    RL = model.NO_PARENT.agent124.B124.RL124,}agent125 = {
    base = model.NO_PARENT.agent125,
    B = model.NO_PARENT.agent125.B125,
    H = model.NO_PARENT.agent125.H125,
    LA = model.NO_PARENT.agent125.B125.LA125,
    RA = model.NO_PARENT.agent125.B125.RA125,
    LL = model.NO_PARENT.agent125.B125.LL125,
    RL = model.NO_PARENT.agent125.B125.RL125,}agent126 = {
    base = model.NO_PARENT.agent126,
    B = model.NO_PARENT.agent126.B126,
    H = model.NO_PARENT.agent126.H126,
    LA = model.NO_PARENT.agent126.B126.LA126,
    RA = model.NO_PARENT.agent126.B126.RA126,
    LL = model.NO_PARENT.agent126.B126.LL126,
    RL = model.NO_PARENT.agent126.B126.RL126,}agent127 = {
    base = model.NO_PARENT.agent127,
    B = model.NO_PARENT.agent127.B127,
    H = model.NO_PARENT.agent127.H127,
    LA = model.NO_PARENT.agent127.B127.LA127,
    RA = model.NO_PARENT.agent127.B127.RA127,
    LL = model.NO_PARENT.agent127.B127.LL127,
    RL = model.NO_PARENT.agent127.B127.RL127,}agent128 = {
    base = model.NO_PARENT.agent128,
    B = model.NO_PARENT.agent128.B128,
    H = model.NO_PARENT.agent128.H128,
    LA = model.NO_PARENT.agent128.B128.LA128,
    RA = model.NO_PARENT.agent128.B128.RA128,
    LL = model.NO_PARENT.agent128.B128.LL128,
    RL = model.NO_PARENT.agent128.B128.RL128,}agent129 = {
    base = model.NO_PARENT.agent129,
    B = model.NO_PARENT.agent129.B129,
    H = model.NO_PARENT.agent129.H129,
    LA = model.NO_PARENT.agent129.B129.LA129,
    RA = model.NO_PARENT.agent129.B129.RA129,
    LL = model.NO_PARENT.agent129.B129.LL129,
    RL = model.NO_PARENT.agent129.B129.RL129,}agent130 = {
    base = model.NO_PARENT.agent130,
    B = model.NO_PARENT.agent130.B130,
    H = model.NO_PARENT.agent130.H130,
    LA = model.NO_PARENT.agent130.B130.LA130,
    RA = model.NO_PARENT.agent130.B130.RA130,
    LL = model.NO_PARENT.agent130.B130.LL130,
    RL = model.NO_PARENT.agent130.B130.RL130,}agent131 = {
    base = model.NO_PARENT.agent131,
    B = model.NO_PARENT.agent131.B131,
    H = model.NO_PARENT.agent131.H131,
    LA = model.NO_PARENT.agent131.B131.LA131,
    RA = model.NO_PARENT.agent131.B131.RA131,
    LL = model.NO_PARENT.agent131.B131.LL131,
    RL = model.NO_PARENT.agent131.B131.RL131,}agent132 = {
    base = model.NO_PARENT.agent132,
    B = model.NO_PARENT.agent132.B132,
    H = model.NO_PARENT.agent132.H132,
    LA = model.NO_PARENT.agent132.B132.LA132,
    RA = model.NO_PARENT.agent132.B132.RA132,
    LL = model.NO_PARENT.agent132.B132.LL132,
    RL = model.NO_PARENT.agent132.B132.RL132,}agent133 = {
    base = model.NO_PARENT.agent133,
    B = model.NO_PARENT.agent133.B133,
    H = model.NO_PARENT.agent133.H133,
    LA = model.NO_PARENT.agent133.B133.LA133,
    RA = model.NO_PARENT.agent133.B133.RA133,
    LL = model.NO_PARENT.agent133.B133.LL133,
    RL = model.NO_PARENT.agent133.B133.RL133,}agent134 = {
    base = model.NO_PARENT.agent134,
    B = model.NO_PARENT.agent134.B134,
    H = model.NO_PARENT.agent134.H134,
    LA = model.NO_PARENT.agent134.B134.LA134,
    RA = model.NO_PARENT.agent134.B134.RA134,
    LL = model.NO_PARENT.agent134.B134.LL134,
    RL = model.NO_PARENT.agent134.B134.RL134,}agent135 = {
    base = model.NO_PARENT.agent135,
    B = model.NO_PARENT.agent135.B135,
    H = model.NO_PARENT.agent135.H135,
    LA = model.NO_PARENT.agent135.B135.LA135,
    RA = model.NO_PARENT.agent135.B135.RA135,
    LL = model.NO_PARENT.agent135.B135.LL135,
    RL = model.NO_PARENT.agent135.B135.RL135,}agent136 = {
    base = model.NO_PARENT.agent136,
    B = model.NO_PARENT.agent136.B136,
    H = model.NO_PARENT.agent136.H136,
    LA = model.NO_PARENT.agent136.B136.LA136,
    RA = model.NO_PARENT.agent136.B136.RA136,
    LL = model.NO_PARENT.agent136.B136.LL136,
    RL = model.NO_PARENT.agent136.B136.RL136,}agent137 = {
    base = model.NO_PARENT.agent137,
    B = model.NO_PARENT.agent137.B137,
    H = model.NO_PARENT.agent137.H137,
    LA = model.NO_PARENT.agent137.B137.LA137,
    RA = model.NO_PARENT.agent137.B137.RA137,
    LL = model.NO_PARENT.agent137.B137.LL137,
    RL = model.NO_PARENT.agent137.B137.RL137,}agent138 = {
    base = model.NO_PARENT.agent138,
    B = model.NO_PARENT.agent138.B138,
    H = model.NO_PARENT.agent138.H138,
    LA = model.NO_PARENT.agent138.B138.LA138,
    RA = model.NO_PARENT.agent138.B138.RA138,
    LL = model.NO_PARENT.agent138.B138.LL138,
    RL = model.NO_PARENT.agent138.B138.RL138,}agent139 = {
    base = model.NO_PARENT.agent139,
    B = model.NO_PARENT.agent139.B139,
    H = model.NO_PARENT.agent139.H139,
    LA = model.NO_PARENT.agent139.B139.LA139,
    RA = model.NO_PARENT.agent139.B139.RA139,
    LL = model.NO_PARENT.agent139.B139.LL139,
    RL = model.NO_PARENT.agent139.B139.RL139,}agent140 = {
    base = model.NO_PARENT.agent140,
    B = model.NO_PARENT.agent140.B140,
    H = model.NO_PARENT.agent140.H140,
    LA = model.NO_PARENT.agent140.B140.LA140,
    RA = model.NO_PARENT.agent140.B140.RA140,
    LL = model.NO_PARENT.agent140.B140.LL140,
    RL = model.NO_PARENT.agent140.B140.RL140,}agent141 = {
    base = model.NO_PARENT.agent141,
    B = model.NO_PARENT.agent141.B141,
    H = model.NO_PARENT.agent141.H141,
    LA = model.NO_PARENT.agent141.B141.LA141,
    RA = model.NO_PARENT.agent141.B141.RA141,
    LL = model.NO_PARENT.agent141.B141.LL141,
    RL = model.NO_PARENT.agent141.B141.RL141,}agent142 = {
    base = model.NO_PARENT.agent142,
    B = model.NO_PARENT.agent142.B142,
    H = model.NO_PARENT.agent142.H142,
    LA = model.NO_PARENT.agent142.B142.LA142,
    RA = model.NO_PARENT.agent142.B142.RA142,
    LL = model.NO_PARENT.agent142.B142.LL142,
    RL = model.NO_PARENT.agent142.B142.RL142,}agent143 = {
    base = model.NO_PARENT.agent143,
    B = model.NO_PARENT.agent143.B143,
    H = model.NO_PARENT.agent143.H143,
    LA = model.NO_PARENT.agent143.B143.LA143,
    RA = model.NO_PARENT.agent143.B143.RA143,
    LL = model.NO_PARENT.agent143.B143.LL143,
    RL = model.NO_PARENT.agent143.B143.RL143,}agent144 = {
    base = model.NO_PARENT.agent144,
    B = model.NO_PARENT.agent144.B144,
    H = model.NO_PARENT.agent144.H144,
    LA = model.NO_PARENT.agent144.B144.LA144,
    RA = model.NO_PARENT.agent144.B144.RA144,
    LL = model.NO_PARENT.agent144.B144.LL144,
    RL = model.NO_PARENT.agent144.B144.RL144,}agent145 = {
    base = model.NO_PARENT.agent145,
    B = model.NO_PARENT.agent145.B145,
    H = model.NO_PARENT.agent145.H145,
    LA = model.NO_PARENT.agent145.B145.LA145,
    RA = model.NO_PARENT.agent145.B145.RA145,
    LL = model.NO_PARENT.agent145.B145.LL145,
    RL = model.NO_PARENT.agent145.B145.RL145,}agent146 = {
    base = model.NO_PARENT.agent146,
    B = model.NO_PARENT.agent146.B146,
    H = model.NO_PARENT.agent146.H146,
    LA = model.NO_PARENT.agent146.B146.LA146,
    RA = model.NO_PARENT.agent146.B146.RA146,
    LL = model.NO_PARENT.agent146.B146.LL146,
    RL = model.NO_PARENT.agent146.B146.RL146,}agent147 = {
    base = model.NO_PARENT.agent147,
    B = model.NO_PARENT.agent147.B147,
    H = model.NO_PARENT.agent147.H147,
    LA = model.NO_PARENT.agent147.B147.LA147,
    RA = model.NO_PARENT.agent147.B147.RA147,
    LL = model.NO_PARENT.agent147.B147.LL147,
    RL = model.NO_PARENT.agent147.B147.RL147,}agent148 = {
    base = model.NO_PARENT.agent148,
    B = model.NO_PARENT.agent148.B148,
    H = model.NO_PARENT.agent148.H148,
    LA = model.NO_PARENT.agent148.B148.LA148,
    RA = model.NO_PARENT.agent148.B148.RA148,
    LL = model.NO_PARENT.agent148.B148.LL148,
    RL = model.NO_PARENT.agent148.B148.RL148,}agent149 = {
    base = model.NO_PARENT.agent149,
    B = model.NO_PARENT.agent149.B149,
    H = model.NO_PARENT.agent149.H149,
    LA = model.NO_PARENT.agent149.B149.LA149,
    RA = model.NO_PARENT.agent149.B149.RA149,
    LL = model.NO_PARENT.agent149.B149.LL149,
    RL = model.NO_PARENT.agent149.B149.RL149,}agent150 = {
    base = model.NO_PARENT.agent150,
    B = model.NO_PARENT.agent150.B150,
    H = model.NO_PARENT.agent150.H150,
    LA = model.NO_PARENT.agent150.B150.LA150,
    RA = model.NO_PARENT.agent150.B150.RA150,
    LL = model.NO_PARENT.agent150.B150.LL150,
    RL = model.NO_PARENT.agent150.B150.RL150,}agent151 = {
    base = model.NO_PARENT.agent151,
    B = model.NO_PARENT.agent151.B151,
    H = model.NO_PARENT.agent151.H151,
    LA = model.NO_PARENT.agent151.B151.LA151,
    RA = model.NO_PARENT.agent151.B151.RA151,
    LL = model.NO_PARENT.agent151.B151.LL151,
    RL = model.NO_PARENT.agent151.B151.RL151,}agent152 = {
    base = model.NO_PARENT.agent152,
    B = model.NO_PARENT.agent152.B152,
    H = model.NO_PARENT.agent152.H152,
    LA = model.NO_PARENT.agent152.B152.LA152,
    RA = model.NO_PARENT.agent152.B152.RA152,
    LL = model.NO_PARENT.agent152.B152.LL152,
    RL = model.NO_PARENT.agent152.B152.RL152,}agent153 = {
    base = model.NO_PARENT.agent153,
    B = model.NO_PARENT.agent153.B153,
    H = model.NO_PARENT.agent153.H153,
    LA = model.NO_PARENT.agent153.B153.LA153,
    RA = model.NO_PARENT.agent153.B153.RA153,
    LL = model.NO_PARENT.agent153.B153.LL153,
    RL = model.NO_PARENT.agent153.B153.RL153,}agent154 = {
    base = model.NO_PARENT.agent154,
    B = model.NO_PARENT.agent154.B154,
    H = model.NO_PARENT.agent154.H154,
    LA = model.NO_PARENT.agent154.B154.LA154,
    RA = model.NO_PARENT.agent154.B154.RA154,
    LL = model.NO_PARENT.agent154.B154.LL154,
    RL = model.NO_PARENT.agent154.B154.RL154,}agent155 = {
    base = model.NO_PARENT.agent155,
    B = model.NO_PARENT.agent155.B155,
    H = model.NO_PARENT.agent155.H155,
    LA = model.NO_PARENT.agent155.B155.LA155,
    RA = model.NO_PARENT.agent155.B155.RA155,
    LL = model.NO_PARENT.agent155.B155.LL155,
    RL = model.NO_PARENT.agent155.B155.RL155,}agent156 = {
    base = model.NO_PARENT.agent156,
    B = model.NO_PARENT.agent156.B156,
    H = model.NO_PARENT.agent156.H156,
    LA = model.NO_PARENT.agent156.B156.LA156,
    RA = model.NO_PARENT.agent156.B156.RA156,
    LL = model.NO_PARENT.agent156.B156.LL156,
    RL = model.NO_PARENT.agent156.B156.RL156,}agent157 = {
    base = model.NO_PARENT.agent157,
    B = model.NO_PARENT.agent157.B157,
    H = model.NO_PARENT.agent157.H157,
    LA = model.NO_PARENT.agent157.B157.LA157,
    RA = model.NO_PARENT.agent157.B157.RA157,
    LL = model.NO_PARENT.agent157.B157.LL157,
    RL = model.NO_PARENT.agent157.B157.RL157,}agent158 = {
    base = model.NO_PARENT.agent158,
    B = model.NO_PARENT.agent158.B158,
    H = model.NO_PARENT.agent158.H158,
    LA = model.NO_PARENT.agent158.B158.LA158,
    RA = model.NO_PARENT.agent158.B158.RA158,
    LL = model.NO_PARENT.agent158.B158.LL158,
    RL = model.NO_PARENT.agent158.B158.RL158,}agent159 = {
    base = model.NO_PARENT.agent159,
    B = model.NO_PARENT.agent159.B159,
    H = model.NO_PARENT.agent159.H159,
    LA = model.NO_PARENT.agent159.B159.LA159,
    RA = model.NO_PARENT.agent159.B159.RA159,
    LL = model.NO_PARENT.agent159.B159.LL159,
    RL = model.NO_PARENT.agent159.B159.RL159,}agent160 = {
    base = model.NO_PARENT.agent160,
    B = model.NO_PARENT.agent160.B160,
    H = model.NO_PARENT.agent160.H160,
    LA = model.NO_PARENT.agent160.B160.LA160,
    RA = model.NO_PARENT.agent160.B160.RA160,
    LL = model.NO_PARENT.agent160.B160.LL160,
    RL = model.NO_PARENT.agent160.B160.RL160,}agent161 = {
    base = model.NO_PARENT.agent161,
    B = model.NO_PARENT.agent161.B161,
    H = model.NO_PARENT.agent161.H161,
    LA = model.NO_PARENT.agent161.B161.LA161,
    RA = model.NO_PARENT.agent161.B161.RA161,
    LL = model.NO_PARENT.agent161.B161.LL161,
    RL = model.NO_PARENT.agent161.B161.RL161,}agent162 = {
    base = model.NO_PARENT.agent162,
    B = model.NO_PARENT.agent162.B162,
    H = model.NO_PARENT.agent162.H162,
    LA = model.NO_PARENT.agent162.B162.LA162,
    RA = model.NO_PARENT.agent162.B162.RA162,
    LL = model.NO_PARENT.agent162.B162.LL162,
    RL = model.NO_PARENT.agent162.B162.RL162,}agent163 = {
    base = model.NO_PARENT.agent163,
    B = model.NO_PARENT.agent163.B163,
    H = model.NO_PARENT.agent163.H163,
    LA = model.NO_PARENT.agent163.B163.LA163,
    RA = model.NO_PARENT.agent163.B163.RA163,
    LL = model.NO_PARENT.agent163.B163.LL163,
    RL = model.NO_PARENT.agent163.B163.RL163,}agent164 = {
    base = model.NO_PARENT.agent164,
    B = model.NO_PARENT.agent164.B164,
    H = model.NO_PARENT.agent164.H164,
    LA = model.NO_PARENT.agent164.B164.LA164,
    RA = model.NO_PARENT.agent164.B164.RA164,
    LL = model.NO_PARENT.agent164.B164.LL164,
    RL = model.NO_PARENT.agent164.B164.RL164,}agent165 = {
    base = model.NO_PARENT.agent165,
    B = model.NO_PARENT.agent165.B165,
    H = model.NO_PARENT.agent165.H165,
    LA = model.NO_PARENT.agent165.B165.LA165,
    RA = model.NO_PARENT.agent165.B165.RA165,
    LL = model.NO_PARENT.agent165.B165.LL165,
    RL = model.NO_PARENT.agent165.B165.RL165,}agent166 = {
    base = model.NO_PARENT.agent166,
    B = model.NO_PARENT.agent166.B166,
    H = model.NO_PARENT.agent166.H166,
    LA = model.NO_PARENT.agent166.B166.LA166,
    RA = model.NO_PARENT.agent166.B166.RA166,
    LL = model.NO_PARENT.agent166.B166.LL166,
    RL = model.NO_PARENT.agent166.B166.RL166,}agent167 = {
    base = model.NO_PARENT.agent167,
    B = model.NO_PARENT.agent167.B167,
    H = model.NO_PARENT.agent167.H167,
    LA = model.NO_PARENT.agent167.B167.LA167,
    RA = model.NO_PARENT.agent167.B167.RA167,
    LL = model.NO_PARENT.agent167.B167.LL167,
    RL = model.NO_PARENT.agent167.B167.RL167,}agent168 = {
    base = model.NO_PARENT.agent168,
    B = model.NO_PARENT.agent168.B168,
    H = model.NO_PARENT.agent168.H168,
    LA = model.NO_PARENT.agent168.B168.LA168,
    RA = model.NO_PARENT.agent168.B168.RA168,
    LL = model.NO_PARENT.agent168.B168.LL168,
    RL = model.NO_PARENT.agent168.B168.RL168,}agent169 = {
    base = model.NO_PARENT.agent169,
    B = model.NO_PARENT.agent169.B169,
    H = model.NO_PARENT.agent169.H169,
    LA = model.NO_PARENT.agent169.B169.LA169,
    RA = model.NO_PARENT.agent169.B169.RA169,
    LL = model.NO_PARENT.agent169.B169.LL169,
    RL = model.NO_PARENT.agent169.B169.RL169,}agent170 = {
    base = model.NO_PARENT.agent170,
    B = model.NO_PARENT.agent170.B170,
    H = model.NO_PARENT.agent170.H170,
    LA = model.NO_PARENT.agent170.B170.LA170,
    RA = model.NO_PARENT.agent170.B170.RA170,
    LL = model.NO_PARENT.agent170.B170.LL170,
    RL = model.NO_PARENT.agent170.B170.RL170,}agent171 = {
    base = model.NO_PARENT.agent171,
    B = model.NO_PARENT.agent171.B171,
    H = model.NO_PARENT.agent171.H171,
    LA = model.NO_PARENT.agent171.B171.LA171,
    RA = model.NO_PARENT.agent171.B171.RA171,
    LL = model.NO_PARENT.agent171.B171.LL171,
    RL = model.NO_PARENT.agent171.B171.RL171,}agent172 = {
    base = model.NO_PARENT.agent172,
    B = model.NO_PARENT.agent172.B172,
    H = model.NO_PARENT.agent172.H172,
    LA = model.NO_PARENT.agent172.B172.LA172,
    RA = model.NO_PARENT.agent172.B172.RA172,
    LL = model.NO_PARENT.agent172.B172.LL172,
    RL = model.NO_PARENT.agent172.B172.RL172,}agent173 = {
    base = model.NO_PARENT.agent173,
    B = model.NO_PARENT.agent173.B173,
    H = model.NO_PARENT.agent173.H173,
    LA = model.NO_PARENT.agent173.B173.LA173,
    RA = model.NO_PARENT.agent173.B173.RA173,
    LL = model.NO_PARENT.agent173.B173.LL173,
    RL = model.NO_PARENT.agent173.B173.RL173,}agent174 = {
    base = model.NO_PARENT.agent174,
    B = model.NO_PARENT.agent174.B174,
    H = model.NO_PARENT.agent174.H174,
    LA = model.NO_PARENT.agent174.B174.LA174,
    RA = model.NO_PARENT.agent174.B174.RA174,
    LL = model.NO_PARENT.agent174.B174.LL174,
    RL = model.NO_PARENT.agent174.B174.RL174,}agent175 = {
    base = model.NO_PARENT.agent175,
    B = model.NO_PARENT.agent175.B175,
    H = model.NO_PARENT.agent175.H175,
    LA = model.NO_PARENT.agent175.B175.LA175,
    RA = model.NO_PARENT.agent175.B175.RA175,
    LL = model.NO_PARENT.agent175.B175.LL175,
    RL = model.NO_PARENT.agent175.B175.RL175,}agent176 = {
    base = model.NO_PARENT.agent176,
    B = model.NO_PARENT.agent176.B176,
    H = model.NO_PARENT.agent176.H176,
    LA = model.NO_PARENT.agent176.B176.LA176,
    RA = model.NO_PARENT.agent176.B176.RA176,
    LL = model.NO_PARENT.agent176.B176.LL176,
    RL = model.NO_PARENT.agent176.B176.RL176,}agent177 = {
    base = model.NO_PARENT.agent177,
    B = model.NO_PARENT.agent177.B177,
    H = model.NO_PARENT.agent177.H177,
    LA = model.NO_PARENT.agent177.B177.LA177,
    RA = model.NO_PARENT.agent177.B177.RA177,
    LL = model.NO_PARENT.agent177.B177.LL177,
    RL = model.NO_PARENT.agent177.B177.RL177,}agent178 = {
    base = model.NO_PARENT.agent178,
    B = model.NO_PARENT.agent178.B178,
    H = model.NO_PARENT.agent178.H178,
    LA = model.NO_PARENT.agent178.B178.LA178,
    RA = model.NO_PARENT.agent178.B178.RA178,
    LL = model.NO_PARENT.agent178.B178.LL178,
    RL = model.NO_PARENT.agent178.B178.RL178,}agent179 = {
    base = model.NO_PARENT.agent179,
    B = model.NO_PARENT.agent179.B179,
    H = model.NO_PARENT.agent179.H179,
    LA = model.NO_PARENT.agent179.B179.LA179,
    RA = model.NO_PARENT.agent179.B179.RA179,
    LL = model.NO_PARENT.agent179.B179.LL179,
    RL = model.NO_PARENT.agent179.B179.RL179,}agent180 = {
    base = model.NO_PARENT.agent180,
    B = model.NO_PARENT.agent180.B180,
    H = model.NO_PARENT.agent180.H180,
    LA = model.NO_PARENT.agent180.B180.LA180,
    RA = model.NO_PARENT.agent180.B180.RA180,
    LL = model.NO_PARENT.agent180.B180.LL180,
    RL = model.NO_PARENT.agent180.B180.RL180,}agent181 = {
    base = model.NO_PARENT.agent181,
    B = model.NO_PARENT.agent181.B181,
    H = model.NO_PARENT.agent181.H181,
    LA = model.NO_PARENT.agent181.B181.LA181,
    RA = model.NO_PARENT.agent181.B181.RA181,
    LL = model.NO_PARENT.agent181.B181.LL181,
    RL = model.NO_PARENT.agent181.B181.RL181,}agent182 = {
    base = model.NO_PARENT.agent182,
    B = model.NO_PARENT.agent182.B182,
    H = model.NO_PARENT.agent182.H182,
    LA = model.NO_PARENT.agent182.B182.LA182,
    RA = model.NO_PARENT.agent182.B182.RA182,
    LL = model.NO_PARENT.agent182.B182.LL182,
    RL = model.NO_PARENT.agent182.B182.RL182,}agent183 = {
    base = model.NO_PARENT.agent183,
    B = model.NO_PARENT.agent183.B183,
    H = model.NO_PARENT.agent183.H183,
    LA = model.NO_PARENT.agent183.B183.LA183,
    RA = model.NO_PARENT.agent183.B183.RA183,
    LL = model.NO_PARENT.agent183.B183.LL183,
    RL = model.NO_PARENT.agent183.B183.RL183,}agent184 = {
    base = model.NO_PARENT.agent184,
    B = model.NO_PARENT.agent184.B184,
    H = model.NO_PARENT.agent184.H184,
    LA = model.NO_PARENT.agent184.B184.LA184,
    RA = model.NO_PARENT.agent184.B184.RA184,
    LL = model.NO_PARENT.agent184.B184.LL184,
    RL = model.NO_PARENT.agent184.B184.RL184,}agent185 = {
    base = model.NO_PARENT.agent185,
    B = model.NO_PARENT.agent185.B185,
    H = model.NO_PARENT.agent185.H185,
    LA = model.NO_PARENT.agent185.B185.LA185,
    RA = model.NO_PARENT.agent185.B185.RA185,
    LL = model.NO_PARENT.agent185.B185.LL185,
    RL = model.NO_PARENT.agent185.B185.RL185,}agent186 = {
    base = model.NO_PARENT.agent186,
    B = model.NO_PARENT.agent186.B186,
    H = model.NO_PARENT.agent186.H186,
    LA = model.NO_PARENT.agent186.B186.LA186,
    RA = model.NO_PARENT.agent186.B186.RA186,
    LL = model.NO_PARENT.agent186.B186.LL186,
    RL = model.NO_PARENT.agent186.B186.RL186,}agent187 = {
    base = model.NO_PARENT.agent187,
    B = model.NO_PARENT.agent187.B187,
    H = model.NO_PARENT.agent187.H187,
    LA = model.NO_PARENT.agent187.B187.LA187,
    RA = model.NO_PARENT.agent187.B187.RA187,
    LL = model.NO_PARENT.agent187.B187.LL187,
    RL = model.NO_PARENT.agent187.B187.RL187,}agent188 = {
    base = model.NO_PARENT.agent188,
    B = model.NO_PARENT.agent188.B188,
    H = model.NO_PARENT.agent188.H188,
    LA = model.NO_PARENT.agent188.B188.LA188,
    RA = model.NO_PARENT.agent188.B188.RA188,
    LL = model.NO_PARENT.agent188.B188.LL188,
    RL = model.NO_PARENT.agent188.B188.RL188,}agent189 = {
    base = model.NO_PARENT.agent189,
    B = model.NO_PARENT.agent189.B189,
    H = model.NO_PARENT.agent189.H189,
    LA = model.NO_PARENT.agent189.B189.LA189,
    RA = model.NO_PARENT.agent189.B189.RA189,
    LL = model.NO_PARENT.agent189.B189.LL189,
    RL = model.NO_PARENT.agent189.B189.RL189,}agent190 = {
    base = model.NO_PARENT.agent190,
    B = model.NO_PARENT.agent190.B190,
    H = model.NO_PARENT.agent190.H190,
    LA = model.NO_PARENT.agent190.B190.LA190,
    RA = model.NO_PARENT.agent190.B190.RA190,
    LL = model.NO_PARENT.agent190.B190.LL190,
    RL = model.NO_PARENT.agent190.B190.RL190,}agent191 = {
    base = model.NO_PARENT.agent191,
    B = model.NO_PARENT.agent191.B191,
    H = model.NO_PARENT.agent191.H191,
    LA = model.NO_PARENT.agent191.B191.LA191,
    RA = model.NO_PARENT.agent191.B191.RA191,
    LL = model.NO_PARENT.agent191.B191.LL191,
    RL = model.NO_PARENT.agent191.B191.RL191,}agent192 = {
    base = model.NO_PARENT.agent192,
    B = model.NO_PARENT.agent192.B192,
    H = model.NO_PARENT.agent192.H192,
    LA = model.NO_PARENT.agent192.B192.LA192,
    RA = model.NO_PARENT.agent192.B192.RA192,
    LL = model.NO_PARENT.agent192.B192.LL192,
    RL = model.NO_PARENT.agent192.B192.RL192,}agent193 = {
    base = model.NO_PARENT.agent193,
    B = model.NO_PARENT.agent193.B193,
    H = model.NO_PARENT.agent193.H193,
    LA = model.NO_PARENT.agent193.B193.LA193,
    RA = model.NO_PARENT.agent193.B193.RA193,
    LL = model.NO_PARENT.agent193.B193.LL193,
    RL = model.NO_PARENT.agent193.B193.RL193,}agent194 = {
    base = model.NO_PARENT.agent194,
    B = model.NO_PARENT.agent194.B194,
    H = model.NO_PARENT.agent194.H194,
    LA = model.NO_PARENT.agent194.B194.LA194,
    RA = model.NO_PARENT.agent194.B194.RA194,
    LL = model.NO_PARENT.agent194.B194.LL194,
    RL = model.NO_PARENT.agent194.B194.RL194,}agent195 = {
    base = model.NO_PARENT.agent195,
    B = model.NO_PARENT.agent195.B195,
    H = model.NO_PARENT.agent195.H195,
    LA = model.NO_PARENT.agent195.B195.LA195,
    RA = model.NO_PARENT.agent195.B195.RA195,
    LL = model.NO_PARENT.agent195.B195.LL195,
    RL = model.NO_PARENT.agent195.B195.RL195,}agent196 = {
    base = model.NO_PARENT.agent196,
    B = model.NO_PARENT.agent196.B196,
    H = model.NO_PARENT.agent196.H196,
    LA = model.NO_PARENT.agent196.B196.LA196,
    RA = model.NO_PARENT.agent196.B196.RA196,
    LL = model.NO_PARENT.agent196.B196.LL196,
    RL = model.NO_PARENT.agent196.B196.RL196,}agent197 = {
    base = model.NO_PARENT.agent197,
    B = model.NO_PARENT.agent197.B197,
    H = model.NO_PARENT.agent197.H197,
    LA = model.NO_PARENT.agent197.B197.LA197,
    RA = model.NO_PARENT.agent197.B197.RA197,
    LL = model.NO_PARENT.agent197.B197.LL197,
    RL = model.NO_PARENT.agent197.B197.RL197,}agent198 = {
    base = model.NO_PARENT.agent198,
    B = model.NO_PARENT.agent198.B198,
    H = model.NO_PARENT.agent198.H198,
    LA = model.NO_PARENT.agent198.B198.LA198,
    RA = model.NO_PARENT.agent198.B198.RA198,
    LL = model.NO_PARENT.agent198.B198.LL198,
    RL = model.NO_PARENT.agent198.B198.RL198,}agent199 = {
    base = model.NO_PARENT.agent199,
    B = model.NO_PARENT.agent199.B199,
    H = model.NO_PARENT.agent199.H199,
    LA = model.NO_PARENT.agent199.B199.LA199,
    RA = model.NO_PARENT.agent199.B199.RA199,
    LL = model.NO_PARENT.agent199.B199.LL199,
    RL = model.NO_PARENT.agent199.B199.RL199,}agent200 = {
    base = model.NO_PARENT.agent200,
    B = model.NO_PARENT.agent200.B200,
    H = model.NO_PARENT.agent200.H200,
    LA = model.NO_PARENT.agent200.B200.LA200,
    RA = model.NO_PARENT.agent200.B200.RA200,
    LL = model.NO_PARENT.agent200.B200.LL200,
    RL = model.NO_PARENT.agent200.B200.RL200,}
agents = {agent1,agent2,agent3,agent4,agent5,agent6,agent7,agent8,agent9,agent10,agent11,agent12,agent13,agent14,agent15,agent16,agent17,agent18,agent19,agent20,agent21,agent22,agent23,agent24,agent25,agent26,agent27,agent28,agent29,agent30,agent31,agent32,agent33,agent34,agent35,agent36,agent37,agent38,agent39,agent40,agent41,agent42,agent43,agent44,agent45,agent46,agent47,agent48,agent49,agent50,agent51,agent52,agent53,agent54,agent55,agent56,agent57,agent58,agent59,agent60,agent61,agent62,agent63,agent64,agent65,agent66,agent67,agent68,agent69,agent70,agent71,agent72,agent73,agent74,agent75,agent76,agent77,agent78,agent79,agent80,agent81,agent82,agent83,agent84,agent85,agent86,agent87,agent88,agent89,agent90,agent91,agent92,agent93,agent94,agent95,agent96,agent97,agent98,agent99,agent100,agent101,agent102,agent103,agent104,agent105,agent106,agent107,agent108,agent109,agent110,agent111,agent112,agent113,agent114,agent115,agent116,agent117,agent118,agent119,agent120,agent121,agent122,agent123,agent124,agent125,agent126,agent127,agent128,agent129,agent130,agent131,agent132,agent133,agent134,agent135,agent136,agent137,agent138,agent139,agent140,agent141,agent142,agent143,agent144,agent145,agent146,agent147,agent148,agent149,agent150,agent151,agent152,agent153,agent154,agent155,agent156,agent157,agent158,agent159,agent160,agent161,agent162,agent163,agent164,agent165,agent166,agent167,agent168,agent169,agent170,agent171,agent172,agent173,agent174,agent175,agent176,agent177,agent178,agent179,agent180,agent181,agent182,agent183,agent184,agent185,agent186,agent187,agent188,agent189,agent190,agent191,agent192,agent193,agent194,agent195,agent196,agent197,agent198,agent199,agent200}

--dragekk's original idea

finishedLoading = false
function player_init()
    for key, value in pairs(agents) do
        value.base.setScale({0.95,0.95,0.95})
        position[key] = player.getPos()
        declareNewAgentStats()
    end
    finishedLoading = true
end

function tick()
    if finishedLoading then
        for key, value in pairs(agents) do
            position[key] = position[key] + velocity[key]
            velocity[key] = velocity[key] * vectors.of({0.6,1,0.6})
    
            local coll = collision(position[key])
            position[key] = coll.position
            velocity[key] = velocity[key] + vectors.of({0,-0.08})
    
            if coll.isColliding then
                velocity[key].y = 0.0001
            end
            local distanceToPlayer = vectors.of({position[key].x,0,position[key].z}).distanceTo((vectors.of({player.getPos().x,0,player.getPos().z})+offsetTarget[key]))
            if distanceToPlayer > 1 then
                local movement = (player.getPos()-position[key]+offsetTarget[key]).normalized()*0.1
                
                if distanceToPlayer > 5 then
                    movement = (player.getPos()-position[key]+offsetTarget[key]).normalized()*0.15
                    if coll.isColliding then
                        velocity[key].y = 0.4
                    end
                end
                velocity[key] = velocity[key] + vectors.of({movement.x,0,movement.z})
            end
            
            if world.getBlockState(position[key]+vectors.of({0,0.5,0})).name == "minecraft:water" then
                velocity[key] = velocity[key] * vectors.of({0.7,0.8,0.7})
                velocity[key] = velocity[key] + vectors.of({0,0.1,0})
            end

            distVelocity[key] = vectors.of({}).distanceTo(vectors.of({velocity[key].x,0,velocity[key].z}))
            distanceWalked[key] = distanceWalked[key] + distVelocity[key]

            if wanderTimer[key] < 0 then
                wanderTimer[key] = math.random()*20*5
                offsetTarget[key] = vectors.of({math.random()*50-25,0,math.random()*50-25})
            end
            wanderTimer[key] = wanderTimer[key] - 1
        end
    end
end

function world_render(delta)
    if finishedLoading then
        for key, value in pairs(agents) do
            value.base.setPos(vectors.lerp(value.base.getPos(),vectors.of({position[key].x*-16,position[key].y*-16,position[key].z*16}),delta))

            if velocity[key].distanceTo(vectors.of({})) > 0.01 then
                value.B.setRot({0,lerp_angle(value.B.getRot().y,math.deg(math.atan2(velocity[key].x,velocity[key].z))+180,delta)})
            end
            local lukat = velocity[key] * vectors.of({-1,-1,-1})

            targetRotation[key] = vectors.of({0,math.deg(math.atan2(lukat.x,lukat.z)),0})
            value.H.setRot({
                lerp_angle(value.H.getRot().x,targetRotation[key].x,delta),
                lerp_angle(value.H.getRot().y,targetRotation[key].y,delta),
                lerp_angle(value.H.getRot().z,targetRotation[key].z,delta)})
            local swing = (math.sin(distanceWalked[key]*2.3)*45)*math.min(distVelocity[key]*32,1)
            value.LL.setRot({lerp(value.LL.getRot().x,swing,delta)})
            value.RL.setRot({lerp(value.RL.getRot().x,-swing,delta)})
            value.LA.setRot({lerp(value.LA.getRot().x,swing,delta)})
            value.RA.setRot({lerp(value.RA.getRot().x,-swing,delta)})
        end
    end
end

function lerp(a, b, x)
    return a + (b - a) * x
end

function lerp_angle(a, b, x)
    local diff = (b-a)
    local delta = diff-(math.floor(diff/360)*360)
    if delta > 180 then
        delta = delta - 360
    end
    return a + delta * x
end

--for future plans
function declareNewAgentStats()
    table.insert(position,vectors.of({0,0,0}))
    table.insert(velocity,vectors.of({0,0,0}))
    table.insert(targetRotation,vectors.of({0,0,0}))
    table.insert(distanceWalked,0)
    table.insert(distVelocity,0)
    table.insert(offsetTarget,vectors.of({0,0,0}))
    table.insert(wanderTimer,0)
end

--collision detection by GNamimates#9366
--give it a 3D position and it will return back the position but adjusted to the closest surface
function collision(pos)-- sorry idk what to name this lmao
    local point = vectors.of({pos.x,pos.y,pos.z})
    local collision = world.getBlockState(point).getCollisionShape()
    local blockPos = vectors.of({point.x-math.floor(point.x),point.y-math.floor(point.y),point.z-math.floor(point.z)})
    local iscoll = false

    for index, value in ipairs(collision) do--loop through all the collision boxes
        if value.x < blockPos.x and value.w > blockPos.x then-- checks if inside the collision box
            if value.y < blockPos.y and value.t > blockPos.y then
                if value.z < blockPos.z and value.h > blockPos.z then
                    --detected inside the cube
                    local currentPoint = point--for somethin idk
                    --finding the closest surface from the cube
                    point.y = math.floor(currentPoint.y)+value.t
                    iscoll = true
                end
            end
        end
    end
    return {position=point,isColliding=iscoll}
end