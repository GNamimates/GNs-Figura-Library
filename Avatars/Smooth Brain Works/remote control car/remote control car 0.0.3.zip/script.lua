---@diagnostic disable: undefined-global,undefined-field
--=====CONFIG==========================
--NOTE THIS ONLY WORKS FOR FIGURA 0.0.7+
CarCamMode = false -- if the player camera should be inside the vehicle
friction = 0.8

--paths
-- change steeringWHeel to nil if you dont want a steering wheel >:P 
steeringWHeel = model.NO_PARENT_car.offset.steeringWheel.joint
offset = model.NO_PARENT_car.offset
wheels = {
    front = {--front wheels
        model.NO_PARENT_car.FL,
        model.NO_PARENT_car.FR,

    },
    back = {--back wheels
        model.NO_PARENT_car.BL,
        model.NO_PARENT_car.BR,
    }
}
--the lower the value is, the smoother the car moves, default is good alraedy
stiffness = vectors.of({0.5,0.5,0.5})--different for each axis
stiffnessRot = 0.2

--============CREDITS=================
--
--thanks to _Rayop_ for the car structure
--and the wonderful internet for helping me GNamimates code this easier than I expected :)

--=======================================
position = vectors.of({0,1,0})
rotation = 0
linear_velocity = vectors.of({0,0,0})

serverPos = position
serverRot = rotation

--STATS N STUFF

positionUpdateTimer = 0

localLinearVelocity = {x=0,y=0,z=0}
distanceDriven = 0
airTime = 0
lowOffset = 0.0
tilt = 0 --front n back | used so when climbing blocks the car would look up1

angular_velocity = 10 -- only Y
steer = 0

--== keybinds ==--
throttle = keybind.newKey("Throttle","U")
reverse = keybind.newKey("Reverse","J")
steerRight = keybind.newKey("Steer Right","K")
steerLeft = keybind.newKey("Steer Left","H")
reset = keybind.newKey("Reset","N")
FPSkeybind = keybind.newKey("Car cam","F7")

STEER = 10
SPEED = 0.05


function player_init()
    --== making stuff work on multiplayer ==-
    ping.posUpdate = function(arg) serverPos = arg.p serverRot = arg.r end
    position = vectors.of({math.floor(player.getPos().x)+0.5,math.floor(player.getPos().y),math.floor(player.getPos().z)+0.5})
    serverPos = position
end

function tick()
    if client.isHost() then
        positionUpdateTimer = positionUpdateTimer + 1

        if positionUpdateTimer > 5 then
            ping.posUpdate({p=position,r=rotation})
        end

        if FPSkeybind.wasPressed() then
            CarCamMode = not CarCamMode
        end

        if reset.wasPressed() then
            position = vectors.of({math.floor(player.getPos().x)+0.5,math.floor(player.getPos().y),math.floor(player.getPos().z)+0.5})
            rotation = -player.getRot().y+180
            linear_velocity = vectors.of({0,0,0})
        end
        --==PHYSICS
        position = position + linear_velocity
        rotation = rotation + angular_velocity
        --getting velocity locally to car rotation
        localLinearVelocity.z = (
            math.sin(math.rad(-rotation))*linear_velocity.x)-
            (math.cos(math.rad(-rotation))*linear_velocity.z)
        localLinearVelocity.x = (
            math.sin(math.rad(rotation))*linear_velocity.z)-
            (math.cos(math.rad(rotation))*linear_velocity.x)

        linear_velocity.x = linear_velocity.x * friction
        linear_velocity.z = linear_velocity.z * friction
        distanceDriven = distanceDriven + localLinearVelocity.z*360

        if math.abs(angular_velocity) > 0.01 then
            angular_velocity = angular_velocity * friction
        else
            angular_velocity = 0
        end

        --==CONTROLS
        --THROTTLE
        if throttle.isPressed() then
            linear_velocity = linear_velocity + vectors.of({math.sin(math.rad(serverRot))*-SPEED,0,math.cos(math.rad(serverRot))*-SPEED})
        end
        if reverse.isPressed() then
            linear_velocity = linear_velocity + vectors.of({math.sin(math.rad(serverRot))*SPEED,0,math.cos(math.rad(serverRot))*SPEED})
        end
        steer = 0
        --STERRING
        if steerRight.isPressed() then
            steer = -STEER
        end
        if steerLeft.isPressed() then
            steer = STEER
        end
        angular_velocity = angular_velocity + (steer*localLinearVelocity.z)
        --check if inside the ground
        --check if standing on solid ground
        --check if standing on slabs
        --Y adjustment
        local floorPos = position
        local coll = collision(floorPos,linear_velocity)

        position.y = position.y + linear_velocity.y
        if coll.isColliding then
            linear_velocity.y = 0.0001
            position = coll.position
        else
            linear_velocity.y = linear_velocity.y-0.02
        end
    end
end

function getMaxHeight(pointPos)
    local final = pointPos
        aabbs = world.getBlockState(pointPos).getCollisionShape()
        for index, value in ipairs(aabbs) do
            if value.x < final[1]-math.floor(final[1]) and value.w > final[1]-math.floor(final[1]) then
                if value.z < final[3]-math.floor(final[3]) and value.h > final[3]-math.floor(final[3]) then
                    final[2] = math.floor(final[2])+value.t--adjusts the position to the height of the ceilinEIGHEAGNEKADEVNI~$%!#@!%^$#()
                end
            end
        end
    return final
end


function world_render(delta)
     --Display
    if steeringWHeel ~= nil then
        steeringWHeel.setRot({0,0,lerp(steeringWHeel.getRot().z,steer*7,0.2)})
    end
    if client.isHost() then
        offset.setPos({0,lerp(lowOffset,offset.getPos().y,stiffness.y),0})
        offset.setRot({localLinearVelocity.z*20,0,localLinearVelocity.x*50})
        model.NO_PARENT_car.setPos({lerp(model.NO_PARENT_car.getPos().x,position.x*-16,stiffness.x),lerp(model.NO_PARENT_car.getPos().y,position.y*-16,stiffness.y),lerp(model.NO_PARENT_car.getPos().z,position.z*16,stiffness.z)})
        model.NO_PARENT_car.setRot({0,lerp(model.NO_PARENT_car.getRot().y,rotation,stiffnessRot),0})
    else
        offset.setPos({0,lerp(lowOffset,offset.getPos().y,stiffness.y),0})
        offset.setRot({localLinearVelocity.z*20,0,localLinearVelocity.x*50})
        model.NO_PARENT_car.setPos({lerp(model.NO_PARENT_car.getPos().x,serverPos.x*-16,stiffness.x),lerp(model.NO_PARENT_car.getPos().y,serverPos.y*-16,stiffness.y),lerp(model.NO_PARENT_car.getPos().z,serverPos.z*16,stiffness.z)})
        model.NO_PARENT_car.setRot({0,lerp(model.NO_PARENT_car.getRot().y,serverRot,stiffnessRot),0})
    end
    
    --wheels
    for index, value in ipairs(wheels.back) do
        if localLinearVelocity.z < 0.2 then
            if throttle.isPressed() then
                particle.addParticle("minecraft:block",vectors.of({
                    (model.NO_PARENT_car.getPos().x/-16)+(math.cos(math.rad(-rotation))*(value.getPivot().x/16))+(math.sin(math.rad(rotation))*(value.getPivot().z/-16)),
                    model.NO_PARENT_car.getPos().y/-16,
                    (model.NO_PARENT_car.getPos().z/16)+(math.sin(math.rad(-rotation))*(value.getPivot().x/16))+(math.cos(math.rad(rotation))*(value.getPivot().z/-16)),
                    math.sin(math.rad(serverRot)),0,math.cos(math.rad(rotation))}),world.getBlockState(serverPos+vectors.of({0,-0.01,0})).name)
            end--back wheels
            value.setRot({-distanceDriven,0,0})
        end
    end
    --front wheels
    for index, value in ipairs(wheels.front) do
        value.setRot({-distanceDriven,lerp(value.getRot().y,steer*3,0.2),0})
    end

    if CarCamMode then
        camera.FIRST_PERSON.setRot(model.NO_PARENT_car.getRot()*vectors.of({-1,-1,-1}))
        cameraSetWorldPos({
            (model.NO_PARENT_car.getPos()+model.NO_PARENT_car.offset.getPos())/vectors.of({-16,-16,16})+
            (vectors.of({
                math.cos(math.rad(model.NO_PARENT_car.getRot().y*-1))*-0.15,
                0.8,
                math.sin(math.rad(model.NO_PARENT_car.getRot().y*-1))*-0.15
            }))
        })
        
    else
        camera.FIRST_PERSON.setRot({0,0,0})
        camera.FIRST_PERSON.setPos({0,0,0})
    end
end


function ping.posUpdate(arg)
    serverPos = arg.p
    serverRot = arg.r
end


function lerp(a, b, x)
    return a + (b - a) * x
end


function tableDistance(table)
    local result = 0.0
    for I, _ in pairs(table) do
        result = result + math.pow(table[I],2)
    end
    return math.sqrt(result)
end

function dotp(value)
    return value/math.abs(value)
end

--cameraSetWorldPos by dragekk
--it isnt going to work if you set camera rotation after running this function
function cameraSetWorldPos(cam)
    if type(cam) == "table" then
        cam = vectors.of(cam)
    end
    local pos = cam-player.getPos()-vectors.of({0, player.getEyeHeight()})
    local cam_rot = camera.FIRST_PERSON.getRot()
    if not cam_rot then
        cam_rot = vectors.of({0, 0, 0})
    end
    local rot = player.getRot()+cam_rot
    local x = math.cos(math.rad(rot.y-90))*-pos.z+math.sin(math.rad(rot.y-90))*pos.x
    local z = math.cos(math.rad(rot.y))*-pos.z+math.sin(math.rad(rot.y))*pos.x
    local z = 1/math.cos(math.rad(rot.x))*z
    camera.FIRST_PERSON.setPos({
        math.min(math.max(x, -256), 256),
        math.min(math.max(pos.y-math.sin(math.rad(rot.x))*z, -256), 256),
        math.min(math.max(z, -256), 256)
    })
end

function collision(position)-- sorry idk what to name this lmao
    local point = vectors.of({position.x,position.y,position.z})
    local collision = world.getBlockState(point).getCollisionShape()
    local blockPos = vectors.of({point.x-math.floor(point.x),point.y-math.floor(point.y),point.z-math.floor(point.z)})
    local isColliding = false
    local normal = vectors.of({1,1,1})

    for index, value in ipairs(collision) do--loop through all the collision boxes
        if value.x < blockPos.x and value.w > blockPos.x then-- checks if inside the collision box
            if value.y < blockPos.y and value.t > blockPos.y then
                if value.z < blockPos.z and value.h > blockPos.z then
                    isColliding = true
                    point.y = math.floor(point.y)+value.t
                end
            end
        end
    end
    return {position=point,isColliding=isColliding}
end

--function collision(position)-- sorry idk what to name this lmao
--    local point = vectors.of({position.x,position.y,position.z})
--    local collision = world.getBlockState(point).getCollisionShape()
--    local blockPos = vectors.of({point.x-math.floor(point.x),point.y-math.floor(point.y),point.z-math.floor(point.z)})
--    local isColliding = false
--    local normal = vectors.of({1,1,1})
--
--    for index, value in ipairs(collision) do--loop through all the collision boxes
--        if value.x < blockPos.x and value.w > blockPos.x then-- checks if inside the collision box
--            if value.y < blockPos.y and value.t > blockPos.y then
--                if value.z < blockPos.z and value.h > blockPos.z then
--                    isColliding = true
--                    --detected inside the cube
--                    local closest = 9999--used to see what is the closes face
--                    local whoClosest = 0
--                    local currentPoint = point--for somethin idk
--                    --finding the closest surface from the cube
--                    if math.abs(value.x-blockPos.x) < closest then
--                        closest = math.abs(value.x-blockPos.x)
--                        whoClosest = 0
--                    end
--                    if math.abs(value.y-blockPos.y) < closest then
--                        closest = math.abs(value.y-blockPos.y)
--                        whoClosest = 1
--                    end
--                    if math.abs(value.z-blockPos.z) < closest then
--                        closest = math.abs(value.z-blockPos.z)
--                        whoClosest = 2
--                    end
--                    
--                    if math.abs(value.w-blockPos.x) < closest then
--                        closest = math.abs(value.w-blockPos.x)
--                        whoClosest = 3
--                    end
--                    if math.abs(value.t-blockPos.y) < closest then
--                        closest = math.abs(value.t-blockPos.y)
--                        whoClosest = 4
--                    end
--                    if math.abs(value.h-blockPos.z) < closest then
--                        closest = math.abs(value.h-blockPos.z)
--                        whoClosest = 5
--                    end
--                    --snap the closest surfance to the point
--                    if whoClosest == 0 then
--                        point.x = math.floor(currentPoint.x)+value.x
--                        normal = vectors.of({1,0,0})
--                    end
--                    if whoClosest == 1 then
--                        point.y = math.floor(currentPoint.y)+value.y
--                        normal = vectors.of({0,1,0})
--                    end
--                    if whoClosest == 2 then
--                        point.z = math.floor(currentPoint.z)+value.z
--                        normal = vectors.of({0,0,1})
--                    end
--                    if whoClosest == 3 then
--                        point.x =  math.floor(currentPoint.x)+value.w
--                        normal = vectors.of({1,0,0})
--                    end
--                    if whoClosest == 4 then
--                        point.y = math.floor(currentPoint.y)+value.t
--                        normal = vectors.of({0,1,0})
--                    end
--                    if whoClosest == 5 then
--                        point.z =  math.floor(currentPoint.z)+value.h
--                        normal = vectors.of({0,0,1})
--                    end
--                end
--            end
--        end
--    end
--    return {position=point,isColliding=isColliding,normal=normal}
--end