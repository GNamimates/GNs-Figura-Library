--[[--============================================================================--
░██████╗░███╗░░██╗░█████╗░███╗░░░███╗██╗███╗░░░███╗░█████╗░████████╗███████╗░██████╗
██╔════╝░████╗░██║██╔══██╗████╗░████║██║████╗░████║██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░██╗░██╔██╗██║███████║██╔████╔██║██║██╔████╔██║███████║░░░██║░░░█████╗░░╚█████╗░
██║░░╚██╗██║╚████║██╔══██║██║╚██╔╝██║██║██║╚██╔╝██║██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚██████╔╝██║░╚███║██║░░██║██║░╚═╝░██║██║██║░╚═╝░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚═════╝░╚═╝░░╚══╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═╝╚═╝░░░░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░
]]--============================================================================--[[
margin = 0.0001

portalSize = {x=1,y=1}
viewportRes = {x=32,y=32}

alwaysUpdate = true
lastCamPos = vectors.of{}

isUsingHotfix = false

color = {}
pathCache = {}


model.NO_PARENT.setScale({portalSize.x/(viewportRes.x/16),portalSize.y/(viewportRes.y/16),-0.01})

mirror_pos = vectors.of {}
ping.moveMirror = function(pos)
    mirror_pos = pos
    model.NO_PARENT.setPos(mirror_pos * vectors.of {-16, -16, 16})
    updateViewport()
end

data.setName("GN-mirror")
do
    local pos = data.load("pos")
    if pos then
        ping.moveMirror(pos)
    end
end

for y = 1, viewportRes.y, 1 do
    for x = 1, viewportRes.x, 1 do
        table.insert(pathCache,model.NO_PARENT["x"..tostring(x-1).."y"..tostring(y-1)])
    end
end

action_wheel.SLOT_1.setItem("minecraft:glass_pane")
action_wheel.SLOT_1.setTitle("placeMirror")
action_wheel.SLOT_1.setFunction(function()
    local pos = player.getTargetedBlockPos(false) + vectors.of {0, 1, 0}
    ping.moveMirror(pos)
    data.save("pos", pos)
end)

action_wheel.SLOT_2.setItem("minecraft:magenta_glazed_terracotta")
action_wheel.SLOT_2.setTitle("toggle Orientation")
action_wheel.SLOT_2.setFunction(function()
    local pos = player.getTargetedBlockPos(false) + vectors.of {0, 1, 0}
    ping.moveMirror(pos)
    data.save("pos", pos)
end)

renderMode = 1
modes ={
    "final composition",
    "albedo map",
    "light map",
    "normal map",
    "update heatmap"
}

action_wheel.SLOT_3.setTitle("Toggle Render Mode: "..modes[renderMode])
action_wheel.SLOT_3.setItem("minecraft:glowstone")
action_wheel.SLOT_3.setFunction(function ()
    renderMode = (renderMode%5)+1
    action_wheel.SLOT_3.setTitle("Toggle Render Mode: "..modes[renderMode])
end)



if meta.getFiguraVersion() == "0.0.8+1.18.2" then
    isUsingHotfix = true
end

function tick()
    if alwaysUpdate then
        updateViewport()
    end
end
lastColor = {}

function updateViewport()
    color = {}
    local c = 0
    local update = {}
    for y = 1, viewportRes.y, 1 do
        for x = 1, viewportRes.x, 1 do
            table.insert(update,{x,y})
        end
    end
    while #update ~= 0 do
        local targetTile = math.floor(math.random()*(#update-1))+1
        value = update[targetTile]
        table.remove(update,targetTile)
        local x = value[1]
        local y = value[2]
        c = x+(y-1)*viewportRes.x
        local worldPos = mirror_pos+(vectors.of{(x-0.5)*portalSize.x,(y-0.5)*portalSize.y}/vectors.of{viewportRes})
        local rayTo = worldPos+((renderer.getCameraPos()-worldPos)*vectors.of{-1,-1,-1}).normalized()*20

        local ray = renderer.raycastBlocks(worldPos,rayTo, "VISUAL", "ANY")
        local rayDir = (worldPos-rayTo).normalized()
        local finalColor = vectors.of{}
        if isUsingHotfix then
            finalColor = world.getBiome(renderer.getCameraPos()).getSkyColor()
        end
        
        local LightingShading = 15
        local SurfacenormalShading = 1
        if ray then
            local targetPos = vectors.of{math.floor(ray.pos.x+rayDir.x*margin),math.floor(ray.pos.y+rayDir.y*margin),math.floor(ray.pos.z+rayDir.z*margin)}
            local offset = targetPos-ray.pos+vectors.of{0.5,0.5,0.5}
            if renderMode == 1 then
                offset = vectors.of{math.abs(offset.x),math.abs(offset.y),math.abs(offset.z)}
                if math.abs(offset.x) > math.abs(offset.y) or math.abs(offset.z) > math.abs(offset.y) then
                    SurfacenormalShading = 0.5
                end
                if math.abs(offset.x) > math.abs(offset.z) and math.abs(offset.x) > math.abs(offset.y) then
                    SurfacenormalShading = 0.4
                end
            end
            if renderMode == 1 or renderMode == 3 then
                LightingShading = math.max(world.getBlockLightLevel(targetPos),world.getSkyLightLevel(targetPos))
            end
            finalColor = vectors.intToRGB(ray.state.getMapColor())*(LightingShading/15)*SurfacenormalShading
        end
        if type(lastColor[c]) ~= "nil" then
            if lastColor[c].x ~= finalColor.x or lastColor[c].y ~= finalColor.y or lastColor[c].z ~= finalColor.z then
                pathCache[c].setColor(finalColor)
                lastColor[c] = finalColor
            else
                if renderMode == 5 then
                    pathCache[c].setColor({0,0,0})
                end
            end
        else
            lastColor[c] = vectors.of{}
            pathCache[c].setColor({0,1,0})
        end
        --model.NO_PARENT["row" .. tostring(y)]["cube" ..tostring(x + (y - 1))].setColor(screenPos)
    end
end

function player_init()
    local format = "POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL"
    local vertexSource = [==[
    #version 150

    in vec3 Position;
    in vec4 Color;
    in vec2 UV0;
    in ivec2 UV1;
    in ivec2 UV2;
    in vec3 Normal;

    uniform sampler2D Sampler1; //Overlay Sampler
    uniform sampler2D Sampler2; //Lightmap Sampler

    uniform mat4 ModelViewMat;
    uniform mat4 ProjMat;

    uniform vec3 Light0_Direction;
    uniform vec3 Light1_Direction;

    out float vertexDistance;
    out vec4 vertexColor;
    out vec4 lightMapColor;
    out vec4 overlayColor;
    out vec2 texCoord0;
    out vec4 normal;

    void main() {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
        vertexColor = Color;
        texCoord0 = vec2(0,0);
        normal = ProjMat * ModelViewMat * vec4(Normal, 0.0);
          }
        ]==]
        local fragmentSource = [==[
    #version 150

    uniform sampler2D Sampler0;

    uniform vec4 ColorModulator;
    uniform float FogStart;
    uniform float FogEnd;
    uniform vec4 FogColor;

    in float vertexDistance;
    in vec4 vertexColor;
    in vec4 lightMapColor;
    in vec4 overlayColor;
    in vec2 texCoord0;
    in vec4 normal;

    out vec4 fragColor;

    void main() {
        fragColor = vertexColor;
    }
    ]==]
    renderlayers.registerShader("noShade", format, vertexSource, fragmentSource, 1, {})
    local intro = function()
        renderlayers.useShader("noShade")
        renderlayers.enableDepthTest()
        renderlayers.disableCull()
    end
    local outro = function()
        renderlayers.restoreDefaults()
    end
    renderlayers.registerRenderLayer("fullBrightL", {}, intro, outro)
    model.NO_PARENT.setRenderLayer("fullBrightL")
end