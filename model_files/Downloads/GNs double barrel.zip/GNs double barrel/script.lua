model.shot.primaryHand.cube.setTexture("Skin")
model.shot.secondaryHand.cube.setTexture("Skin")

vanilla_model.RIGHT_ARM.setEnabled(false)
vanilla_model.RIGHT_SLEEVE.setEnabled(false)

vanilla_model.LEFT_ARM.setEnabled(false)
vanilla_model.LEFT_SLEEVE.setEnabled(false)

currentPosition = nil
lastPosition = nil
velocity = nil

shoot = keybind.newKey("Shoot","MOUSE_BUTTON_1")
holdingShoot = false

currentRotation = nil
lastRotation = nil

shootCooldownTime = 20
cooldown = 0

maxAmmo = 9999999999

ammo = maxAmmo
power = 10

keybind.newKey("Reload","R")

isHoldingNothing = false
wasHoldingNothing = false

function player_init()
    currentPosition = player.getPos()
    lastPosition = currentPosition
    velocity = vectors.of({0})

    currentRotation = player.getRot()
    lastRotation = currentRotation
    animation.intro.play()
    
end

function tick()
    wasHoldingNothing = isHoldingNothing
    isHoldingNothing = (player.getEquipmentItem(1).getType() == "minecraft:air")
    cooldown = cooldown + 1

    if wasHoldingNothing ~= isHoldingNothing then
        if isHoldingNothing then
            model.shot.setEnabled(true)
            vanilla_model.RIGHT_ARM.setEnabled(false)
            vanilla_model.RIGHT_SLEEVE.setEnabled(false)

            vanilla_model.LEFT_ARM.setEnabled(false)
            vanilla_model.LEFT_SLEEVE.setEnabled(false)
            animation.intro.play()
        else
            model.shot.setEnabled(false)
            vanilla_model.RIGHT_ARM.setEnabled(true)
            vanilla_model.RIGHT_SLEEVE.setEnabled(true)

            vanilla_model.LEFT_ARM.setEnabled(true)
            vanilla_model.LEFT_SLEEVE.setEnabled(true)
        end
    end

    if isHoldingNothing then
        if holdingShoot ~= shoot.isPressed() then
            if shoot.isPressed() then
                if ammo > 0 then
                    if shootCooldownTime < cooldown then
                        animation.shoot.play()
                        sound.playCustomSound("shoot",player.getPos(),{1,1})
                        chat.sendMessage("/summon arrow ~ ~1.5 ~ {Motion:["..player.getLookDir().x*power..","..player.getLookDir().y*power..","..player.getLookDir().z*power.."]}")
                        cooldown = 0
                        ammo = ammo - 1
                    end
                end
            end
        end
        holdingShoot = shoot.isPressed()
        if ammo <= 0 and cooldown > shootCooldownTime then
            if not animation.reload.isPlaying() then
                animation.shoot.stop()
                animation.reload.play()
                ammo = maxAmmo
                cooldown = 20
                sound.playCustomSound("reload",player.getPos(),{1,1})
            end
        end
    end

    

    lastPosition = currentPosition
    currentPosition = player.getPos()
    velocity = currentPosition - lastPosition

    lastRotation = currentRotation
    currentRotation = player.getRot()
end

function world_render(delta)
    --model.NO_PARENT.setPos((vectors.lerp(lastPosition,currentPosition,delta)*vectors.of({-16,-16,16}))-vectors.of({0,player.getEyeHeight()*16}))
    model.shot.setRot((vectors.lerp(lastRotation,currentRotation,delta)*vectors.of({-1,0,-1})))
end