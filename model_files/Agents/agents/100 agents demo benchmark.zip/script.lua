position = {}
velocity = {}
targetRotation = {}
distanceWalked = {}
distVelocity = {}
offsetTarget = {}
wanderTimer = {}

agent1 = {
    base = model.NO_PARENT.agent1,
    B = model.NO_PARENT.agent1.B1,
    H = model.NO_PARENT.agent1.H1,
    LA = model.NO_PARENT.agent1.B1.LA1,
    RA = model.NO_PARENT.agent1.B1.RA1,
    LL = model.NO_PARENT.agent1.B1.LL1,
    RL = model.NO_PARENT.agent1.B1.RL1,}agent2 = {
    base = model.NO_PARENT.agent2,
    B = model.NO_PARENT.agent2.B2,
    H = model.NO_PARENT.agent2.H2,
    LA = model.NO_PARENT.agent2.B2.LA2,
    RA = model.NO_PARENT.agent2.B2.RA2,
    LL = model.NO_PARENT.agent2.B2.LL2,
    RL = model.NO_PARENT.agent2.B2.RL2,}agent3 = {
    base = model.NO_PARENT.agent3,
    B = model.NO_PARENT.agent3.B3,
    H = model.NO_PARENT.agent3.H3,
    LA = model.NO_PARENT.agent3.B3.LA3,
    RA = model.NO_PARENT.agent3.B3.RA3,
    LL = model.NO_PARENT.agent3.B3.LL3,
    RL = model.NO_PARENT.agent3.B3.RL3,}agent4 = {
    base = model.NO_PARENT.agent4,
    B = model.NO_PARENT.agent4.B4,
    H = model.NO_PARENT.agent4.H4,
    LA = model.NO_PARENT.agent4.B4.LA4,
    RA = model.NO_PARENT.agent4.B4.RA4,
    LL = model.NO_PARENT.agent4.B4.LL4,
    RL = model.NO_PARENT.agent4.B4.RL4,}agent5 = {
    base = model.NO_PARENT.agent5,
    B = model.NO_PARENT.agent5.B5,
    H = model.NO_PARENT.agent5.H5,
    LA = model.NO_PARENT.agent5.B5.LA5,
    RA = model.NO_PARENT.agent5.B5.RA5,
    LL = model.NO_PARENT.agent5.B5.LL5,
    RL = model.NO_PARENT.agent5.B5.RL5,}agent6 = {
    base = model.NO_PARENT.agent6,
    B = model.NO_PARENT.agent6.B6,
    H = model.NO_PARENT.agent6.H6,
    LA = model.NO_PARENT.agent6.B6.LA6,
    RA = model.NO_PARENT.agent6.B6.RA6,
    LL = model.NO_PARENT.agent6.B6.LL6,
    RL = model.NO_PARENT.agent6.B6.RL6,}agent7 = {
    base = model.NO_PARENT.agent7,
    B = model.NO_PARENT.agent7.B7,
    H = model.NO_PARENT.agent7.H7,
    LA = model.NO_PARENT.agent7.B7.LA7,
    RA = model.NO_PARENT.agent7.B7.RA7,
    LL = model.NO_PARENT.agent7.B7.LL7,
    RL = model.NO_PARENT.agent7.B7.RL7,}agent8 = {
    base = model.NO_PARENT.agent8,
    B = model.NO_PARENT.agent8.B8,
    H = model.NO_PARENT.agent8.H8,
    LA = model.NO_PARENT.agent8.B8.LA8,
    RA = model.NO_PARENT.agent8.B8.RA8,
    LL = model.NO_PARENT.agent8.B8.LL8,
    RL = model.NO_PARENT.agent8.B8.RL8,}agent9 = {
    base = model.NO_PARENT.agent9,
    B = model.NO_PARENT.agent9.B9,
    H = model.NO_PARENT.agent9.H9,
    LA = model.NO_PARENT.agent9.B9.LA9,
    RA = model.NO_PARENT.agent9.B9.RA9,
    LL = model.NO_PARENT.agent9.B9.LL9,
    RL = model.NO_PARENT.agent9.B9.RL9,}agent10 = {
    base = model.NO_PARENT.agent10,
    B = model.NO_PARENT.agent10.B10,
    H = model.NO_PARENT.agent10.H10,
    LA = model.NO_PARENT.agent10.B10.LA10,
    RA = model.NO_PARENT.agent10.B10.RA10,
    LL = model.NO_PARENT.agent10.B10.LL10,
    RL = model.NO_PARENT.agent10.B10.RL10,}agent11 = {
    base = model.NO_PARENT.agent11,
    B = model.NO_PARENT.agent11.B11,
    H = model.NO_PARENT.agent11.H11,
    LA = model.NO_PARENT.agent11.B11.LA11,
    RA = model.NO_PARENT.agent11.B11.RA11,
    LL = model.NO_PARENT.agent11.B11.LL11,
    RL = model.NO_PARENT.agent11.B11.RL11,}agent12 = {
    base = model.NO_PARENT.agent12,
    B = model.NO_PARENT.agent12.B12,
    H = model.NO_PARENT.agent12.H12,
    LA = model.NO_PARENT.agent12.B12.LA12,
    RA = model.NO_PARENT.agent12.B12.RA12,
    LL = model.NO_PARENT.agent12.B12.LL12,
    RL = model.NO_PARENT.agent12.B12.RL12,}agent13 = {
    base = model.NO_PARENT.agent13,
    B = model.NO_PARENT.agent13.B13,
    H = model.NO_PARENT.agent13.H13,
    LA = model.NO_PARENT.agent13.B13.LA13,
    RA = model.NO_PARENT.agent13.B13.RA13,
    LL = model.NO_PARENT.agent13.B13.LL13,
    RL = model.NO_PARENT.agent13.B13.RL13,}agent14 = {
    base = model.NO_PARENT.agent14,
    B = model.NO_PARENT.agent14.B14,
    H = model.NO_PARENT.agent14.H14,
    LA = model.NO_PARENT.agent14.B14.LA14,
    RA = model.NO_PARENT.agent14.B14.RA14,
    LL = model.NO_PARENT.agent14.B14.LL14,
    RL = model.NO_PARENT.agent14.B14.RL14,}agent15 = {
    base = model.NO_PARENT.agent15,
    B = model.NO_PARENT.agent15.B15,
    H = model.NO_PARENT.agent15.H15,
    LA = model.NO_PARENT.agent15.B15.LA15,
    RA = model.NO_PARENT.agent15.B15.RA15,
    LL = model.NO_PARENT.agent15.B15.LL15,
    RL = model.NO_PARENT.agent15.B15.RL15,}agent16 = {
    base = model.NO_PARENT.agent16,
    B = model.NO_PARENT.agent16.B16,
    H = model.NO_PARENT.agent16.H16,
    LA = model.NO_PARENT.agent16.B16.LA16,
    RA = model.NO_PARENT.agent16.B16.RA16,
    LL = model.NO_PARENT.agent16.B16.LL16,
    RL = model.NO_PARENT.agent16.B16.RL16,}agent17 = {
    base = model.NO_PARENT.agent17,
    B = model.NO_PARENT.agent17.B17,
    H = model.NO_PARENT.agent17.H17,
    LA = model.NO_PARENT.agent17.B17.LA17,
    RA = model.NO_PARENT.agent17.B17.RA17,
    LL = model.NO_PARENT.agent17.B17.LL17,
    RL = model.NO_PARENT.agent17.B17.RL17,}agent18 = {
    base = model.NO_PARENT.agent18,
    B = model.NO_PARENT.agent18.B18,
    H = model.NO_PARENT.agent18.H18,
    LA = model.NO_PARENT.agent18.B18.LA18,
    RA = model.NO_PARENT.agent18.B18.RA18,
    LL = model.NO_PARENT.agent18.B18.LL18,
    RL = model.NO_PARENT.agent18.B18.RL18,}agent19 = {
    base = model.NO_PARENT.agent19,
    B = model.NO_PARENT.agent19.B19,
    H = model.NO_PARENT.agent19.H19,
    LA = model.NO_PARENT.agent19.B19.LA19,
    RA = model.NO_PARENT.agent19.B19.RA19,
    LL = model.NO_PARENT.agent19.B19.LL19,
    RL = model.NO_PARENT.agent19.B19.RL19,}agent20 = {
    base = model.NO_PARENT.agent20,
    B = model.NO_PARENT.agent20.B20,
    H = model.NO_PARENT.agent20.H20,
    LA = model.NO_PARENT.agent20.B20.LA20,
    RA = model.NO_PARENT.agent20.B20.RA20,
    LL = model.NO_PARENT.agent20.B20.LL20,
    RL = model.NO_PARENT.agent20.B20.RL20,}agent21 = {
    base = model.NO_PARENT.agent21,
    B = model.NO_PARENT.agent21.B21,
    H = model.NO_PARENT.agent21.H21,
    LA = model.NO_PARENT.agent21.B21.LA21,
    RA = model.NO_PARENT.agent21.B21.RA21,
    LL = model.NO_PARENT.agent21.B21.LL21,
    RL = model.NO_PARENT.agent21.B21.RL21,}agent22 = {
    base = model.NO_PARENT.agent22,
    B = model.NO_PARENT.agent22.B22,
    H = model.NO_PARENT.agent22.H22,
    LA = model.NO_PARENT.agent22.B22.LA22,
    RA = model.NO_PARENT.agent22.B22.RA22,
    LL = model.NO_PARENT.agent22.B22.LL22,
    RL = model.NO_PARENT.agent22.B22.RL22,}agent23 = {
    base = model.NO_PARENT.agent23,
    B = model.NO_PARENT.agent23.B23,
    H = model.NO_PARENT.agent23.H23,
    LA = model.NO_PARENT.agent23.B23.LA23,
    RA = model.NO_PARENT.agent23.B23.RA23,
    LL = model.NO_PARENT.agent23.B23.LL23,
    RL = model.NO_PARENT.agent23.B23.RL23,}agent24 = {
    base = model.NO_PARENT.agent24,
    B = model.NO_PARENT.agent24.B24,
    H = model.NO_PARENT.agent24.H24,
    LA = model.NO_PARENT.agent24.B24.LA24,
    RA = model.NO_PARENT.agent24.B24.RA24,
    LL = model.NO_PARENT.agent24.B24.LL24,
    RL = model.NO_PARENT.agent24.B24.RL24,}agent25 = {
    base = model.NO_PARENT.agent25,
    B = model.NO_PARENT.agent25.B25,
    H = model.NO_PARENT.agent25.H25,
    LA = model.NO_PARENT.agent25.B25.LA25,
    RA = model.NO_PARENT.agent25.B25.RA25,
    LL = model.NO_PARENT.agent25.B25.LL25,
    RL = model.NO_PARENT.agent25.B25.RL25,}agent26 = {
    base = model.NO_PARENT.agent26,
    B = model.NO_PARENT.agent26.B26,
    H = model.NO_PARENT.agent26.H26,
    LA = model.NO_PARENT.agent26.B26.LA26,
    RA = model.NO_PARENT.agent26.B26.RA26,
    LL = model.NO_PARENT.agent26.B26.LL26,
    RL = model.NO_PARENT.agent26.B26.RL26,}agent27 = {
    base = model.NO_PARENT.agent27,
    B = model.NO_PARENT.agent27.B27,
    H = model.NO_PARENT.agent27.H27,
    LA = model.NO_PARENT.agent27.B27.LA27,
    RA = model.NO_PARENT.agent27.B27.RA27,
    LL = model.NO_PARENT.agent27.B27.LL27,
    RL = model.NO_PARENT.agent27.B27.RL27,}agent28 = {
    base = model.NO_PARENT.agent28,
    B = model.NO_PARENT.agent28.B28,
    H = model.NO_PARENT.agent28.H28,
    LA = model.NO_PARENT.agent28.B28.LA28,
    RA = model.NO_PARENT.agent28.B28.RA28,
    LL = model.NO_PARENT.agent28.B28.LL28,
    RL = model.NO_PARENT.agent28.B28.RL28,}agent29 = {
    base = model.NO_PARENT.agent29,
    B = model.NO_PARENT.agent29.B29,
    H = model.NO_PARENT.agent29.H29,
    LA = model.NO_PARENT.agent29.B29.LA29,
    RA = model.NO_PARENT.agent29.B29.RA29,
    LL = model.NO_PARENT.agent29.B29.LL29,
    RL = model.NO_PARENT.agent29.B29.RL29,}agent30 = {
    base = model.NO_PARENT.agent30,
    B = model.NO_PARENT.agent30.B30,
    H = model.NO_PARENT.agent30.H30,
    LA = model.NO_PARENT.agent30.B30.LA30,
    RA = model.NO_PARENT.agent30.B30.RA30,
    LL = model.NO_PARENT.agent30.B30.LL30,
    RL = model.NO_PARENT.agent30.B30.RL30,}agent31 = {
    base = model.NO_PARENT.agent31,
    B = model.NO_PARENT.agent31.B31,
    H = model.NO_PARENT.agent31.H31,
    LA = model.NO_PARENT.agent31.B31.LA31,
    RA = model.NO_PARENT.agent31.B31.RA31,
    LL = model.NO_PARENT.agent31.B31.LL31,
    RL = model.NO_PARENT.agent31.B31.RL31,}agent32 = {
    base = model.NO_PARENT.agent32,
    B = model.NO_PARENT.agent32.B32,
    H = model.NO_PARENT.agent32.H32,
    LA = model.NO_PARENT.agent32.B32.LA32,
    RA = model.NO_PARENT.agent32.B32.RA32,
    LL = model.NO_PARENT.agent32.B32.LL32,
    RL = model.NO_PARENT.agent32.B32.RL32,}agent33 = {
    base = model.NO_PARENT.agent33,
    B = model.NO_PARENT.agent33.B33,
    H = model.NO_PARENT.agent33.H33,
    LA = model.NO_PARENT.agent33.B33.LA33,
    RA = model.NO_PARENT.agent33.B33.RA33,
    LL = model.NO_PARENT.agent33.B33.LL33,
    RL = model.NO_PARENT.agent33.B33.RL33,}agent34 = {
    base = model.NO_PARENT.agent34,
    B = model.NO_PARENT.agent34.B34,
    H = model.NO_PARENT.agent34.H34,
    LA = model.NO_PARENT.agent34.B34.LA34,
    RA = model.NO_PARENT.agent34.B34.RA34,
    LL = model.NO_PARENT.agent34.B34.LL34,
    RL = model.NO_PARENT.agent34.B34.RL34,}agent35 = {
    base = model.NO_PARENT.agent35,
    B = model.NO_PARENT.agent35.B35,
    H = model.NO_PARENT.agent35.H35,
    LA = model.NO_PARENT.agent35.B35.LA35,
    RA = model.NO_PARENT.agent35.B35.RA35,
    LL = model.NO_PARENT.agent35.B35.LL35,
    RL = model.NO_PARENT.agent35.B35.RL35,}agent36 = {
    base = model.NO_PARENT.agent36,
    B = model.NO_PARENT.agent36.B36,
    H = model.NO_PARENT.agent36.H36,
    LA = model.NO_PARENT.agent36.B36.LA36,
    RA = model.NO_PARENT.agent36.B36.RA36,
    LL = model.NO_PARENT.agent36.B36.LL36,
    RL = model.NO_PARENT.agent36.B36.RL36,}agent37 = {
    base = model.NO_PARENT.agent37,
    B = model.NO_PARENT.agent37.B37,
    H = model.NO_PARENT.agent37.H37,
    LA = model.NO_PARENT.agent37.B37.LA37,
    RA = model.NO_PARENT.agent37.B37.RA37,
    LL = model.NO_PARENT.agent37.B37.LL37,
    RL = model.NO_PARENT.agent37.B37.RL37,}agent38 = {
    base = model.NO_PARENT.agent38,
    B = model.NO_PARENT.agent38.B38,
    H = model.NO_PARENT.agent38.H38,
    LA = model.NO_PARENT.agent38.B38.LA38,
    RA = model.NO_PARENT.agent38.B38.RA38,
    LL = model.NO_PARENT.agent38.B38.LL38,
    RL = model.NO_PARENT.agent38.B38.RL38,}agent39 = {
    base = model.NO_PARENT.agent39,
    B = model.NO_PARENT.agent39.B39,
    H = model.NO_PARENT.agent39.H39,
    LA = model.NO_PARENT.agent39.B39.LA39,
    RA = model.NO_PARENT.agent39.B39.RA39,
    LL = model.NO_PARENT.agent39.B39.LL39,
    RL = model.NO_PARENT.agent39.B39.RL39,}agent40 = {
    base = model.NO_PARENT.agent40,
    B = model.NO_PARENT.agent40.B40,
    H = model.NO_PARENT.agent40.H40,
    LA = model.NO_PARENT.agent40.B40.LA40,
    RA = model.NO_PARENT.agent40.B40.RA40,
    LL = model.NO_PARENT.agent40.B40.LL40,
    RL = model.NO_PARENT.agent40.B40.RL40,}agent41 = {
    base = model.NO_PARENT.agent41,
    B = model.NO_PARENT.agent41.B41,
    H = model.NO_PARENT.agent41.H41,
    LA = model.NO_PARENT.agent41.B41.LA41,
    RA = model.NO_PARENT.agent41.B41.RA41,
    LL = model.NO_PARENT.agent41.B41.LL41,
    RL = model.NO_PARENT.agent41.B41.RL41,}agent42 = {
    base = model.NO_PARENT.agent42,
    B = model.NO_PARENT.agent42.B42,
    H = model.NO_PARENT.agent42.H42,
    LA = model.NO_PARENT.agent42.B42.LA42,
    RA = model.NO_PARENT.agent42.B42.RA42,
    LL = model.NO_PARENT.agent42.B42.LL42,
    RL = model.NO_PARENT.agent42.B42.RL42,}agent43 = {
    base = model.NO_PARENT.agent43,
    B = model.NO_PARENT.agent43.B43,
    H = model.NO_PARENT.agent43.H43,
    LA = model.NO_PARENT.agent43.B43.LA43,
    RA = model.NO_PARENT.agent43.B43.RA43,
    LL = model.NO_PARENT.agent43.B43.LL43,
    RL = model.NO_PARENT.agent43.B43.RL43,}agent44 = {
    base = model.NO_PARENT.agent44,
    B = model.NO_PARENT.agent44.B44,
    H = model.NO_PARENT.agent44.H44,
    LA = model.NO_PARENT.agent44.B44.LA44,
    RA = model.NO_PARENT.agent44.B44.RA44,
    LL = model.NO_PARENT.agent44.B44.LL44,
    RL = model.NO_PARENT.agent44.B44.RL44,}agent45 = {
    base = model.NO_PARENT.agent45,
    B = model.NO_PARENT.agent45.B45,
    H = model.NO_PARENT.agent45.H45,
    LA = model.NO_PARENT.agent45.B45.LA45,
    RA = model.NO_PARENT.agent45.B45.RA45,
    LL = model.NO_PARENT.agent45.B45.LL45,
    RL = model.NO_PARENT.agent45.B45.RL45,}agent46 = {
    base = model.NO_PARENT.agent46,
    B = model.NO_PARENT.agent46.B46,
    H = model.NO_PARENT.agent46.H46,
    LA = model.NO_PARENT.agent46.B46.LA46,
    RA = model.NO_PARENT.agent46.B46.RA46,
    LL = model.NO_PARENT.agent46.B46.LL46,
    RL = model.NO_PARENT.agent46.B46.RL46,}agent47 = {
    base = model.NO_PARENT.agent47,
    B = model.NO_PARENT.agent47.B47,
    H = model.NO_PARENT.agent47.H47,
    LA = model.NO_PARENT.agent47.B47.LA47,
    RA = model.NO_PARENT.agent47.B47.RA47,
    LL = model.NO_PARENT.agent47.B47.LL47,
    RL = model.NO_PARENT.agent47.B47.RL47,}agent48 = {
    base = model.NO_PARENT.agent48,
    B = model.NO_PARENT.agent48.B48,
    H = model.NO_PARENT.agent48.H48,
    LA = model.NO_PARENT.agent48.B48.LA48,
    RA = model.NO_PARENT.agent48.B48.RA48,
    LL = model.NO_PARENT.agent48.B48.LL48,
    RL = model.NO_PARENT.agent48.B48.RL48,}agent49 = {
    base = model.NO_PARENT.agent49,
    B = model.NO_PARENT.agent49.B49,
    H = model.NO_PARENT.agent49.H49,
    LA = model.NO_PARENT.agent49.B49.LA49,
    RA = model.NO_PARENT.agent49.B49.RA49,
    LL = model.NO_PARENT.agent49.B49.LL49,
    RL = model.NO_PARENT.agent49.B49.RL49,}agent50 = {
    base = model.NO_PARENT.agent50,
    B = model.NO_PARENT.agent50.B50,
    H = model.NO_PARENT.agent50.H50,
    LA = model.NO_PARENT.agent50.B50.LA50,
    RA = model.NO_PARENT.agent50.B50.RA50,
    LL = model.NO_PARENT.agent50.B50.LL50,
    RL = model.NO_PARENT.agent50.B50.RL50,}agent51 = {
    base = model.NO_PARENT.agent51,
    B = model.NO_PARENT.agent51.B51,
    H = model.NO_PARENT.agent51.H51,
    LA = model.NO_PARENT.agent51.B51.LA51,
    RA = model.NO_PARENT.agent51.B51.RA51,
    LL = model.NO_PARENT.agent51.B51.LL51,
    RL = model.NO_PARENT.agent51.B51.RL51,}agent52 = {
    base = model.NO_PARENT.agent52,
    B = model.NO_PARENT.agent52.B52,
    H = model.NO_PARENT.agent52.H52,
    LA = model.NO_PARENT.agent52.B52.LA52,
    RA = model.NO_PARENT.agent52.B52.RA52,
    LL = model.NO_PARENT.agent52.B52.LL52,
    RL = model.NO_PARENT.agent52.B52.RL52,}agent53 = {
    base = model.NO_PARENT.agent53,
    B = model.NO_PARENT.agent53.B53,
    H = model.NO_PARENT.agent53.H53,
    LA = model.NO_PARENT.agent53.B53.LA53,
    RA = model.NO_PARENT.agent53.B53.RA53,
    LL = model.NO_PARENT.agent53.B53.LL53,
    RL = model.NO_PARENT.agent53.B53.RL53,}agent54 = {
    base = model.NO_PARENT.agent54,
    B = model.NO_PARENT.agent54.B54,
    H = model.NO_PARENT.agent54.H54,
    LA = model.NO_PARENT.agent54.B54.LA54,
    RA = model.NO_PARENT.agent54.B54.RA54,
    LL = model.NO_PARENT.agent54.B54.LL54,
    RL = model.NO_PARENT.agent54.B54.RL54,}agent55 = {
    base = model.NO_PARENT.agent55,
    B = model.NO_PARENT.agent55.B55,
    H = model.NO_PARENT.agent55.H55,
    LA = model.NO_PARENT.agent55.B55.LA55,
    RA = model.NO_PARENT.agent55.B55.RA55,
    LL = model.NO_PARENT.agent55.B55.LL55,
    RL = model.NO_PARENT.agent55.B55.RL55,}agent56 = {
    base = model.NO_PARENT.agent56,
    B = model.NO_PARENT.agent56.B56,
    H = model.NO_PARENT.agent56.H56,
    LA = model.NO_PARENT.agent56.B56.LA56,
    RA = model.NO_PARENT.agent56.B56.RA56,
    LL = model.NO_PARENT.agent56.B56.LL56,
    RL = model.NO_PARENT.agent56.B56.RL56,}agent57 = {
    base = model.NO_PARENT.agent57,
    B = model.NO_PARENT.agent57.B57,
    H = model.NO_PARENT.agent57.H57,
    LA = model.NO_PARENT.agent57.B57.LA57,
    RA = model.NO_PARENT.agent57.B57.RA57,
    LL = model.NO_PARENT.agent57.B57.LL57,
    RL = model.NO_PARENT.agent57.B57.RL57,}agent58 = {
    base = model.NO_PARENT.agent58,
    B = model.NO_PARENT.agent58.B58,
    H = model.NO_PARENT.agent58.H58,
    LA = model.NO_PARENT.agent58.B58.LA58,
    RA = model.NO_PARENT.agent58.B58.RA58,
    LL = model.NO_PARENT.agent58.B58.LL58,
    RL = model.NO_PARENT.agent58.B58.RL58,}agent59 = {
    base = model.NO_PARENT.agent59,
    B = model.NO_PARENT.agent59.B59,
    H = model.NO_PARENT.agent59.H59,
    LA = model.NO_PARENT.agent59.B59.LA59,
    RA = model.NO_PARENT.agent59.B59.RA59,
    LL = model.NO_PARENT.agent59.B59.LL59,
    RL = model.NO_PARENT.agent59.B59.RL59,}agent60 = {
    base = model.NO_PARENT.agent60,
    B = model.NO_PARENT.agent60.B60,
    H = model.NO_PARENT.agent60.H60,
    LA = model.NO_PARENT.agent60.B60.LA60,
    RA = model.NO_PARENT.agent60.B60.RA60,
    LL = model.NO_PARENT.agent60.B60.LL60,
    RL = model.NO_PARENT.agent60.B60.RL60,}agent61 = {
    base = model.NO_PARENT.agent61,
    B = model.NO_PARENT.agent61.B61,
    H = model.NO_PARENT.agent61.H61,
    LA = model.NO_PARENT.agent61.B61.LA61,
    RA = model.NO_PARENT.agent61.B61.RA61,
    LL = model.NO_PARENT.agent61.B61.LL61,
    RL = model.NO_PARENT.agent61.B61.RL61,}agent62 = {
    base = model.NO_PARENT.agent62,
    B = model.NO_PARENT.agent62.B62,
    H = model.NO_PARENT.agent62.H62,
    LA = model.NO_PARENT.agent62.B62.LA62,
    RA = model.NO_PARENT.agent62.B62.RA62,
    LL = model.NO_PARENT.agent62.B62.LL62,
    RL = model.NO_PARENT.agent62.B62.RL62,}agent63 = {
    base = model.NO_PARENT.agent63,
    B = model.NO_PARENT.agent63.B63,
    H = model.NO_PARENT.agent63.H63,
    LA = model.NO_PARENT.agent63.B63.LA63,
    RA = model.NO_PARENT.agent63.B63.RA63,
    LL = model.NO_PARENT.agent63.B63.LL63,
    RL = model.NO_PARENT.agent63.B63.RL63,}agent64 = {
    base = model.NO_PARENT.agent64,
    B = model.NO_PARENT.agent64.B64,
    H = model.NO_PARENT.agent64.H64,
    LA = model.NO_PARENT.agent64.B64.LA64,
    RA = model.NO_PARENT.agent64.B64.RA64,
    LL = model.NO_PARENT.agent64.B64.LL64,
    RL = model.NO_PARENT.agent64.B64.RL64,}agent65 = {
    base = model.NO_PARENT.agent65,
    B = model.NO_PARENT.agent65.B65,
    H = model.NO_PARENT.agent65.H65,
    LA = model.NO_PARENT.agent65.B65.LA65,
    RA = model.NO_PARENT.agent65.B65.RA65,
    LL = model.NO_PARENT.agent65.B65.LL65,
    RL = model.NO_PARENT.agent65.B65.RL65,}agent66 = {
    base = model.NO_PARENT.agent66,
    B = model.NO_PARENT.agent66.B66,
    H = model.NO_PARENT.agent66.H66,
    LA = model.NO_PARENT.agent66.B66.LA66,
    RA = model.NO_PARENT.agent66.B66.RA66,
    LL = model.NO_PARENT.agent66.B66.LL66,
    RL = model.NO_PARENT.agent66.B66.RL66,}agent67 = {
    base = model.NO_PARENT.agent67,
    B = model.NO_PARENT.agent67.B67,
    H = model.NO_PARENT.agent67.H67,
    LA = model.NO_PARENT.agent67.B67.LA67,
    RA = model.NO_PARENT.agent67.B67.RA67,
    LL = model.NO_PARENT.agent67.B67.LL67,
    RL = model.NO_PARENT.agent67.B67.RL67,}agent68 = {
    base = model.NO_PARENT.agent68,
    B = model.NO_PARENT.agent68.B68,
    H = model.NO_PARENT.agent68.H68,
    LA = model.NO_PARENT.agent68.B68.LA68,
    RA = model.NO_PARENT.agent68.B68.RA68,
    LL = model.NO_PARENT.agent68.B68.LL68,
    RL = model.NO_PARENT.agent68.B68.RL68,}agent69 = {
    base = model.NO_PARENT.agent69,
    B = model.NO_PARENT.agent69.B69,
    H = model.NO_PARENT.agent69.H69,
    LA = model.NO_PARENT.agent69.B69.LA69,
    RA = model.NO_PARENT.agent69.B69.RA69,
    LL = model.NO_PARENT.agent69.B69.LL69,
    RL = model.NO_PARENT.agent69.B69.RL69,}agent70 = {
    base = model.NO_PARENT.agent70,
    B = model.NO_PARENT.agent70.B70,
    H = model.NO_PARENT.agent70.H70,
    LA = model.NO_PARENT.agent70.B70.LA70,
    RA = model.NO_PARENT.agent70.B70.RA70,
    LL = model.NO_PARENT.agent70.B70.LL70,
    RL = model.NO_PARENT.agent70.B70.RL70,}agent71 = {
    base = model.NO_PARENT.agent71,
    B = model.NO_PARENT.agent71.B71,
    H = model.NO_PARENT.agent71.H71,
    LA = model.NO_PARENT.agent71.B71.LA71,
    RA = model.NO_PARENT.agent71.B71.RA71,
    LL = model.NO_PARENT.agent71.B71.LL71,
    RL = model.NO_PARENT.agent71.B71.RL71,}agent72 = {
    base = model.NO_PARENT.agent72,
    B = model.NO_PARENT.agent72.B72,
    H = model.NO_PARENT.agent72.H72,
    LA = model.NO_PARENT.agent72.B72.LA72,
    RA = model.NO_PARENT.agent72.B72.RA72,
    LL = model.NO_PARENT.agent72.B72.LL72,
    RL = model.NO_PARENT.agent72.B72.RL72,}agent73 = {
    base = model.NO_PARENT.agent73,
    B = model.NO_PARENT.agent73.B73,
    H = model.NO_PARENT.agent73.H73,
    LA = model.NO_PARENT.agent73.B73.LA73,
    RA = model.NO_PARENT.agent73.B73.RA73,
    LL = model.NO_PARENT.agent73.B73.LL73,
    RL = model.NO_PARENT.agent73.B73.RL73,}agent74 = {
    base = model.NO_PARENT.agent74,
    B = model.NO_PARENT.agent74.B74,
    H = model.NO_PARENT.agent74.H74,
    LA = model.NO_PARENT.agent74.B74.LA74,
    RA = model.NO_PARENT.agent74.B74.RA74,
    LL = model.NO_PARENT.agent74.B74.LL74,
    RL = model.NO_PARENT.agent74.B74.RL74,}agent75 = {
    base = model.NO_PARENT.agent75,
    B = model.NO_PARENT.agent75.B75,
    H = model.NO_PARENT.agent75.H75,
    LA = model.NO_PARENT.agent75.B75.LA75,
    RA = model.NO_PARENT.agent75.B75.RA75,
    LL = model.NO_PARENT.agent75.B75.LL75,
    RL = model.NO_PARENT.agent75.B75.RL75,}agent76 = {
    base = model.NO_PARENT.agent76,
    B = model.NO_PARENT.agent76.B76,
    H = model.NO_PARENT.agent76.H76,
    LA = model.NO_PARENT.agent76.B76.LA76,
    RA = model.NO_PARENT.agent76.B76.RA76,
    LL = model.NO_PARENT.agent76.B76.LL76,
    RL = model.NO_PARENT.agent76.B76.RL76,}agent77 = {
    base = model.NO_PARENT.agent77,
    B = model.NO_PARENT.agent77.B77,
    H = model.NO_PARENT.agent77.H77,
    LA = model.NO_PARENT.agent77.B77.LA77,
    RA = model.NO_PARENT.agent77.B77.RA77,
    LL = model.NO_PARENT.agent77.B77.LL77,
    RL = model.NO_PARENT.agent77.B77.RL77,}agent78 = {
    base = model.NO_PARENT.agent78,
    B = model.NO_PARENT.agent78.B78,
    H = model.NO_PARENT.agent78.H78,
    LA = model.NO_PARENT.agent78.B78.LA78,
    RA = model.NO_PARENT.agent78.B78.RA78,
    LL = model.NO_PARENT.agent78.B78.LL78,
    RL = model.NO_PARENT.agent78.B78.RL78,}agent79 = {
    base = model.NO_PARENT.agent79,
    B = model.NO_PARENT.agent79.B79,
    H = model.NO_PARENT.agent79.H79,
    LA = model.NO_PARENT.agent79.B79.LA79,
    RA = model.NO_PARENT.agent79.B79.RA79,
    LL = model.NO_PARENT.agent79.B79.LL79,
    RL = model.NO_PARENT.agent79.B79.RL79,}agent80 = {
    base = model.NO_PARENT.agent80,
    B = model.NO_PARENT.agent80.B80,
    H = model.NO_PARENT.agent80.H80,
    LA = model.NO_PARENT.agent80.B80.LA80,
    RA = model.NO_PARENT.agent80.B80.RA80,
    LL = model.NO_PARENT.agent80.B80.LL80,
    RL = model.NO_PARENT.agent80.B80.RL80,}agent81 = {
    base = model.NO_PARENT.agent81,
    B = model.NO_PARENT.agent81.B81,
    H = model.NO_PARENT.agent81.H81,
    LA = model.NO_PARENT.agent81.B81.LA81,
    RA = model.NO_PARENT.agent81.B81.RA81,
    LL = model.NO_PARENT.agent81.B81.LL81,
    RL = model.NO_PARENT.agent81.B81.RL81,}agent82 = {
    base = model.NO_PARENT.agent82,
    B = model.NO_PARENT.agent82.B82,
    H = model.NO_PARENT.agent82.H82,
    LA = model.NO_PARENT.agent82.B82.LA82,
    RA = model.NO_PARENT.agent82.B82.RA82,
    LL = model.NO_PARENT.agent82.B82.LL82,
    RL = model.NO_PARENT.agent82.B82.RL82,}agent83 = {
    base = model.NO_PARENT.agent83,
    B = model.NO_PARENT.agent83.B83,
    H = model.NO_PARENT.agent83.H83,
    LA = model.NO_PARENT.agent83.B83.LA83,
    RA = model.NO_PARENT.agent83.B83.RA83,
    LL = model.NO_PARENT.agent83.B83.LL83,
    RL = model.NO_PARENT.agent83.B83.RL83,}agent84 = {
    base = model.NO_PARENT.agent84,
    B = model.NO_PARENT.agent84.B84,
    H = model.NO_PARENT.agent84.H84,
    LA = model.NO_PARENT.agent84.B84.LA84,
    RA = model.NO_PARENT.agent84.B84.RA84,
    LL = model.NO_PARENT.agent84.B84.LL84,
    RL = model.NO_PARENT.agent84.B84.RL84,}agent85 = {
    base = model.NO_PARENT.agent85,
    B = model.NO_PARENT.agent85.B85,
    H = model.NO_PARENT.agent85.H85,
    LA = model.NO_PARENT.agent85.B85.LA85,
    RA = model.NO_PARENT.agent85.B85.RA85,
    LL = model.NO_PARENT.agent85.B85.LL85,
    RL = model.NO_PARENT.agent85.B85.RL85,}agent86 = {
    base = model.NO_PARENT.agent86,
    B = model.NO_PARENT.agent86.B86,
    H = model.NO_PARENT.agent86.H86,
    LA = model.NO_PARENT.agent86.B86.LA86,
    RA = model.NO_PARENT.agent86.B86.RA86,
    LL = model.NO_PARENT.agent86.B86.LL86,
    RL = model.NO_PARENT.agent86.B86.RL86,}agent87 = {
    base = model.NO_PARENT.agent87,
    B = model.NO_PARENT.agent87.B87,
    H = model.NO_PARENT.agent87.H87,
    LA = model.NO_PARENT.agent87.B87.LA87,
    RA = model.NO_PARENT.agent87.B87.RA87,
    LL = model.NO_PARENT.agent87.B87.LL87,
    RL = model.NO_PARENT.agent87.B87.RL87,}agent88 = {
    base = model.NO_PARENT.agent88,
    B = model.NO_PARENT.agent88.B88,
    H = model.NO_PARENT.agent88.H88,
    LA = model.NO_PARENT.agent88.B88.LA88,
    RA = model.NO_PARENT.agent88.B88.RA88,
    LL = model.NO_PARENT.agent88.B88.LL88,
    RL = model.NO_PARENT.agent88.B88.RL88,}agent89 = {
    base = model.NO_PARENT.agent89,
    B = model.NO_PARENT.agent89.B89,
    H = model.NO_PARENT.agent89.H89,
    LA = model.NO_PARENT.agent89.B89.LA89,
    RA = model.NO_PARENT.agent89.B89.RA89,
    LL = model.NO_PARENT.agent89.B89.LL89,
    RL = model.NO_PARENT.agent89.B89.RL89,}agent90 = {
    base = model.NO_PARENT.agent90,
    B = model.NO_PARENT.agent90.B90,
    H = model.NO_PARENT.agent90.H90,
    LA = model.NO_PARENT.agent90.B90.LA90,
    RA = model.NO_PARENT.agent90.B90.RA90,
    LL = model.NO_PARENT.agent90.B90.LL90,
    RL = model.NO_PARENT.agent90.B90.RL90,}agent91 = {
    base = model.NO_PARENT.agent91,
    B = model.NO_PARENT.agent91.B91,
    H = model.NO_PARENT.agent91.H91,
    LA = model.NO_PARENT.agent91.B91.LA91,
    RA = model.NO_PARENT.agent91.B91.RA91,
    LL = model.NO_PARENT.agent91.B91.LL91,
    RL = model.NO_PARENT.agent91.B91.RL91,}agent92 = {
    base = model.NO_PARENT.agent92,
    B = model.NO_PARENT.agent92.B92,
    H = model.NO_PARENT.agent92.H92,
    LA = model.NO_PARENT.agent92.B92.LA92,
    RA = model.NO_PARENT.agent92.B92.RA92,
    LL = model.NO_PARENT.agent92.B92.LL92,
    RL = model.NO_PARENT.agent92.B92.RL92,}agent93 = {
    base = model.NO_PARENT.agent93,
    B = model.NO_PARENT.agent93.B93,
    H = model.NO_PARENT.agent93.H93,
    LA = model.NO_PARENT.agent93.B93.LA93,
    RA = model.NO_PARENT.agent93.B93.RA93,
    LL = model.NO_PARENT.agent93.B93.LL93,
    RL = model.NO_PARENT.agent93.B93.RL93,}agent94 = {
    base = model.NO_PARENT.agent94,
    B = model.NO_PARENT.agent94.B94,
    H = model.NO_PARENT.agent94.H94,
    LA = model.NO_PARENT.agent94.B94.LA94,
    RA = model.NO_PARENT.agent94.B94.RA94,
    LL = model.NO_PARENT.agent94.B94.LL94,
    RL = model.NO_PARENT.agent94.B94.RL94,}agent95 = {
    base = model.NO_PARENT.agent95,
    B = model.NO_PARENT.agent95.B95,
    H = model.NO_PARENT.agent95.H95,
    LA = model.NO_PARENT.agent95.B95.LA95,
    RA = model.NO_PARENT.agent95.B95.RA95,
    LL = model.NO_PARENT.agent95.B95.LL95,
    RL = model.NO_PARENT.agent95.B95.RL95,}agent96 = {
    base = model.NO_PARENT.agent96,
    B = model.NO_PARENT.agent96.B96,
    H = model.NO_PARENT.agent96.H96,
    LA = model.NO_PARENT.agent96.B96.LA96,
    RA = model.NO_PARENT.agent96.B96.RA96,
    LL = model.NO_PARENT.agent96.B96.LL96,
    RL = model.NO_PARENT.agent96.B96.RL96,}agent97 = {
    base = model.NO_PARENT.agent97,
    B = model.NO_PARENT.agent97.B97,
    H = model.NO_PARENT.agent97.H97,
    LA = model.NO_PARENT.agent97.B97.LA97,
    RA = model.NO_PARENT.agent97.B97.RA97,
    LL = model.NO_PARENT.agent97.B97.LL97,
    RL = model.NO_PARENT.agent97.B97.RL97,}agent98 = {
    base = model.NO_PARENT.agent98,
    B = model.NO_PARENT.agent98.B98,
    H = model.NO_PARENT.agent98.H98,
    LA = model.NO_PARENT.agent98.B98.LA98,
    RA = model.NO_PARENT.agent98.B98.RA98,
    LL = model.NO_PARENT.agent98.B98.LL98,
    RL = model.NO_PARENT.agent98.B98.RL98,}agent99 = {
    base = model.NO_PARENT.agent99,
    B = model.NO_PARENT.agent99.B99,
    H = model.NO_PARENT.agent99.H99,
    LA = model.NO_PARENT.agent99.B99.LA99,
    RA = model.NO_PARENT.agent99.B99.RA99,
    LL = model.NO_PARENT.agent99.B99.LL99,
    RL = model.NO_PARENT.agent99.B99.RL99,}agent100 = {
    base = model.NO_PARENT.agent100,
    B = model.NO_PARENT.agent100.B100,
    H = model.NO_PARENT.agent100.H100,
    LA = model.NO_PARENT.agent100.B100.LA100,
    RA = model.NO_PARENT.agent100.B100.RA100,
    LL = model.NO_PARENT.agent100.B100.LL100,
    RL = model.NO_PARENT.agent100.B100.RL100,}
agents = {agent1,agent2,agent3,agent4,agent5,agent6,agent7,agent8,agent9,agent10,agent11,agent12,agent13,agent14,agent15,agent16,agent17,agent18,agent19,agent20,agent21,agent22,agent23,agent24,agent25,agent26,agent27,agent28,agent29,agent30,agent31,agent32,agent33,agent34,agent35,agent36,agent37,agent38,agent39,agent40,agent41,agent42,agent43,agent44,agent45,agent46,agent47,agent48,agent49,agent50,agent51,agent52,agent53,agent54,agent55,agent56,agent57,agent58,agent59,agent60,agent61,agent62,agent63,agent64,agent65,agent66,agent67,agent68,agent69,agent70,agent71,agent72,agent73,agent74,agent75,agent76,agent77,agent78,agent79,agent80,agent81,agent82,agent83,agent84,agent85,agent86,agent87,agent88,agent89,agent90,agent91,agent92,agent93,agent94,agent95,agent96,agent97,agent98,agent99,agent100}

--dragekk's original idea

finishedLoading = false
function player_init()
    for key, value in pairs(agents) do
        value.base.setScale({0.95,0.95,0.95})
        position[key] = player.getPos()
        declareNewAgentStats()
    end
    finishedLoading = true
end

function tick()
    if finishedLoading then
        for key, value in pairs(agents) do
            position[key] = position[key] + velocity[key]
            velocity[key] = velocity[key] * vectors.of({0.6,1,0.6})
    
            local coll = collision(position[key])
            position[key] = coll.position
            velocity[key] = velocity[key] + vectors.of({0,-0.08})
    
            if coll.isColliding then
                velocity[key].y = 0.0001
            end
            local distanceToPlayer = vectors.of({position[key].x,0,position[key].z}).distanceTo((vectors.of({player.getPos().x,0,player.getPos().z})+offsetTarget[key]))
            if distanceToPlayer > 1 then
                local movement = (player.getPos()-position[key]+offsetTarget[key]).normalized()*0.1
                
                if distanceToPlayer > 5 then
                    movement = (player.getPos()-position[key]+offsetTarget[key]).normalized()*0.15
                    if coll.isColliding then
                        velocity[key].y = 0.4
                    end
                end
                velocity[key] = velocity[key] + vectors.of({movement.x,0,movement.z})
            end
            
            if world.getBlockState(position[key]+vectors.of({0,0.5,0})).name == "minecraft:water" then
                velocity[key] = velocity[key] * vectors.of({0.7,0.8,0.7})
                velocity[key] = velocity[key] + vectors.of({0,0.1,0})
            end

            distVelocity[key] = vectors.of({}).distanceTo(vectors.of({velocity[key].x,0,velocity[key].z}))
            distanceWalked[key] = distanceWalked[key] + distVelocity[key]

            if wanderTimer[key] < 0 then
                wanderTimer[key] = math.random()*20*5
                offsetTarget[key] = vectors.of({math.random()*50-25,0,math.random()*50-25})
            end
            wanderTimer[key] = wanderTimer[key] - 1
        end
    end
end

function world_render(delta)
    if finishedLoading then
        for key, value in pairs(agents) do
            value.base.setPos(vectors.lerp(value.base.getPos(),vectors.of({position[key].x*-16,position[key].y*-16,position[key].z*16}),delta))

            if velocity[key].distanceTo(vectors.of({})) > 0.01 then
                value.B.setRot({0,lerp_angle(value.B.getRot().y,math.deg(math.atan2(velocity[key].x,velocity[key].z))+180,delta)})
            end
            local lukat = velocity[key] * vectors.of({-1,-1,-1})

            targetRotation[key] = vectors.of({0,math.deg(math.atan2(lukat.x,lukat.z)),0})
            value.H.setRot({
                lerp_angle(value.H.getRot().x,targetRotation[key].x,delta),
                lerp_angle(value.H.getRot().y,targetRotation[key].y,delta),
                lerp_angle(value.H.getRot().z,targetRotation[key].z,delta)})
            local swing = (math.sin(distanceWalked[key]*2.3)*45)*math.min(distVelocity[key]*32,1)
            value.LL.setRot({lerp(value.LL.getRot().x,swing,delta)})
            value.RL.setRot({lerp(value.RL.getRot().x,-swing,delta)})
            value.LA.setRot({lerp(value.LA.getRot().x,swing,delta)})
            value.RA.setRot({lerp(value.RA.getRot().x,-swing,delta)})
        end
    end
end

function lerp(a, b, x)
    return a + (b - a) * x
end

function lerp_angle(a, b, x)
    local diff = (b-a)
    local delta = diff-(math.floor(diff/360)*360)
    if delta > 180 then
        delta = delta - 360
    end
    return a + delta * x
end

--for future plans
function declareNewAgentStats()
    table.insert(position,vectors.of({0,0,0}))
    table.insert(velocity,vectors.of({0,0,0}))
    table.insert(targetRotation,vectors.of({0,0,0}))
    table.insert(distanceWalked,0)
    table.insert(distVelocity,0)
    table.insert(offsetTarget,vectors.of({0,0,0}))
    table.insert(wanderTimer,0)
end

--collision detection by GNamimates#9366
--give it a 3D position and it will return back the position but adjusted to the closest surface
function collision(pos)-- sorry idk what to name this lmao
    local point = vectors.of({pos.x,pos.y,pos.z})
    local collision = world.getBlockState(point).getCollisionShape()
    local blockPos = vectors.of({point.x-math.floor(point.x),point.y-math.floor(point.y),point.z-math.floor(point.z)})
    local iscoll = false

    for index, value in ipairs(collision) do--loop through all the collision boxes
        if value.x < blockPos.x and value.w > blockPos.x then-- checks if inside the collision box
            if value.y < blockPos.y and value.t > blockPos.y then
                if value.z < blockPos.z and value.h > blockPos.z then
                    --detected inside the cube
                    local currentPoint = point--for somethin idk
                    --finding the closest surface from the cube
                    point.y = math.floor(currentPoint.y)+value.t
                    iscoll = true
                end
            end
        end
    end
    return {position=point,isColliding=iscoll}
end