for k,v in pairs(vanilla_model) do
	v.setEnabled(false)
end

timer = 0
timerMax = 30
cloakSpeed = 0

function player_init()
	model.base.setRenderLayer("ghostLayer")
end

function tick()
	timer = timer + cloakSpeed
	if timer >= timerMax then
		timer = timerMax
		cloakSpeed = 0
	elseif timer <= 0 then
		timer = 0
		cloakSpeed = 0
	end
end

function render(delta)
	local time = timer + delta*cloakSpeed
	local cutoff = -0.01 + 1.02*time/timerMax 
	renderer.setUniform("ghostLayer", "CutoffLevel", cutoff)
	renderer.setShadowSize(0.5*(1-timer/timerMax))
end

function toggleCloak() 
	if timer == timerMax then
		renderer.setUniform("ghostLayer", "RandomSeed", math.random()*2)
		cloakSpeed = -1
	elseif timer == 0 then
		renderer.setUniform("ghostLayer", "RandomSeed", math.random()*2)
		cloakSpeed = 1
	end
end

network.registerPing("toggleCloak")

action_wheel.SLOT_1.setItem(item_stack.createItem("minecraft:golden_carrot"))
action_wheel.SLOT_1.setTitle("Toggle Cloak")
action_wheel.SLOT_1.setFunction(function() network.ping("toggleCloak") end)