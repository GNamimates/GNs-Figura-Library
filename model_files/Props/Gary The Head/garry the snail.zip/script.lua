vanilla_model.HEAD.setEnabled(false)
vanilla_model.HAT.setEnabled(false)
--gary the snail