-- Settings --
MIN_DELAY = 30
MAX_DELAY = 30
SOUND_DELAY = 80
FRAMES = 5
TB = 2
--------------
firstPerson = keybind.newKey("Float in First-Person", "L")
fpfon = false

sineCount = 0

nextBlink = world.getTime()+math.random(MIN_DELAY,MAX_DELAY)
nextSound = world.getTime()+SOUND_DELAY

function onDamage(amount, source)
	log("ow")
	sound.playSound("entity.wither.hurt", player.getPos(), {1, 0})
end

function tick()
	if firstPerson.isPressed() then
		if fpfon == true then
			log("First-Person Floating Off")
			fpfon = false
		else
			log("First-Person Floating On")
			fpfon = true
		end
	end
	
	sineCount = sineCount + 0.25
	sine = (math.sin(sineCount)/5)+0.75
	sineModel = (-(math.sin(sineCount)*5))-11.25
	vanilla_model.HEAD.setPos({0,sineModel,0})
	vanilla_model.TORSO.setPos({0,sineModel,0})
	vanilla_model.LEFT_ARM.setPos({0,sineModel,0})
	vanilla_model.RIGHT_ARM.setPos({0,sineModel,0})
	vanilla_model.LEFT_LEG.setPos({0,sineModel,0})
	vanilla_model.RIGHT_LEG.setPos({0,sineModel,0})
	vanilla_model.HAT.setPos({0,sineModel,0})
	vanilla_model.JACKET.setPos({0,sineModel,0})
	vanilla_model.LEFT_SLEEVE.setPos({0,sineModel,0})
	vanilla_model.RIGHT_SLEEVE.setPos({0,sineModel,0})
	vanilla_model.LEFT_PANTS_LEG.setPos({0,sineModel,0})
	vanilla_model.RIGHT_PANTS_LEG.setPos({0,sineModel,0})
	particlepos = player.getPos()+vectors.of({(math.random(-20,20)/100),sine,(math.random(-20,20)/100)})
	particle.addParticle("soul_fire_flame", particlepos,{0,0,0})
	if fpfon then
		camera.FIRST_PERSON.setPos({0,sine,0})
	else
		camera.FIRST_PERSON.setPos({0,0,0})
	end
	camera.THIRD_PERSON.setPos({0,sine,0})
    local x = world.getTime()
    if x >= nextBlink then
        model.Body.setUV({0,(x-nextBlink)/FRAMES})
        model.Head.setUV({0,(x-nextBlink)/FRAMES})
        model.LeftArm.setUV({0,(x-nextBlink)/FRAMES})
        model.RightArm.setUV({0,(x-nextBlink)/FRAMES})
        model.LeftLeg.setUV({0,(x-nextBlink)/FRAMES})
        model.RightLeg.setUV({0,(x-nextBlink)/FRAMES})
        if x >= nextBlink+(FRAMES) then
            nextBlink = x+math.random(MIN_DELAY,MAX_DELAY)
        end
    end
	if x >= nextSound then
        sound.playSound("entity.wither.ambient", player.getPos(), {1, 0})
		nextSound = x+SOUND_DELAY
    end
end